# Global Incident Rules & Learning

## Generell Læring og Feilkorrigeringer (Do's and Don'ts)

Denne filen samler læringspunkter fra hendelser og feilsøking som har overføringsverdi på
tvers av caser. Punktene under er arvet fra malen ved oppsett av denne casen.

### Do's
- Komprimer store binærfiler (presentasjoner, videoer) til PDF før de legges
  i `Customers request/` eller `Meeting notes/` — f.eks. embeddede videoer og
  høyoppløselige bilder i PowerPoint-filer kan gjøre dem unødvendig store.
- Bruk konsekvent stor forbokstav i kunde-/casenavn når SharePoint-området og
  workspace-mappen navngis (f.eks. `Kunde AS`, `Contoso`), ikke lowercase.

### Don'ts
- (Ingen registrert ennå — legg til etter hvert som læring oppstår.)
