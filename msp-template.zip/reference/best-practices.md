# Global Best Practices

## Standard Driftsprosedyrer
* Bekreft alltid nåværende systemstatus (overvåking/alarmer) før du starter arbeid på en kundes miljø.
* Bruk minst mulig privilegier (least privilege) ved tilgang til kundesystemer.
* Dokumenter alle produksjonsendringer i changelog, uavhengig av størrelse.
* Foretrekk reversible endringer, og ha alltid en rollback-plan klar før endringer utføres.

## Sjekklistekrav ved Endringer
* [ ] Endringen er innenfor kundens definerte endringsvindu (se `admin/engagement.md`).
* [ ] Endringen er kommunisert til/godkjent av riktig kontaktperson hos kunden.
* [ ] Rollback-plan er identifisert og forstått.
* [ ] Endringen er logget i `changelog/`.
* [ ] `STATUS.md` er oppdatert etter gjennomføring.

## Generelle Sikkerhetsregler
* Ingen hemmeligheter (passord, nøkler, tokens) lagres i klartekst i dette workspacet — se `.claude/rules/safety-rules.md`.
* Alle destruktive handlinger (sletting, nedetid, restart av produksjonstjenester) krever eksplisitt godkjenning fra bruker.
* Rapporter avvik eller mistenkelig aktivitet umiddelbart.

## Kvalitetskontroll før eksport
* Kjør `customer-value-reviewer` og `writing-style-reviewer` på bekreftet innhold før
  Word-dokumentet genereres og eksportspørsmålet stilles til bruker — se CLAUDE.md →
  "Customer Value review".
