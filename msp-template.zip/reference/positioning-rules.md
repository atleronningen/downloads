# Posisjonering: Når skal spesifikke merkede produkter/tjenester navngis?

Beslutningsramme for hvor konkret man navngir Sopra Sterias merkede produkter/tjenester
(f.eks. Right*-porteføljen) i en kundevendt leveranse. Testen er **hva kunden faktisk kjøper**
— ikke hvilken mappe leveransen ligger i, og ikke om det formelt er en RFI/RFP eller ikke.

## Standard for MSP-caser

De fleste RFI/RFP-er i dette workspacet er formelle forespørsler om en konkret
produktifisert/driftet tjeneste. Kunden forventer konkrete, ansvarlige svar om hva de vil
drifte — navngi det spesifikke Right*-produktet direkte, anker i `service-catalog`-skillen.
Dette er utgangspunktet for et RFI/RFP-svar med mindre et av punktene under gjør seg
gjeldende for deler av svaret.

## Beslutningstre for avvik fra standarden

1. **Rådgivnings-/analysedel av en RFP** (mulighetsstudie, kartlegging, utredning som del av
   en ellers driftsrettet anskaffelse) — hold deg på referansearkitektur-/metodikk-nivå for
   akkurat den delen. Ikke navngi spesifikke produkter der leveransen er studien/analysen i
   seg selv, ikke et produkt — å navngi et spesifikt produkt kan direkte motsi et løfte om
   teknologi-/leverandøragnostisk tilnærming.

2. **Team-/bemanningsdel av en RFP** (navngitte roller/FTE-er) — samme som punkt 1, selv når
   resten av anskaffelsen formelt er pakket som en driftsavtale. Testen er om kunden for den
   delen kjøper et team med navngitte roller og kompetanse, eller en pakketert/merket tjeneste.

3. **Blandet RFP** (driftsdel + rådgivnings-/bemanningsdel i samme dokument) — behandle hver
   del for seg etter testen over. Ikke la produktnavngiving i driftsdelen smitte over på
   rådgivnings-/bemanningsdelen, og omvendt.

## Praktisk sjekk

Spør, per del av leveransen: **kjøper kunden en driftet tjeneste, en studie, eller et team?**
- Driftet tjeneste/pakketert produkt → navngi produktet direkte.
- Studie eller team → referansearkitektur-nivå, ingen produktnavngiving.

Logg avgjørelsen og begrunnelsen i casens `memory.md`, slik at neste lignende case slipper å
ta stilling til det fra scratch.
