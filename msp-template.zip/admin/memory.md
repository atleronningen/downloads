# Memory — <kundenavn> / <casenavn>

Working memory for denne casen: gjenbrukbar kunnskap som er relevant mens denne casen pågår.
Case-fremdrift (hva som er sendt, hva som er åpent, hva som gjenstår) hører hjemme i
`STATUS.md`, ikke her.

**Denne filen er case-scoped, ikke delt med andre caser.** Den er arbeidsminne for denne
casen så lenge den pågår.

## Win themes library

Strategiske budskap brukt i denne casen og hvordan de landet.

## Product mapping corrections

Tilfeller hvor et Right*-produkt først ble antatt, men riktig passform viste seg å være noe
annet.

| Requirement pattern | Auto-suggested | Better fit | Why |
|---|---|---|---|
| | | | |

## Process lessons

Læring om selve tilbudsprosessen, ikke om kunden.

## Customer facts worth remembering

Varige fakta om kunden (ikke case-status) som er verdt å vite ved et fremtidig bid.
