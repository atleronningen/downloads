# Engagement: <kundenavn> — <casenavn>

## Status
* **Fase:** Prospekt / tilbudsarbeid (RFI/RFP) — ingen signert driftsavtale, dette er Managed Services-tilbudsprosess.

## Utfordring
* <Kundens kjerneproblem/situasjon, 2–3 setninger>

## Mål med leveransen
* <Hva suksess ser ut som for kunden>

## Scope for tilbudet
* <Fylles inn basert på RFI/RFP-dokument>

## Frist
* <Tilbudsfrist fylles inn når RFI/RFP-dokument er mottatt>

## Hovedkontakter
| Rolle | Navn | Kontaktinfo |
|---|---|---|
| Teknisk/innkjøpskontakt (kunde) | <Navn> | <e-post> |
| Beslutningstaker (kunde) | <Navn> | <e-post> |
| Ansvarlig konsulent (oss) | <Navn> | <e-post> |
