# CLAUDE.md - Managed Services Case Workspace

Dette workspacet er malbasert (kopiert fra `msp-template`) og representerer ÉN case for ÉN
kunde — ikke et delt repo med flere kunder. Se `KOM-I-GANG.md` for hvordan du kobler deg til
dette workspacet via SharePoint/OneDrive og Claude Cowork, og for do's/don'ts ved samhandling
med andre i teamet.

## 1. Førstegangsoppsett

Hvis brukerens første melding i en fersk sesjon uttrykker at casen nettopp er satt opp (f.eks.
"Ny case satt opp for første gang", eller lignende — tolk intensjonen, ikke krev en eksakt
frase), gjør følgende før noe annet:

1. Spør om **kundenavn** og **casenavn**.
2. Fyll ut placeholders i `admin/engagement.md` (fase/scope/frist/kontakter), `admin/rules.md`,
   `STATUS.md` og tittelen i `admin/memory.md` med det du får oppgitt — ikke gjett på
   informasjon du ikke har fått.
3. Gi Word-filen (`Sopra Steria template.docx`) et beskrivende filnavn ved å endre selve
   filnavnet (ikke SharePoint sin visningsnavn-metadata), f.eks. `<Kunde> - <Case>.docx`.
4. Opprett mappene `admin/`, `Customers request/`, `Meeting notes/` og `changelog/` dersom de
   ikke finnes fra før. De kan stå tomme; de fylles etter hvert som casen krever det.
5. Sjekk om `## Lokalt oppsett`-seksjonen (se punkt 5 under) trengs — spør brukeren om deres
   lokale klone av `service-catalog` ligger på standardstien, hvis casen ser ut til å trenge
   tjenestekatalogen tidlig.
6. Gå videre til normal sesjonsstart (punkt 2 under) med de nå utfylte filene.

## 2. Normal sesjonsstart

Når casen allerede er satt opp fra før:

1. Les `reference/best-practices.md` og `reference/incident-rules.md` (global kontekst arvet
   fra malen).
2. Les `admin/engagement.md` (kundetilpasning, scope & frister) og `admin/rules.md`
   (kundespesifikke instrukser/begrensninger).
3. Les `STATUS.md` (nåværende status for casen).
4. Les `admin/ACTIVITY.md` (betydelige beslutninger denne casen: endret omfang, metode, retning
   eller leveranse — se `.claude/rules/memory-protocol.md`).
5. Les de 2 seneste loggene under `changelog/`.
6. Les `admin/memory.md` (case-scoped læring samlet så langt).
7. Oppsummer kort status og vent på instrukser.

## 3. Avslutningsrutine

Når økten avsluttes (eller bruker sier "avslutt økt" / "oppdater status"):

1. Følg retningslinjene i `.claude/rules/memory-protocol.md` nøye.
2. Har noe i økten endret omfang, metode, retning eller leveranse: legg det til i
   `admin/ACTIVITY.md` i det øyeblikket det skjer, ikke bare samlet ved avslutning.
3. Opprett ny øktslogg i `changelog/` — bruk `.claude/skills/create-changelog.sh <initialer>`.
4. Oppdater `STATUS.md` dersom fremdrift, åpne spørsmål eller beslutninger er endret.

## 4. Retningslinjer & Sikkerhet

* Se `.claude/rules/safety-rules.md` for regler vedrørende endringsvinduer, hemmeligheter og
  deling/tilgang.

## 5. Lokalt oppsett

* **service-catalog-klone:** `.claude/skills/service-catalog` og `.claude/rules/dps-contract-access.md`
  forventer en lokal git-klone av `service-catalog`-repoet på `~/AI-teamwork/service-catalog`
  (utenfor enhver OneDrive/SharePoint-synk). Hvis din klone ligger et annet sted på denne
  maskinen, noter faktisk sti her:
  * <Lokal sti til service-catalog-klonen, hvis den avviker fra standard>

## 6. Hvordan jobbe med caser (RFI/RFP)

* **Skills tilgjengelig for case-arbeid** (i `.claude/skills/`):
  - **rfi-triage** — rask 2-minutters vurdering av en nylig mottatt RFI/RFP: språk, sektor,
    størrelse, frist og sannsynlig Right*-produktpassform. Bruk før man committer til full
    drafting.
  - **rfi-response-drafter** — full arbeidsflyt for å besvare en RFI/RFP: parse → gjennomgå
    → introduksjon → utkast & finpuss per krav → generer merkevaremessig Word-dokument.
  - **rfi-compliance-checker** — sjekker at avtalte win themes faktisk går igjen i minst 30 %
    av kravsvarene, og krysssjekker mot `admin/memory.md` sitt win themes-bibliotek.
  - **service-catalog** — slår opp fakta i tjenestekatalogen (DPS-produktporteføljen med
    Right*-produkter, SLA, leveransemodell, samt andre tjenestebeskrivelser), lest direkte fra
    en lokal klone av service-catalog-repoet (se punkt 5 over). Bruk automatisk når et krav
    trenger produkt-/tjenestedetaljer — ikke bare når det eksplisitt blir bedt om. Friskhet på
    den lokale klonen sjekkes automatisk per `.claude/rules/dps-contract-access.md` før oppslag.

* **Posisjonering:** Før du avgjør hvor konkret du navngir spesifikke merkede produkter/
  tjenester i en leveranse, les `reference/positioning-rules.md`.

* **Customer Value review:** Før et kundevendt dokument genereres endelig, kjør
  `customer-value-reviewer`-agenten og vis funnene til brukeren før godkjenning bes om.

* **Writing Style review:** Samtidig med Customer Value review, kjør
  `writing-style-reviewer`-agenten på samme innhold og vis funnene til brukeren før
  godkjenning bes om.

* **Skrivestil:** Les `.claude/rules/writing-style.md` (og `.claude/customer-value/writing-style-core.md`
  den peker til) før kundevendt innhold skrives, og etterlev reglene der uten å bli minnet på det.

* **memory.md:** Les `admin/memory.md` før drafting starter på denne casen (win themes,
  produktmapping-korrigeringer som kan gjenbrukes så langt i casen). Oppdater den løpende med
  kunnskap som har overføringsverdi — ikke case-fremdrift (den hører hjemme i `STATUS.md`).

* **STATUS.md:** Holder løpende status for casen — oppsummering, scope/beslutninger, åpne
  spørsmål, og hvordan gjenoppta arbeidet. Oppdater den gjennom hele arbeidet med casen, ikke
  bare ved avslutning.

* **ACTIVITY.md:** Løpende, aldri omskrevet logg over betydelige beslutninger i casen — endret
  omfang, metode, retning eller leveranse (`admin/ACTIVITY.md`). Skiller seg fra `STATUS.md`
  ved at den aldri overskrives eller ryddes; den er casens historikk, ikke dens øyeblikksbilde.
  Se `.claude/rules/memory-protocol.md` for format og skille mot `STATUS.md`.

## Mappestruktur

```
<Kunde> - <Case>/
  CLAUDE.md
  STATUS.md
  Sopra Steria template.docx  (eller <Kunde> - <Case>.docx etter oppsett)
  admin/
    engagement.md
    rules.md
    memory.md
    ACTIVITY.md
  Customers request/
  Meeting notes/
  changelog/
  reference/
  .claude/
```

`admin/` samler strukturfilene som styrer casens historikk og Claudes oppførsel, men som
sjelden trengs som førstelesning for noen som kobler seg på casen — `engagement.md`, `rules.md`,
`memory.md` og `ACTIVITY.md`. Egnet til å gi snevrere SharePoint-redigeringstilgang enn resten
av arbeidsområdet, se `KOM-I-GANG.md` Del E. `STATUS.md` blir stående i roten, siden den er
casens "les dette først"-fil.

`Customers request/` er dropbox for kundens eget materiale (RFI/RFP/ITT, briefing, synopsis).
`Meeting notes/` er løpende møtenotater, ett filnavn per møte med ISO-datoprefiks
(f.eks. `2026-08-06_kickoff.md`), slik at de sorterer kronologisk. Destiller beslutninger og
resonnement som betyr noe inn i `STATUS.md`, i stedet for at de blir liggende begravd i et
møtenotat.
