# Managed Services Case Workspace — mal

Dette er `msp-template`: malen enhver ny case kopieres fra. Mappen representerer ikke én
case i seg selv — den er utgangspunktet du kopierer til et nytt SharePoint-område per
kunde/case. Se `KOM-I-GANG.md` for hvordan du kobler en ny eller eksisterende case til Claude
Cowork, og for do's/don'ts ved samhandling med andre i teamet.

## Start her

- **Setter du opp en ny case fra denne malen?** Gå til `KOM-I-GANG.md`, Del A0.
- **Kobler du deg på en case noen andre allerede har satt opp?** Gå til `KOM-I-GANG.md`, Del A.
- **Jobber du i en case som allerede er i gang?** Les `STATUS.md`, deretter `admin/ACTIVITY.md`,
  i den kopierte case-mappen (malen selv har ingen case-status å lese).
- **Skal du besvare en RFI/RFP?** Les `CLAUDE.md`, avsnitt 6 — om rfi-skillene, service-catalog,
  og review-porten (Customer Value + Writing Style).

## Hvordan filene henger sammen

| Fil/mappe | Hva det er |
|---|---|
| `CLAUDE.md` | Instruksjoner til Claude: oppsett, sesjonsrutiner, hvordan man jobber med caser. Leses av Claude ved øktstart, ikke ment som førstelesning for mennesker. |
| `KOM-I-GANG.md` | Onboarding for mennesker: hvordan koble til SharePoint/OneDrive og Cowork, forutsetninger for samarbeid i team, do's og don'ts. |
| `STATUS.md` | Nåsituasjonen i casen: oppsummering, scope/beslutninger, åpne spørsmål, hvordan gjenoppta arbeidet. |
| `Sopra Steria template.docx` | Word-mal for leveransen. Får et beskrivende filnavn ved oppsett. |
| `admin/` | Strukturfiler som styrer casens historikk og Claudes oppførsel, men ikke er ment som førstelesning — egnet til snevrere SharePoint-tilgang enn resten (se `KOM-I-GANG.md` Del E). |
| `admin/engagement.md` | Kundetilpasning: fase, utfordring, mål, scope for tilbudet, frist, kontakter. Fylles ut ved oppsett (`CLAUDE.md` §1). |
| `admin/rules.md` | Kundespesifikke regler og begrensninger, lagt til etter hvert som de oppstår. |
| `admin/ACTIVITY.md` | Løpende logg over betydelige endringer (omfang, metode, retning, leveranse). Skrives aldri om eller ryddes opp i. |
| `admin/memory.md` | Case-scoped arbeidsminne: gjenbrukbar kunnskap mens denne casen pågår (win themes, produktmapping-korrigeringer, læring) — ikke case-fremdrift. |
| `Customers request/` | Dropbox for kundens eget materiale (RFI/RFP/ITT, briefing, synopsis). |
| `Meeting notes/` | Løpende møtenotater, ett filnavn per møte med ISO-datoprefiks, f.eks. `2026-08-06_kickoff.md`. |
| `changelog/` | Én loggfil per økt, opprettet med `.claude/skills/create-changelog.sh <initialer>`. |
| `reference/` | Global kontekst arvet fra malen: beste praksis, hendelseslæring, posisjoneringsregler, diagram av multi-bruker-flyten. |
| `.claude/` | Reviewere (Customer Value, Writing Style), skriveregler, tjenestekatalog-tilgangsregel og RFI-skillene (triage, drafter, compliance checker, service-catalog). Endres sjelden, og aldri midt i en case uten å varsle teamet. |

## Regler som gjelder overalt

- Denne mappen er malen, ikke en case. Legg aldri casespesifikt innhold her — kopier mappen
  til et nytt SharePoint-område først (`KOM-I-GANG.md`, Del A0).
- I en kopiert case-mappe holdes roten til filene i tabellen over pluss de fem mappene under
  den (inkludert `admin/`). Ingen ad-hoc-filer i roten.
- `STATUS.md`, `admin/ACTIVITY.md`, `admin/engagement.md` og `admin/rules.md` redigeres av én
  person om gangen — se `KOM-I-GANG.md`, Del D.
- Betydelige endringer logges i `admin/ACTIVITY.md` i det øyeblikket de skjer, ikke bare ved
  øktslutt.
- Kundevendt innhold går gjennom `customer-value-reviewer` og `writing-style-reviewer` før
  brukeren spørres om godkjenning.
