#!/usr/bin/env python3
"""
parse_rfi.py — Extract requirements/questions from an RFI document.

Supports both .docx and .pdf files.

Handles multiple RFI formats:
- Q&A heading-based: Questions are headings (e.g. Nortura style)
- Q&A table-based: Questions in table cells marked "KUNDENS SPØRSMÅL" or similar
- Scope document: Descriptive sections with implicit requirements (e.g. TenneT style)
- Mixed: Combination of the above

Usage:
    python3 parse_rfi.py --file rfi_document.docx --output requirements.json
    python3 parse_rfi.py --file rfi_document.pdf --output requirements.json
    python3 parse_rfi.py --file rfi.pdf --output reqs.json --product-index index.json

Output: JSON with extracted requirements, customer context, and optional product suggestions.
"""

import argparse, json, sys, re
from pathlib import Path

def ensure_docx():
    try:
        from docx import Document; return Document
    except ImportError:
        import subprocess; subprocess.check_call([sys.executable, "-m", "pip", "install", "python-docx", "--break-system-packages", "-q"])
        from docx import Document; return Document

def ensure_pdfplumber():
    try:
        import pdfplumber; return pdfplumber
    except ImportError:
        import subprocess; subprocess.check_call([sys.executable, "-m", "pip", "install", "pdfplumber", "--break-system-packages", "-q"])
        import pdfplumber; return pdfplumber

# ---- PDF extraction ----

def extract_text_from_pdf(file_path):
    pdfplumber = ensure_pdfplumber()
    paragraphs = []
    with pdfplumber.open(file_path) as pdf:
        for page_num, page in enumerate(pdf.pages, 1):
            words = page.extract_words(extra_attrs=["fontname", "size"])
            if not words: continue
            lines, current_line = [], [words[0]]
            for w in words[1:]:
                if abs(w["top"] - current_line[-1]["top"]) < 3:
                    current_line.append(w)
                else:
                    lines.append(current_line); current_line = [w]
            lines.append(current_line)
            all_sizes = sorted([w["size"] for w in words if w["text"].strip()])
            if not all_sizes: continue
            median_size = all_sizes[len(all_sizes) // 2]
            for line_words in lines:
                text = " ".join(w["text"] for w in line_words).strip()
                if not text: continue
                avg_size = sum(w["size"] for w in line_words) / len(line_words)
                is_bold = any("bold" in w.get("fontname", "").lower() for w in line_words)
                if avg_size > median_size * 1.4: style = "Heading 1"
                elif avg_size > median_size * 1.15 or (avg_size > median_size * 1.05 and is_bold): style = "Heading 2"
                elif is_bold and len(text) < 100: style = "Heading 3"
                else: style = "Normal"
                paragraphs.append({"text": text, "style": style, "page": page_num})
            for table in (page.extract_tables() or []):
                for row in table:
                    for cell in (row or []):
                        if cell and cell.strip():
                            paragraphs.append({"text": cell.strip(), "style": "Table Cell", "page": page_num})
    return paragraphs


def extract_structured_tables_from_pdf(file_path):
    """Extract tables from PDF preserving row/column structure.
    
    Returns a list of table objects compatible with the docx table question extractor,
    where each table is a list of rows, and each row is a list of cell strings.
    """
    pdfplumber = ensure_pdfplumber()
    tables = []
    with pdfplumber.open(file_path) as pdf:
        for page_num, page in enumerate(pdf.pages, 1):
            page_tables = page.extract_tables() or []
            for raw_table in page_tables:
                if not raw_table or len(raw_table) < 2:
                    continue
                # Clean cells: replace None with empty string, strip whitespace
                cleaned = []
                for row in raw_table:
                    if row is None:
                        continue
                    cleaned_row = [(cell.strip() if cell else "") for cell in row]
                    # Skip completely empty rows
                    if any(c for c in cleaned_row):
                        cleaned.append(cleaned_row)
                if len(cleaned) >= 2:
                    tables.append({
                        "rows": cleaned,
                        "page": page_num,
                        "num_cols": max(len(r) for r in cleaned),
                    })
    return tables


def extract_table_questions_pdf(pdf_tables):
    """Extract questions from structured PDF tables.
    
    Handles common table-based RFI patterns in PDFs:
    1. Header row with question/requirement column, followed by data rows
    2. Two-column tables with question + answer space
    3. Multi-column tables with ID, question, and response columns
    """
    questions = []
    q_markers = ["question", "requirement", "krav", "spørsmål", "scope", "description",
                 "criteria", "ask", "need", "behov", "omfang"]
    id_markers = ["id", "ref", "no.", "nr.", "#", "number", "nummer"]
    
    for t_idx, table_info in enumerate(pdf_tables):
        rows = table_info["rows"]
        page = table_info["page"]
        
        if len(rows) < 2:
            continue
        
        header = rows[0]
        header_lower = [h.lower() for h in header]
        
        # Find the question column and optional ID column
        q_col = None
        id_col = None
        for col_idx, h in enumerate(header_lower):
            if any(m in h for m in q_markers) and q_col is None:
                q_col = col_idx
            if any(m in h for m in id_markers) and id_col is None:
                id_col = col_idx
        
        if q_col is not None:
            # Header-identified table: extract questions from the identified column
            for r_idx, row in enumerate(rows[1:], 1):
                if q_col < len(row):
                    q_text = row[q_col].strip()
                    if q_text and len(q_text) > 15:
                        req_id = row[id_col].strip() if id_col is not None and id_col < len(row) else ""
                        source = f"PDF Table {t_idx+1}, Page {page}, Row {r_idx}"
                        if req_id:
                            source += f" (ID: {req_id})"
                        questions.append({
                            "type": "pdf_table_question",
                            "source": source,
                            "text": q_text,
                            "req_id": req_id,
                        })
        else:
            # No clear header — try heuristic: if first column looks like IDs and
            # second column has long text, treat column 2 as questions
            if len(header) >= 2:
                col1_avg_len = sum(len(r[0]) for r in rows if r[0]) / max(len(rows), 1)
                col2_avg_len = sum(len(r[1]) if len(r) > 1 else 0 for r in rows) / max(len(rows), 1)
                
                if col1_avg_len < 15 and col2_avg_len > 30:
                    # Likely ID + question pattern
                    for r_idx, row in enumerate(rows[1:], 1):
                        if len(row) >= 2 and row[1].strip() and len(row[1].strip()) > 20:
                            questions.append({
                                "type": "pdf_table_question",
                                "source": f"PDF Table {t_idx+1}, Page {page}, Row {r_idx}",
                                "text": row[1].strip(),
                                "req_id": row[0].strip(),
                            })
    
    return questions

# ---- Unified paragraph interface ----

def load_document(file_path):
    file_path = Path(file_path); ext = file_path.suffix.lower()
    if ext == ".pdf":
        raw = extract_text_from_pdf(file_path)
        pdf_tables = extract_structured_tables_from_pdf(file_path)
        return [{"text": p["text"], "style": p["style"], "index": i, "source": f"Page {p['page']}"} for i, p in enumerate(raw)], pdf_tables, "pdf"
    elif ext in (".docx", ".doc"):
        Document = ensure_docx(); doc = Document(file_path)
        return [{"text": p.text.strip(), "style": p.style.name if p.style else "Normal", "index": i, "source": f"Paragraph {i}"} for i, p in enumerate(doc.paragraphs)], doc.tables, "docx"
    else:
        raise ValueError(f"Unsupported file type: {ext}. Use .docx or .pdf")

# ---- Customer context extraction ----

def extract_customer_context(paragraphs):
    context = {"company_name": None, "industry": None, "employee_count": None, "goals": [], "situation_summary": [], "document_purpose": None}
    industry_map = {"energy": ["energy", "electricity", "grid", "power", "tso", "transmission"], "financial_services": ["bank", "finance", "insurance"], "public_sector": ["municipality", "kommune", "government"], "oil_gas": ["oil", "gas", "petroleum", "offshore"], "transport": ["railway", "transport"], "telecom": ["telecom", "telco", "mobile network"], "research": ["research", "university", "institute"]}
    goal_keywords = ["goal", "objective", "ambition", "strategy", "north star", "mål", "strategi", "ambisjon", "vision"]

    for p in paragraphs:
        text, text_lower = p["text"], p["text"].lower()
        if not context["company_name"]:
            m = re.search(r"(?:about|om)\s+(.+?)(?:\s*$|\s+\d)", text, re.IGNORECASE)
            if m: context["company_name"] = m.group(1).strip()
        if not context["employee_count"]:
            m = re.search(r"(\d[\d,.]+)\s*(?:employees|fte|staff|medarbeidere|ansatte)", text_lower)
            if m: context["employee_count"] = m.group(1).replace(",", "").replace(".", "")
        if ("purpose" in text_lower or "formål" in text_lower or "objective" in text_lower) and len(text) > 50:
            context["document_purpose"] = text[:500]
        if any(kw in text_lower for kw in goal_keywords) and len(text) > 30:
            context["goals"].append(text[:300])
        if not context["industry"]:
            for ind, kws in industry_map.items():
                if any(kw in text_lower for kw in kws): context["industry"] = ind; break
    context["goals"] = context["goals"][:5]
    return context

# ---- Q&A extraction ----

def extract_table_questions_docx(tables):
    questions = []
    markers = ["kundens spørsmål", "customer question", "customer's question", "requirement", "krav", "spørsmål", "question"]
    for t_idx, table in enumerate(tables):
        for r_idx, row in enumerate(table.rows):
            for c_idx, cell in enumerate(row.cells):
                ct = cell.text.strip(); cl = ct.lower(); is_m = any(m in cl for m in markers)
                if is_m and len(ct) < 50 and r_idx + 1 < len(table.rows):
                    qt = table.rows[r_idx + 1].cells[c_idx].text.strip()
                    if qt and len(qt) > 10: questions.append({"type": "table_question", "source": f"Table {t_idx}, Row {r_idx+1}", "text": qt})
                elif is_m and len(ct) > 50:
                    questions.append({"type": "table_question", "source": f"Table {t_idx}, Row {r_idx}", "text": ct})
    return questions

def extract_heading_questions(paragraphs):
    questions = []
    q_ind = ["?", "describe", "how", "what", "which", "explain", "beskriv", "hvordan", "hva", "hvilke", "forklar", "proposed", "foreslå"]
    for p in paragraphs:
        style, text = p["style"].lower(), p["text"]
        if not text or not any(h in style for h in ["heading 2", "heading 3", "heading 4"]): continue
        if any(ind in text.lower() for ind in q_ind):
            questions.append({"type": "heading_question", "source": p["source"], "text": text, "para_idx": p["index"]})
    return questions

def extract_freetext_questions(paragraphs):
    """Extract questions from any paragraph style — catches questions in custom styles
    like 'Document Status', 'Body text', etc. that the heading extractor misses.
    
    Uses numbered question patterns (e.g. '2.1.1.', 'Q1:', '1)') and question marks
    to find questions regardless of style.
    """
    questions = []
    # Pattern: starts with a numbering scheme (2.1.1., Q1:, 1), a), etc.)
    numbered_pattern = re.compile(r'^(\d+\.[\d.]+\.?|[Qq]\d+[.:]|[a-z]\)|●)\s*(.+)')
    
    for p in paragraphs:
        text = p["text"]
        if not text or len(text) < 20: continue
        style = p["style"].lower()
        
        # Skip headings (already caught), TOC entries, and very short text
        if any(h in style for h in ["heading", "toc", "title", "subtitle"]): continue
        
        text_lower = text.lower()
        is_question = "?" in text
        has_number = numbered_pattern.match(text)
        has_q_verb = any(v in text_lower for v in [
            "please describe", "please provide", "please explain", "please share",
            "what is your", "what are your", "how would you", "how do you", "how can your",
            "which scope", "which lot", "can you give", "can you share", "do you have",
            "what does your", "what delivery", "what is your advice", "what is your opinion",
            "we would like to get", "we are interested in",
            "beskriv", "forklar", "hvilke", "hvordan vil",
        ])
        
        if is_question and (has_number or has_q_verb):
            questions.append({
                "type": "freetext_question",
                "source": p["source"],
                "text": text,
                "para_idx": p["index"],
                "style_name": p["style"],
            })
        elif has_number and has_q_verb and len(text) > 40:
            questions.append({
                "type": "freetext_question",
                "source": p["source"],
                "text": text,
                "para_idx": p["index"],
                "style_name": p["style"],
            })
    
    return questions


def categorize_requirement(req):
    """Tag a requirement with a category to guide tone and guardrails.
    
    Categories:
    - scope: technical/functional requirements about what to deliver
    - commercial: pricing, costs, commercial models
    - procedural: tender process, evaluation criteria, timelines
    - reference: case studies, experience, certifications
    - risk: risks, concerns, challenges
    - transition: transition approach, implementation
    """
    text_lower = (req.get("text", "") + " " + req.get("body_summary", "")).lower()
    
    commercial_kw = ["price", "pricing", "cost", "bandwidth", "budget", "commercial",
                     "transition costs", "yearly costs", "pris", "kostnad", "honorar"]
    procedural_kw = ["tender", "procedure", "criteria", "awarding", "selection", "suitability",
                     "bafo", "negotiation", "phase", "anbud", "evaluering", "tildelingskriterier"]
    reference_kw = ["reference", "case study", "example", "experience", "certification",
                    "industry", "sector", "referanse", "erfaring", "sertifisering"]
    risk_kw = ["risk", "concern", "challenge", "mitigation", "risiko", "bekymring"]
    transition_kw = ["transition", "migration", "implementation", "onboarding", "transfer",
                     "transisjon", "migrering", "etablering", "overgang"]
    
    if any(kw in text_lower for kw in commercial_kw):
        return "commercial"
    elif any(kw in text_lower for kw in risk_kw):
        return "risk"
    elif any(kw in text_lower for kw in procedural_kw):
        return "procedural"
    elif any(kw in text_lower for kw in reference_kw):
        return "reference"
    elif any(kw in text_lower for kw in risk_kw):
        return "risk"
    elif any(kw in text_lower for kw in transition_kw):
        return "transition"
    else:
        return "scope"

# ---- Scope document extraction ----

def extract_scope_sections(paragraphs):
    sections = []; h1 = None; h2 = None; body = []
    skip = ["document information", "document history", "contents", "table of contents", "innholdsfortegnelse", "version", "copyright", "disclaimer"]

    def save():
        if h2 and body:
            sections.append({"type": "scope_section", "heading": h2, "parent_heading": h1,
                "source": f"Section: {h1} > {h2}" if h1 else f"Section: {h2}",
                "body_text": " ".join(body)[:500], "word_count": sum(len(b.split()) for b in body)})

    for p in paragraphs:
        style, text = p["style"].lower(), p["text"]
        if not text: continue
        if "heading 1" in style:
            save(); h1 = text; h2 = None; body = []
        elif "heading 2" in style or "heading 3" in style:
            save(); h2 = text; body = []
        elif ("normal" in style or "table cell" in style) and len(text) > 20:
            body.append(text)
    save()
    return [s for s in sections if not any(sk in s["heading"].lower() for sk in skip) and s["word_count"] > 30]

# ---- Product matching ----

# Capability tag patterns — used to tag both product sections and requirements
_TAG_PATTERNS = {
    "cloud": ["cloud", "azure", "aws", "gcp", "iaas", "paas", "saas", "hybrid cloud", "multi-cloud"],
    "workplace": ["workplace", "end-user", "end user", "laptop", "desktop", "device", "vdi", "digital workplace"],
    "identity": ["identity", "access management", "iam", "iga", "entra", "active directory", "sso", "mfa", "privileged"],
    "security": ["security", "soc", "siem", "soar", "threat", "vulnerability", "cyber", "zero trust", "penetration", "endpoint detection"],
    "network": ["network", "lan", "wan", "wifi", "wlan", "sd-wan", "firewall", "connectivity", "routing", "switching"],
    "monitoring": ["monitoring", "observability", "alerting", "aiops", "dashboar", "event correlation", "log management"],
    "service_management": ["itsm", "itil", "servicenow", "siam", "service integration", "service desk", "incident", "problem", "change management"],
    "application": ["application management", "application operations", "application lifecycle", "devops", "ci/cd", "containeriz"],
    "collaboration": ["microsoft 365", "m365", "teams", "sharepoint", "copilot", "exchange", "onedrive", "collaboration"],
    "finops": ["finops", "cost optimi", "cost management", "license", "rightsiz", "cloud spend", "tbm"],
    "automation": ["automat", "self-service", "self service", "chatbot", "ai-driven", "ai-powered", "robotic", "rpa"],
    "governance": ["governance", "compliance", "audit", "risk management", "iso 27001", "isae", "gdpr", "nis2"],
    "transition": ["transition", "migration", "onboarding", "establishment", "navigator", "cmo", "tmo", "fmo"],
    "printing": ["print", "printing", "printer", "mps", "managed print"],
    "database": ["database", "sql", "oracle", "postgresql", "mysql", "db2", "data platform"],
    "backup": ["backup", "recovery", "disaster recovery", "business continuity", "dr", "archiv"],
    "service_desk": ["service desk", "servicedesk", "helpdesk", "help desk", "support", "first line", "second line", "l1", "l2"],
}

def _extract_req_tags(text):
    """Extract capability tags from requirement text (mirrors parse_catalog.extract_capability_tags)."""
    text_lower = text.lower()
    return [tag for tag, patterns in _TAG_PATTERNS.items() if any(p in text_lower for p in patterns)]

# Hardcoded keyword boost — domain knowledge fallback for when the index
# doesn't have rich enough content (e.g. very short sections)
_FALLBACK_KW_MAP = {
    "MS01": ["cloud", "azure", "aws", "infrastructure", "iaas", "paas", "hybrid", "server",
             "compute", "storage", "backup", "datacenter", "data center", "kubernetes", "terraform",
             "container", "virtual machine", "vm", "hypervisor"],
    "MS02": ["workplace", "end user", "end-user", "device", "client", "laptop", "desktop",
             "mobile", "m365", "microsoft 365", "intune", "service desk", "servicedesk",
             "helpdesk", "on-site", "onsite", "print", "hardware", "vdi", "citrix",
             "virtual desktop", "application packaging", "collaboration", "teams", "sharepoint",
             "copilot", "viva", "autopilot", "endpoint", "windows"],
    "MS03": ["application management", "application operations", "application lifecycle",
             "applikasjon", "software lifecycle", "am/ao", "devops"],
    "MS04": ["security", "sikkerhet", "soc", "siem", "soar", "threat", "vulnerability",
             "penetration", "cyber", "incident response", "zero trust", "endpoint detection",
             "devsecops", "security operations"],
    "MS05": ["siam", "service integration", "service management", "itsm", "itil", "esm",
             "servicenow", "topdesk", "supplier management", "multi-vendor", "prime vendor"],
    "MS06": ["network", "nettverk", "lan", "wan", "wlan", "wifi", "sd-wan", "connectivity",
             "firewall", "switch", "routing", "load balancer"],
    "MS07": ["database", "db", "sql", "oracle", "postgresql", "mysql", "middleware",
             "integration platform", "api gateway", "data platform"],
    "MS08": ["monitoring", "overvåking", "observability", "dashboard", "alerting", "aiops",
             "event correlation", "log management", "synthetic monitoring"],
    "MS09": ["identity", "identitet", "access", "tilgang", "iam", "iga", "entra",
             "active directory", "privileged", "pam", "mfa", "sso", "federation"],
    "MS10": ["finops", "cost management", "cloud spend", "optimization", "license management",
             "rightsizing", "tbm", "technology business management", "cost transparency"],
}


def _tokenize(text):
    """Tokenize text for matching — lowercased words + bigrams."""
    import re
    text_lower = text.lower()
    tokens = re.findall(r'[a-zA-Z0-9][\w.-]*[a-zA-Z0-9]|[a-zA-Z0-9]', text_lower)
    bigrams = [f"{tokens[i]} {tokens[i+1]}" for i in range(len(tokens)-1)]
    return set(tokens + bigrams), text_lower


def suggest_products(text, product_index):
    """Score and rank product matches for a requirement text.
    
    Uses three matching strategies, combined into a weighted score:
    1. Capability tag overlap (broad category match)
    2. Keyword overlap (auto-extracted from catalog content)
    3. Fallback keyword boost (hardcoded domain knowledge)
    
    Returns products sorted by score, with score >= threshold.
    """
    if not product_index:
        return []
    
    req_tokens, req_lower = _tokenize(text)
    products = product_index.get("products", [])
    
    # Group products by top-level code for scoring
    # Score at top-level (MS01, MS02...) but also track best sub-product
    top_level_scores = {}  # code -> {score, product_entry, sub_matches}
    
    for prod in products:
        code = prod.get("product_code", "")
        top_code = code[:4] if len(code) >= 4 else code
        
        score = 0
        match_reasons = []
        
        # Strategy 1: Capability tag overlap
        prod_tags = set(prod.get("capability_tags", []))
        # Derive requirement tags using lightweight inline check
        req_tags = set(_extract_req_tags(text))
        tag_overlap = prod_tags & req_tags
        if tag_overlap:
            score += len(tag_overlap) * 5
            match_reasons.append(f"tags:{','.join(tag_overlap)}")
        
        # Strategy 2: Keyword overlap with the enriched index
        prod_keywords = set(prod.get("keywords", []))
        keyword_overlap = req_tokens & prod_keywords
        if keyword_overlap:
            # Weight by keyword scores from the index
            kw_scores = prod.get("keyword_scores", {})
            for kw in keyword_overlap:
                score += kw_scores.get(kw, 1)
            match_reasons.append(f"kw:{len(keyword_overlap)}")
        
        # Strategy 3: Fallback hardcoded keywords (boost)
        fallback_kws = _FALLBACK_KW_MAP.get(top_code, [])
        fallback_hits = sum(1 for kw in fallback_kws if kw in req_lower)
        if fallback_hits:
            score += fallback_hits * 2
            match_reasons.append(f"fallback:{fallback_hits}")
        
        # Accumulate into top-level group
        if top_code not in top_level_scores:
            top_level_scores[top_code] = {
                "score": 0,
                "product_entry": None,
                "sub_matches": [],
                "match_reasons": [],
            }
        
        entry = top_level_scores[top_code]
        entry["score"] += score
        entry["match_reasons"].extend(match_reasons)
        
        # Track the top-level product entry vs sub-products
        is_top_level = len(code) <= 4
        if is_top_level:
            entry["product_entry"] = prod
        elif score > 0:
            entry["sub_matches"].append({
                "code": code,
                "name": prod.get("product_name", prod.get("heading", code)),
                "score": score,
            })
    
    # Build ranked results
    threshold = 6  # Minimum score to be included (filters weak single-tag matches)
    results = []
    for top_code, data in sorted(top_level_scores.items(), key=lambda x: -x[1]["score"]):
        if data["score"] < threshold:
            continue
        prod = data["product_entry"]
        if not prod:
            continue
        
        result = {
            "code": prod.get("product_code", top_code),
            "name": prod.get("product_name", prod.get("heading", top_code)),
            "summary": prod.get("summary", "")[:150],
            "score": data["score"],
            "match_reasons": list(set(data["match_reasons"])),
        }
        
        # Include top sub-product matches
        if data["sub_matches"]:
            best_subs = sorted(data["sub_matches"], key=lambda x: -x["score"])[:3]
            result["sub_products"] = best_subs
        
        results.append(result)
    
    # Sort by score descending
    results.sort(key=lambda x: -x["score"])
    
    return results

# ---- Format detection ----

def detect_format(paragraphs, tables, file_type="docx"):
    q_words = ["?", "describe", "how", "what", "which", "explain", "proposed", "beskriv", "hvordan", "hva", "hvilke", "forklar", "foreslå"]
    q_h, s_h = 0, 0
    for p in paragraphs:
        style, tl = p["style"].lower(), p["text"].lower()
        if any(h in style for h in ["heading 2", "heading 3"]):
            if any(q in tl for q in q_words): q_h += 1
            elif len(p["text"]) > 10: s_h += 1
    # Count table questions based on file type
    if file_type == "pdf":
        tq = len(extract_table_questions_pdf(tables)) if tables else 0
    else:
        tq = len(extract_table_questions_docx(tables)) if tables else 0
    # Check for freetext questions (answer template pattern)
    ftq = len(extract_freetext_questions(paragraphs))
    
    if tq > 3: return "table_based"
    elif ftq > q_h and ftq > 3: return "answer_template"
    elif q_h > s_h and q_h > 2: return "heading_based"
    elif s_h > 2: return "scope_document"
    return "mixed"

def detect_language(paragraphs):
    text = " ".join(p["text"] for p in paragraphs[:50]).lower()
    no_c = sum(1 for w in ["og", "er", "det", "som", "til", "av", "med", "har", "kan", "skal", "vil", "dette"] if f" {w} " in text)
    en_c = sum(1 for w in ["the", "and", "is", "of", "to", "for", "with", "that", "this", "will", "are", "has"] if f" {w} " in text)
    return "no" if no_c > en_c * 1.5 else "en"

def extract_section_structure(paragraphs):
    secs = []
    for p in paragraphs:
        style, text = p["style"].lower(), p["text"]
        if not text: continue
        if "heading 1" in style: secs.append({"level": 1, "text": text, "para_idx": p["index"]})
        elif "heading 2" in style: secs.append({"level": 2, "text": text, "para_idx": p["index"]})
    return secs

# ---- Lot / tower detection ----

def detect_lots(paragraphs, section_structure):
    """Detect lot/tower structure in the RFI document.
    
    Looks for patterns like:
    - "Lot 1: Cloud Platform" / "Lot 2 – Digital Workplace"
    - "Tower A: Infrastructure" / "Tower 1 - Security"
    - "Scope Area 1: ..." / "Service Area: ..."
    - Norwegian: "Del 1:", "Område 1:", "Tjenesteområde:"
    
    Returns a list of detected lots with their heading positions, or empty list
    if no lot structure is detected (single-lot RFI).
    """
    lots = []
    
    # Patterns for lot/tower headings
    lot_patterns = [
        # English
        re.compile(r'^(?:Lot|Tower|Package|Scope\s*Area|Service\s*Area)\s*(\d+|[A-Z])\s*[:\-–]\s*(.+)', re.IGNORECASE),
        # Numbered with "lot" keyword nearby
        re.compile(r'^(\d+)\s*[.\-–:]\s*(.*(?:lot|tower|scope|service|domain).*)', re.IGNORECASE),
        # Norwegian
        re.compile(r'^(?:Del|Område|Tjenesteområde|Leveranseområde)\s*(\d+|[A-Z])\s*[:\-–]\s*(.+)', re.IGNORECASE),
    ]
    
    for s in section_structure:
        if s["level"] > 2:
            continue
        text = s["text"].strip()
        
        for pattern in lot_patterns:
            m = pattern.match(text)
            if m:
                lot_id = m.group(1).strip()
                lot_name = m.group(2).strip()
                lots.append({
                    "lot_id": f"Lot {lot_id}" if not lot_id.startswith("Lot") else lot_id,
                    "lot_name": lot_name,
                    "heading": text,
                    "para_idx": s["para_idx"],
                    "level": s["level"],
                })
                break
    
    # Also scan paragraphs for lot references in non-heading text
    # (sometimes lots are defined in a table or intro paragraph)
    if not lots:
        lot_table_pattern = re.compile(
            r'(?:Lot|Tower|Del|Område)\s+(\d+|[A-Z])\s*[:\-–]?\s*([A-Za-zÆØÅæøå][\w\s&/,.-]{3,50})',
            re.IGNORECASE
        )
        lot_refs = {}
        for p in paragraphs:
            for m in lot_table_pattern.finditer(p["text"]):
                lid = m.group(1).strip()
                lname = m.group(2).strip()
                if lid not in lot_refs:
                    lot_refs[lid] = {"lot_id": f"Lot {lid}", "lot_name": lname,
                                     "heading": m.group(0), "para_idx": p["index"], "level": 0}
        if len(lot_refs) >= 2:
            lots = sorted(lot_refs.values(), key=lambda x: x["lot_id"])
    
    return lots


def assign_requirements_to_lots(requirements, lots, section_structure, paragraphs):
    """Assign each requirement to a lot based on document position.
    
    Strategy:
    1. Requirements appearing between Lot N heading and Lot N+1 heading belong to Lot N
    2. Requirements before the first lot heading are "shared" (no lot assignment)
    3. If lot headings come from a table (level=0), use keyword matching instead of position
    
    Returns requirements with an added 'lot_id' field (None for shared requirements).
    """
    if not lots:
        # No lots detected — all requirements are unassigned
        for req in requirements:
            req["lot_id"] = None
            req["lot_name"] = None
        return requirements
    
    # Sort lots by position
    positioned_lots = [l for l in lots if l.get("level", 0) > 0]
    
    if positioned_lots:
        # Position-based assignment
        positioned_lots.sort(key=lambda x: x["para_idx"])
        
        for req in requirements:
            req_pos = req.get("para_idx", 0)
            assigned = False
            
            for i, lot in enumerate(positioned_lots):
                lot_start = lot["para_idx"]
                lot_end = positioned_lots[i + 1]["para_idx"] if i + 1 < len(positioned_lots) else 999999
                
                if lot_start <= req_pos < lot_end:
                    req["lot_id"] = lot["lot_id"]
                    req["lot_name"] = lot["lot_name"]
                    assigned = True
                    break
            
            if not assigned:
                # Before first lot — shared requirement
                req["lot_id"] = None
                req["lot_name"] = None
    else:
        # Table-based lot references — use keyword matching
        for req in requirements:
            req_text = (req.get("text", "") + " " + req.get("body_summary", "")).lower()
            best_lot = None
            best_score = 0
            
            for lot in lots:
                lot_words = [w.lower() for w in lot["lot_name"].split() if len(w) > 3]
                score = sum(1 for w in lot_words if w in req_text)
                if score > best_score:
                    best_score = score
                    best_lot = lot
            
            if best_lot and best_score >= 1:
                req["lot_id"] = best_lot["lot_id"]
                req["lot_name"] = best_lot["lot_name"]
            else:
                req["lot_id"] = None
                req["lot_name"] = None
    
    return requirements


def group_requirements_by_lot(requirements, lots):
    """Group requirements into a lot-based structure.
    
    Returns:
    {
        "shared": [requirements with no lot assignment],
        "lots": [
            {
                "lot_id": "Lot 1",
                "lot_name": "Cloud Platform",
                "requirements": [...]
            }
        ]
    }
    """
    shared = [r for r in requirements if r.get("lot_id") is None]
    
    lot_groups = []
    for lot in lots:
        lot_reqs = [r for r in requirements if r.get("lot_id") == lot["lot_id"]]
        lot_groups.append({
            "lot_id": lot["lot_id"],
            "lot_name": lot["lot_name"],
            "requirements": lot_reqs,
            "requirement_count": len(lot_reqs),
        })
    
    return {"shared": shared, "lots": lot_groups}


# ---- Main parser ----

def extract_evaluation_criteria(paragraphs):
    """Extract evaluation criteria and weightings from the RFI text.
    
    Looks for patterns like:
    - "Quality 60%, Price 40%"
    - "Kvalitet: 70%, Pris: 30%"
    - "Evaluation criteria: Technical (50%), Financial (30%), References (20%)"
    - Tables with criteria and weight columns
    
    Returns a list of {criterion, weight, raw_text} dicts.
    """
    criteria = []
    seen = set()
    
    # Pattern 1: "criterion XX%" patterns in text
    pct_pattern = re.compile(
        r'([A-Za-zÆØÅæøå][A-Za-zÆØÅæøå\s/&-]{2,30}?)\s*[:=]?\s*(\d{1,3})\s*%',
        re.IGNORECASE
    )
    # Pattern 2: "XX% criterion" patterns
    pct_prefix_pattern = re.compile(
        r'(\d{1,3})\s*%\s+([A-Za-zÆØÅæøå][A-Za-zÆØÅæøå\s/&-]{2,30})',
        re.IGNORECASE
    )
    
    # Context keywords that indicate we're in an evaluation section
    eval_context = [
        "evaluer", "criteria", "kriterier", "awarding", "tildeling", "weighting",
        "vekting", "score", "poeng", "assessment", "vurdering", "selection",
        "utvelgelse", "ranking", "rangering",
    ]
    
    for p in paragraphs:
        text = p["text"]
        text_lower = text.lower()
        
        # Only scan paragraphs that look like they're about evaluation
        is_eval_context = any(kw in text_lower for kw in eval_context)
        has_percentage = "%" in text
        
        if not (is_eval_context or has_percentage):
            continue
        
        # Try Pattern 1: "Quality 60%"
        for m in pct_pattern.finditer(text):
            criterion = m.group(1).strip().rstrip(":")
            weight = int(m.group(2))
            if 5 <= weight <= 100 and criterion.lower() not in seen:
                # Filter out noise — skip if the criterion looks like a non-criterion number
                noise = ["page", "section", "chapter", "figure", "table", "punkt",
                         "side", "avsnitt", "kapittel", "weighting", "vekting", "weight"]
                if not any(n in criterion.lower() for n in noise):
                    seen.add(criterion.lower())
                    criteria.append({
                        "criterion": criterion,
                        "weight": weight,
                        "raw_text": text[:200],
                        "source": p.get("source", ""),
                    })
        
        # Try Pattern 2: "60% Quality"
        for m in pct_prefix_pattern.finditer(text):
            weight = int(m.group(1))
            criterion = m.group(2).strip()
            if 5 <= weight <= 100 and criterion.lower() not in seen:
                noise = ["page", "section", "chapter", "figure", "table",
                         "weighting", "vekting", "weight"]
                if not any(n in criterion.lower() for n in noise):
                    seen.add(criterion.lower())
                    criteria.append({
                        "criterion": criterion,
                        "weight": weight,
                        "raw_text": text[:200],
                        "source": p.get("source", ""),
                    })
    
    # Validate: if weights sum to roughly 100, we have good data
    total_weight = sum(c["weight"] for c in criteria)
    if criteria:
        for c in criteria:
            c["total_weight_sum"] = total_weight
            c["weights_valid"] = 90 <= total_weight <= 110  # Allow rounding tolerance
    
    return criteria


def parse_rfi(file_path, product_index_path=None):
    file_path = Path(file_path)
    product_index = None
    if product_index_path:
        with open(product_index_path, "r", encoding="utf-8") as f: product_index = json.load(f)

    paragraphs, tables, file_type = load_document(file_path)
    total_words = sum(len(p["text"].split()) for p in paragraphs)
    detected_format = detect_format(paragraphs, tables, file_type)
    customer_context = extract_customer_context(paragraphs)

    requirements = []
    if detected_format == "table_based":
        if file_type == "pdf":
            requirements = extract_table_questions_pdf(tables)
        elif tables:
            requirements = extract_table_questions_docx(tables)
        for hq in extract_heading_questions(paragraphs):
            if not any(r["text"][:50] == hq["text"][:50] for r in requirements): requirements.append(hq)
    elif detected_format == "answer_template":
        # Answer template: questions are in custom/non-heading styles
        requirements = extract_freetext_questions(paragraphs)
        # Also try headings and tables
        for hq in extract_heading_questions(paragraphs):
            if not any(r["text"][:50] == hq["text"][:50] for r in requirements): requirements.append(hq)
        if file_type == "pdf":
            for tq in extract_table_questions_pdf(tables): requirements.append(tq)
        elif tables:
            for tq in extract_table_questions_docx(tables): requirements.append(tq)
    elif detected_format == "heading_based":
        requirements = extract_heading_questions(paragraphs)
        if file_type == "pdf":
            for tq in extract_table_questions_pdf(tables): requirements.append(tq)
        elif tables:
            for tq in extract_table_questions_docx(tables): requirements.append(tq)
    elif detected_format == "scope_document":
        for s in extract_scope_sections(paragraphs):
            requirements.append({"type": s["type"], "source": s["source"], "text": s["heading"], "body_summary": s["body_text"], "parent_section": s.get("parent_heading"), "word_count": s["word_count"]})
        for hq in extract_heading_questions(paragraphs):
            if not any(r["text"][:50] == hq["text"][:50] for r in requirements): requirements.append(hq)
    else:
        requirements = extract_heading_questions(paragraphs) + extract_scope_sections(paragraphs)
        if file_type == "pdf":
            for tq in extract_table_questions_pdf(tables): requirements.append(tq)
        elif tables:
            for tq in extract_table_questions_docx(tables): requirements.append(tq)

    # Fallback: if very few requirements found, try freetext extraction
    if len(requirements) < 3 and detected_format != "answer_template":
        freetext = extract_freetext_questions(paragraphs)
        for ftq in freetext:
            if not any(r["text"][:50] == ftq["text"][:50] for r in requirements):
                requirements.append(ftq)
        if freetext:
            detected_format = detected_format + "+freetext_fallback"

    # Deduplicate
    seen, deduped = set(), []
    for r in requirements:
        key = r["text"][:100].strip()
        if key not in seen: seen.add(key); deduped.append(r)
    requirements = deduped

    # Product suggestions
    if product_index:
        for req in requirements:
            search = req["text"] + " " + req.get("body_summary", "")
            req["suggested_products"] = suggest_products(search, product_index)

    # Categorize each requirement
    for req in requirements:
        req["category"] = categorize_requirement(req)

    # Extract evaluation criteria
    evaluation_criteria = extract_evaluation_criteria(paragraphs)

    # Detect lot/tower structure
    section_struct = extract_section_structure(paragraphs)
    detected_lots = detect_lots(paragraphs, section_struct)
    
    lot_structure = None
    if detected_lots:
        requirements = assign_requirements_to_lots(requirements, detected_lots, section_struct, paragraphs)
        lot_structure = group_requirements_by_lot(requirements, detected_lots)

    return {"file": file_path.name, "file_type": file_type, "total_words": total_words,
        "detected_format": detected_format, "detected_language": detect_language(paragraphs),
        "customer_context": customer_context, "section_structure": section_struct,
        "requirements": requirements, "requirement_count": len(requirements),
        "evaluation_criteria": evaluation_criteria,
        "detected_lots": detected_lots,
        "lot_structure": lot_structure}

# ---- Output formatting ----

def format_requirements_summary(result):
    lines = [f"# RFI Analysis: {result['file']}", "",
        f"File type: {result['file_type']} | Format: {result['detected_format']} | Language: {result['detected_language']} | Words: ~{result['total_words']:,} | Requirements: {result['requirement_count']}", ""]
    ctx = result.get("customer_context", {})
    if any(ctx.values()):
        lines.append("## Customer Context")
        if ctx.get("company_name"): lines.append(f"- Company: {ctx['company_name']}")
        if ctx.get("industry"): lines.append(f"- Industry: {ctx['industry']}")
        if ctx.get("employee_count"): lines.append(f"- Employees: ~{ctx['employee_count']}")
        if ctx.get("document_purpose"): lines.append(f"- Purpose: {ctx['document_purpose'][:200]}")
        if ctx.get("goals"):
            lines.append("- Goals/Strategy:")
            for g in ctx["goals"][:3]: lines.append(f"  - {g[:150]}")
        lines.append("")
    if result["section_structure"]:
        lines.append("## Document Sections")
        for s in result["section_structure"]:
            lines.append(f"{'  ' * (s['level'] - 1)}- {s['text']}")
        lines.append("")
    # Evaluation criteria
    eval_criteria = result.get("evaluation_criteria", [])
    if eval_criteria:
        lines.append("## ⚖️ Evaluation Criteria\n")
        total = eval_criteria[0].get("total_weight_sum", 0)
        valid = eval_criteria[0].get("weights_valid", False)
        for ec in eval_criteria:
            bar = "█" * (ec["weight"] // 5) + "░" * (20 - ec["weight"] // 5)
            lines.append(f"- **{ec['criterion']}**: {ec['weight']}%  {bar}")
        lines.append(f"\nTotal: {total}% {'✅ (valid)' if valid else '⚠️ (may be incomplete or noisy)'}")
        lines.append(f"\n💡 **Effort allocation tip**: Focus most drafting effort on the highest-weighted criteria.")
        lines.append("")
    # Lot structure
    lot_struct = result.get("lot_structure")
    detected_lots = result.get("detected_lots", [])
    if detected_lots:
        lines.append(f"## 📦 Lot/Tower Structure ({len(detected_lots)} lots detected)\n")
        if lot_struct:
            if lot_struct["shared"]:
                lines.append(f"**Shared (cross-lot)**: {len(lot_struct['shared'])} requirements")
            for lg in lot_struct["lots"]:
                lines.append(f"- **{lg['lot_id']}: {lg['lot_name']}** — {lg['requirement_count']} requirements")
        lines.append("")
    lines.append("## Extracted Requirements\n")
    for i, req in enumerate(result["requirements"], 1):
        cat = req.get("category", "scope")
        cat_icon = {"scope": "🔧", "commercial": "💰", "procedural": "📋", "reference": "📎", "risk": "⚠️", "transition": "🔄"}.get(cat, "")
        lines.append(f"### R{i:02d} {cat_icon} [{cat}] ({req['type']})")
        lot_label = f" | 📦 {req['lot_id']}" if req.get("lot_id") else ""
        lines.append(f"Source: {req['source']}{lot_label}")
        if req.get("parent_section"): lines.append(f"Parent: {req['parent_section']}")
        lines.append(f"\n**{req['text']}**")
        if req.get("body_summary"): lines.append(f"\n{req['body_summary'][:200]}…")
        if req.get("suggested_products"):
            lines.append(f"\nSuggested products:")
            for sp in req["suggested_products"]:
                score_str = f" (score: {sp.get('score', '?')})"
                lines.append(f"  - {sp['code']} — {sp['name']}{score_str}")
                if sp.get("sub_products"):
                    for sub in sp["sub_products"]:
                        lines.append(f"    └ {sub['code']}: {sub['name']}")
        lines.append("")
    return "\n".join(lines)

def main():
    parser = argparse.ArgumentParser(description="Parse RFI document (.docx or .pdf)")
    parser.add_argument("--file", required=True, help="RFI document path (.docx or .pdf)")
    parser.add_argument("--output", required=True, help="Output JSON path")
    parser.add_argument("--summary", help="Also write a text summary to this path")
    parser.add_argument("--product-index", help="Product index JSON for auto-matching")
    args = parser.parse_args()
    result = parse_rfi(args.file, args.product_index)
    output_path = Path(args.output); output_path.parent.mkdir(parents=True, exist_ok=True)
    with open(output_path, "w", encoding="utf-8") as f: json.dump(result, f, ensure_ascii=False, indent=2)
    print(f"✅ Parsed: {result['requirement_count']} requirements ({result['detected_format']}, {result['detected_language']}) from {result['file']}")
    if args.summary:
        with open(args.summary, "w", encoding="utf-8") as f: f.write(format_requirements_summary(result))
        print(f"✅ Summary: {args.summary}")

if __name__ == "__main__":
    main()
