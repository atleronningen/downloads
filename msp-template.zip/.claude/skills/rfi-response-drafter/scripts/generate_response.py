#!/usr/bin/env python3
"""
generate_response.py — Generate a branded Sopra Steria RFI response document.

Takes a JSON file of approved responses and produces a Word document using
the Sopra Steria branded template (.dotx), preserving cover page, headers,
logos, and styles.

Usage:
    python3 generate_response.py \
        --template "path/to/template.dotx" \
        --responses "path/to/responses.json" \
        --output "path/to/output.docx" \
        --title "RFI Response — Customer Name" \
        --subtitle "Sopra Steria — Digital Platform Services"

responses.json format:
{
    "customer": "Customer Name",
    "rfi_title": "RFI Title",
    "language": "en" | "no",
    "sections": [
        {
            "heading": "Section heading (H1)",
            "type": "h1",
            "content": null
        },
        {
            "heading": "Requirement question text",
            "type": "requirement",
            "key_takeaway": "Optional key takeaway text",
            "content": "Full narrative response...",
            "bullets": ["Optional", "bullet", "points"]
        }
    ]
}
"""

import argparse
import json
import sys
import os
import zipfile
import shutil
from pathlib import Path

try:
    from docx import Document
    from docx.shared import Pt, Inches, RGBColor, Emu
    from docx.enum.text import WD_ALIGN_PARAGRAPH
except ImportError:
    import subprocess
    subprocess.check_call([sys.executable, "-m", "pip", "install", "python-docx", "--break-system-packages", "-q"])
    from docx import Document
    from docx.shared import Pt, Inches, RGBColor, Emu
    from docx.enum.text import WD_ALIGN_PARAGRAPH


SOPRA_PURPLE = RGBColor(0x4C, 0x1F, 0x82)


def convert_dotx_to_docx(dotx_path, docx_path):
    """Convert a .dotx template to .docx by fixing the content type in the ZIP."""
    with zipfile.ZipFile(dotx_path, "r") as zin:
        tmp_dir = str(docx_path) + "_tmp"
        os.makedirs(tmp_dir, exist_ok=True)
        zin.extractall(tmp_dir)

    ct_path = os.path.join(tmp_dir, "[Content_Types].xml")
    with open(ct_path, "r", encoding="utf-8") as f:
        content = f.read()
    content = content.replace(
        "application/vnd.openxmlformats-officedocument.wordprocessingml.template.main+xml",
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml",
    )
    with open(ct_path, "w", encoding="utf-8") as f:
        f.write(content)

    with zipfile.ZipFile(docx_path, "w", zipfile.ZIP_DEFLATED) as zout:
        for root, dirs, files in os.walk(tmp_dir):
            for file in files:
                file_path = os.path.join(root, file)
                arcname = os.path.relpath(file_path, tmp_dir)
                zout.write(file_path, arcname)

    shutil.rmtree(tmp_dir)
    return docx_path


def update_sdt_content(doc, alias, new_text):
    """Update the text in Structured Document Tags (SDTs) matching the given alias.
    
    SDTs are used on the Sopra Steria cover page for title, subtitle, customer name, and date.
    """
    WNS = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
    body = doc.element.body
    # Search entire document (body + glossary) for SDTs
    for sdt in body.iter(f'{{{WNS}}}sdt'):
        sdt_pr = sdt.find(f'{{{WNS}}}sdtPr')
        if sdt_pr is None:
            continue
        alias_elem = sdt_pr.find(f'{{{WNS}}}alias')
        if alias_elem is None:
            continue
        alias_val = alias_elem.get(f'{{{WNS}}}val', '')
        if alias_val != alias:
            continue
        # Found matching SDT — update all text runs inside sdtContent
        sdt_content = sdt.find(f'{{{WNS}}}sdtContent')
        if sdt_content is None:
            continue
        # Clear existing text and set new text on first run
        first_run_set = False
        for t_elem in sdt_content.iter(f'{{{WNS}}}t'):
            if not first_run_set:
                t_elem.text = new_text
                first_run_set = True
            else:
                t_elem.text = ''


def template_has_toc(doc):
    """Check if the template already has a Table of Contents SDT block."""
    WNS = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
    body = doc.element.body
    for sdt in body.iter(f'{{{WNS}}}sdt'):
        sdt_pr = sdt.find(f'{{{WNS}}}sdtPr')
        if sdt_pr is None:
            continue
        # Check for docPartGallery with Table of Contents
        for dpg in sdt_pr.iter(f'{{{WNS}}}docPartGallery'):
            if dpg.get(f'{{{WNS}}}val', '') == 'Table of Contents':
                return True
        # Also check for TOC field codes inside SDT
        for instr in sdt.iter(f'{{{WNS}}}instrText'):
            if instr.text and 'TOC' in instr.text:
                return True
    return False


def clean_toc_placeholder_entries(doc):
    """Remove stale placeholder entries from the template's existing ToC.
    
    The template's ToC SDT contains rendered entries from the original placeholder content.
    These look wrong until Word updates the field. We clear the visible text but keep the
    field code so Word can regenerate the entries on open.
    """
    WNS = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
    body = doc.element.body
    for sdt in body.iter(f'{{{WNS}}}sdt'):
        sdt_pr = sdt.find(f'{{{WNS}}}sdtPr')
        if sdt_pr is None:
            continue
        is_toc = False
        for dpg in sdt_pr.iter(f'{{{WNS}}}docPartGallery'):
            if dpg.get(f'{{{WNS}}}val', '') == 'Table of Contents':
                is_toc = True
        if not is_toc:
            continue
        # Found the ToC SDT — remove rendered paragraphs that don't contain field codes
        sdt_content = sdt.find(f'{{{WNS}}}sdtContent')
        if sdt_content is None:
            continue
        to_remove = []
        for child in sdt_content:
            tag = child.tag.split("}")[-1] if "}" in child.tag else child.tag
            if tag == "p":
                # Keep paragraphs with TOC field codes, remove rendered entries
                has_field = child.find(f'.//{{{WNS}}}fldChar') is not None
                has_toc_heading = False
                for r in child.iter(f'{{{WNS}}}pStyle'):
                    if 'TOC' in r.get(f'{{{WNS}}}val', '').upper() and 'Heading' in r.get(f'{{{WNS}}}val', ''):
                        has_toc_heading = True
                if has_toc_heading:
                    # This is the "Table of Contents" heading — keep it
                    continue
                if not has_field:
                    # Rendered ToC entry (stale) — check if it has TOC style
                    style_elem = child.find(f'.//{{{WNS}}}pStyle')
                    if style_elem is not None:
                        style_val = style_elem.get(f'{{{WNS}}}val', '')
                        if style_val.startswith('TOC') or style_val.startswith('toc'):
                            to_remove.append(child)
        for elem in to_remove:
            sdt_content.remove(elem)


def add_table_of_contents(doc):
    """Add a Table of Contents field after the cover page separator.
    
    Only adds a ToC if the template doesn't already have one.
    This inserts a TOC field code that Word will update when the document is opened.
    The TOC shows Heading 1-3 with hyperlinks.
    """
    if template_has_toc(doc):
        # Template already has a ToC — just clean stale entries
        clean_toc_placeholder_entries(doc)
        return

    from docx.oxml.ns import qn
    from docx.oxml import OxmlElement

    # Create a TOC paragraph
    para = doc.add_paragraph()
    style = get_style_safe(doc, "TOC Heading", "Heading 1")
    if style:
        para.style = style
    run = para.add_run("Table of Contents")

    # Add the actual TOC field
    toc_para = doc.add_paragraph()
    run = toc_para.add_run()
    
    # Begin field
    fldChar_begin = OxmlElement('w:fldChar')
    fldChar_begin.set(qn('w:fldCharType'), 'begin')
    run._r.append(fldChar_begin)
    
    # Field instruction
    instrText = OxmlElement('w:instrText')
    instrText.set(qn('xml:space'), 'preserve')
    instrText.text = r' TOC \o "1-3" \h \z \u '
    run._r.append(instrText)
    
    # Separate
    fldChar_sep = OxmlElement('w:fldChar')
    fldChar_sep.set(qn('w:fldCharType'), 'separate')
    run._r.append(fldChar_sep)
    
    # Placeholder text (Word will replace this on update)
    placeholder = OxmlElement('w:t')
    placeholder.text = '[Update this Table of Contents in Word: right-click → Update Field]'
    run._r.append(placeholder)
    
    # End field
    fldChar_end = OxmlElement('w:fldChar')
    fldChar_end.set(qn('w:fldCharType'), 'end')
    run._r.append(fldChar_end)

    # Add a page break after TOC
    doc.add_page_break()


def clear_body_content(doc):
    """Remove placeholder content from the template body, keeping cover page and section properties.

    Template structure:
    - bookmarkStart, sdt elements (cover page) → KEEP
    - Empty separator paragraph after cover page → KEEP
    - Placeholder paragraphs and tables (Lorem ipsum etc.) → REMOVE
    - Final sectPr (section properties) → KEEP
    """
    WNS = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
    body = doc.element.body

    # Identify which elements to keep vs remove
    elements_to_remove = []
    cover_phase = True  # True while we're still in the cover page area

    for element in body:
        tag = element.tag.split("}")[-1] if "}" in element.tag else element.tag

        # Always keep section properties
        if tag == "sectPr":
            continue

        # Keep cover page elements: bookmarkStart, bookmarkEnd, sdt
        if tag in ("bookmarkStart", "bookmarkEnd", "sdt"):
            continue

        # The first empty paragraph after SDTs is the cover/body separator — keep it
        if cover_phase and tag == "p":
            # Check if this paragraph has no visible text content
            text = element.findtext(f'.//{{{WNS}}}t', '')
            if not text.strip():
                cover_phase = False  # We've passed the cover page
                continue
            else:
                # First paragraph with text = start of placeholder content
                cover_phase = False
                elements_to_remove.append(element)
        elif not cover_phase:
            # Everything after the cover page separator is placeholder — remove it
            elements_to_remove.append(element)

    for elem in elements_to_remove:
        body.remove(elem)


def get_style_safe(doc, style_name, fallback="Normal"):
    """Get a style by name, falling back if not found."""
    try:
        return doc.styles[style_name]
    except KeyError:
        try:
            return doc.styles[fallback]
        except KeyError:
            return None


def add_paragraph_with_style(doc, text, style_name, bold=False):
    """Add a paragraph using a named style from the template."""
    para = doc.add_paragraph()
    style = get_style_safe(doc, style_name)
    if style:
        para.style = style
    run = para.add_run(text)
    if bold:
        run.bold = True
    return para


def add_content_paragraphs(doc, content_text):
    """Add content as multiple paragraphs, splitting on double newlines."""
    paragraphs = content_text.split("\n\n")
    for para_text in paragraphs:
        para_text = para_text.strip()
        if not para_text:
            continue
        # Handle single newlines within a paragraph as line breaks
        para = doc.add_paragraph()
        style = get_style_safe(doc, "Normal")
        if style:
            para.style = style
        lines = para_text.split("\n")
        for i, line in enumerate(lines):
            run = para.add_run(line.strip())
            if i < len(lines) - 1:
                from docx.oxml.ns import qn
                br = run._r.makeelement(qn("w:br"), {})
                run._r.append(br)


def add_bullet_list(doc, items):
    """Add bullet list items using the template's List Paragraph style."""
    for item in items:
        para = doc.add_paragraph()
        style = get_style_safe(doc, "List Paragraph", "List Bullet")
        if style:
            para.style = style
        para.add_run(item)


def add_compliance_matrix(doc, section, lang="en"):
    """Add a compliance matrix table with styled headers and status coloring.
    
    Expected section format:
    {
        "type": "compliance_matrix",
        "heading": "Compliance Matrix",
        "rows": [
            {
                "req_id": "R01",
                "requirement": "Short requirement summary",
                "status": "Fully Compliant",
                "section_ref": "2.1"
            }
        ]
    }
    
    Status values: "Fully Compliant", "Partially Compliant", "Alternative Proposed", "Not Applicable"
    """
    from docx.shared import Cm
    from docx.enum.table import WD_TABLE_ALIGNMENT
    from docx.oxml.ns import qn
    from docx.oxml import OxmlElement

    rows = section.get("rows", [])
    if not rows:
        return

    # Column headers (language-aware)
    if lang == "no":
        headers = ["Ref.", "Krav", "Samsvar", "Avsnitt"]
    else:
        headers = ["Ref.", "Requirement", "Compliance Status", "Section"]

    # Create table: header row + data rows
    table = doc.add_table(rows=1 + len(rows), cols=4)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = True

    # Style the table with grid lines
    tbl = table._tbl
    tbl_pr = tbl.tblPr if tbl.tblPr is not None else OxmlElement('w:tblPr')
    borders = OxmlElement('w:tblBorders')
    for border_name in ('top', 'left', 'bottom', 'right', 'insideH', 'insideV'):
        border = OxmlElement(f'w:{border_name}')
        border.set(qn('w:val'), 'single')
        border.set(qn('w:sz'), '4')
        border.set(qn('w:space'), '0')
        border.set(qn('w:color'), '666666')
        borders.append(border)
    tbl_pr.append(borders)

    # Set column widths (approximate: 8%, 52%, 22%, 18%)
    tbl_grid = OxmlElement('w:tblGrid')
    col_widths = [Cm(1.5), Cm(9.5), Cm(4.0), Cm(2.5)]
    for w in col_widths:
        grid_col = OxmlElement('w:gridCol')
        grid_col.set(qn('w:w'), str(w))
        tbl_grid.append(grid_col)
    tbl.insert(1, tbl_grid)  # Insert after tblPr

    # Header row — Sopra Steria purple background
    header_cells = table.rows[0].cells
    for i, header_text in enumerate(headers):
        cell = header_cells[i]
        cell.text = ""
        para = cell.paragraphs[0]
        run = para.add_run(header_text)
        run.bold = True
        run.font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)
        run.font.size = Pt(9)
        # Purple background shading
        shading = OxmlElement('w:shd')
        shading.set(qn('w:fill'), '4C1F82')
        shading.set(qn('w:val'), 'clear')
        cell._tc.get_or_add_tcPr().append(shading)

    # Status color mapping
    STATUS_COLORS = {
        "Fully Compliant": "C6EFCE",       # Green
        "Fullt samsvar": "C6EFCE",
        "Partially Compliant": "FFEB9C",    # Amber
        "Delvis samsvar": "FFEB9C",
        "Alternative Proposed": "BDD7EE",   # Blue
        "Alternativ foreslått": "BDD7EE",
        "Not Applicable": "D9D9D9",         # Grey
        "Ikke aktuelt": "D9D9D9",
    }

    # Data rows
    for row_idx, row_data in enumerate(rows):
        cells = table.rows[1 + row_idx].cells
        
        # Req ID
        cells[0].text = ""
        run = cells[0].paragraphs[0].add_run(row_data.get("req_id", ""))
        run.font.size = Pt(9)
        run.bold = True

        # Requirement text
        cells[1].text = ""
        run = cells[1].paragraphs[0].add_run(row_data.get("requirement", ""))
        run.font.size = Pt(9)

        # Status with conditional coloring
        status = row_data.get("status", "")
        cells[2].text = ""
        run = cells[2].paragraphs[0].add_run(status)
        run.font.size = Pt(9)
        run.bold = True
        bg_color = STATUS_COLORS.get(status, "FFFFFF")
        shading = OxmlElement('w:shd')
        shading.set(qn('w:fill'), bg_color)
        shading.set(qn('w:val'), 'clear')
        cells[2]._tc.get_or_add_tcPr().append(shading)

        # Section reference
        cells[3].text = ""
        run = cells[3].paragraphs[0].add_run(row_data.get("section_ref", ""))
        run.font.size = Pt(9)

    # Add a blank paragraph after the table for spacing
    doc.add_paragraph()


def add_figure_placeholder(doc, section, lang="en"):
    """Add a numbered figure placeholder with a bordered box and caption.
    
    Expected section format:
    {
        "type": "figure_placeholder",
        "figure_number": 1,
        "caption": "Overview of the SIAM operating model",
        "description": "Diagram showing the layered governance model with strategic, tactical, and operational levels. Include customer, service integrator, and vendor boxes with RACI arrows.",
        "size": "half"  // "half" (default) or "full"
    }
    
    Renders as:
    - A bordered grey box with "[Insert figure here]" and the description
    - A caption below: "Figure 1: Overview of the SIAM operating model"
    """
    from docx.shared import Cm
    from docx.oxml.ns import qn
    from docx.oxml import OxmlElement

    fig_num = section.get("figure_number", "X")
    caption = section.get("caption", "")
    description = section.get("description", "")
    size = section.get("size", "half")

    # Create a single-cell table to act as the placeholder box
    table = doc.add_table(rows=1, cols=1)
    table.autofit = True

    # Style the border
    tbl = table._tbl
    tbl_pr = tbl.tblPr if tbl.tblPr is not None else OxmlElement('w:tblPr')
    borders = OxmlElement('w:tblBorders')
    for border_name in ('top', 'left', 'bottom', 'right'):
        border = OxmlElement(f'w:{border_name}')
        border.set(qn('w:val'), 'dashed')
        border.set(qn('w:sz'), '6')
        border.set(qn('w:space'), '0')
        border.set(qn('w:color'), '999999')
        borders.append(border)
    tbl_pr.append(borders)

    # Set background to light grey
    cell = table.rows[0].cells[0]
    shading = OxmlElement('w:shd')
    shading.set(qn('w:fill'), 'F2F2F2')
    shading.set(qn('w:val'), 'clear')
    cell._tc.get_or_add_tcPr().append(shading)

    # Set minimum height based on size
    tr = table.rows[0]._tr
    tr_pr = tr.get_or_add_trPr()
    tr_height = OxmlElement('w:trHeight')
    if size == "full":
        tr_height.set(qn('w:val'), str(int(Cm(8))))
    else:
        tr_height.set(qn('w:val'), str(int(Cm(5))))
    tr_height.set(qn('w:hRule'), 'atLeast')
    tr_pr.append(tr_height)

    # Content inside the box
    cell.text = ""
    # "[Insert figure here]" header
    header_para = cell.paragraphs[0]
    header_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = header_para.add_run(f"[Insert Figure {fig_num} here]")
    run.bold = True
    run.font.color.rgb = RGBColor(0x66, 0x66, 0x66)
    run.font.size = Pt(11)

    # Description text (instructions for what to illustrate)
    if description:
        desc_para = cell.add_paragraph()
        desc_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = desc_para.add_run(description)
        run.italic = True
        run.font.color.rgb = RGBColor(0x88, 0x88, 0x88)
        run.font.size = Pt(9)

    # Caption below the box
    if lang == "no":
        caption_prefix = f"Figur {fig_num}"
    else:
        caption_prefix = f"Figure {fig_num}"

    caption_para = doc.add_paragraph()
    caption_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = caption_para.add_run(f"{caption_prefix}: {caption}")
    run.italic = True
    run.font.size = Pt(9)
    run.font.color.rgb = SOPRA_PURPLE

    # Spacing after
    doc.add_paragraph()


def add_inline_table(doc, table_data, lang="en"):
    """Add a styled table inline within a requirement response.
    
    table_data format:
    {
        "caption": "Table 1: SLA tier overview",        # optional
        "headers": ["Tier", "Availability", "Response Time", "Support Hours"],
        "rows": [
            ["Gold", "99.9%", "15 min", "24/7"],
            ["Silver", "99.5%", "30 min", "8x5"],
            ["Bronze", "99.0%", "2 hours", "8x5"]
        ],
        "style": "branded"  # "branded" (purple header) or "plain" (grey header)
    }
    """
    from docx.oxml.ns import qn
    from docx.oxml import OxmlElement
    from docx.enum.table import WD_TABLE_ALIGNMENT

    headers = table_data.get("headers", [])
    rows_data = table_data.get("rows", [])
    caption = table_data.get("caption", "")
    style = table_data.get("style", "branded")

    if not headers or not rows_data:
        return

    num_cols = len(headers)
    table = doc.add_table(rows=1 + len(rows_data), cols=num_cols)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = True

    # Grid borders
    tbl = table._tbl
    tbl_pr = tbl.tblPr if tbl.tblPr is not None else OxmlElement('w:tblPr')
    borders = OxmlElement('w:tblBorders')
    for border_name in ('top', 'left', 'bottom', 'right', 'insideH', 'insideV'):
        border = OxmlElement(f'w:{border_name}')
        border.set(qn('w:val'), 'single')
        border.set(qn('w:sz'), '4')
        border.set(qn('w:space'), '0')
        border.set(qn('w:color'), '999999')
        borders.append(border)
    tbl_pr.append(borders)

    # Header row
    if style == "branded":
        header_bg, header_fg = '4C1F82', RGBColor(0xFF, 0xFF, 0xFF)
    else:
        header_bg, header_fg = 'E8E8E8', RGBColor(0x33, 0x33, 0x33)

    for i, header_text in enumerate(headers):
        cell = table.rows[0].cells[i]
        cell.text = ""
        run = cell.paragraphs[0].add_run(str(header_text))
        run.bold = True
        run.font.color.rgb = header_fg
        run.font.size = Pt(9)
        shading = OxmlElement('w:shd')
        shading.set(qn('w:fill'), header_bg)
        shading.set(qn('w:val'), 'clear')
        cell._tc.get_or_add_tcPr().append(shading)

    # Data rows with alternating zebra stripes
    for row_idx, row_values in enumerate(rows_data):
        cells = table.rows[1 + row_idx].cells
        bg = 'F9F9F9' if row_idx % 2 == 1 else 'FFFFFF'
        for col_idx in range(num_cols):
            val = row_values[col_idx] if col_idx < len(row_values) else ""
            cell = cells[col_idx]
            cell.text = ""
            run = cell.paragraphs[0].add_run(str(val))
            run.font.size = Pt(9)
            # First column bold
            if col_idx == 0:
                run.bold = True
            # Zebra stripe
            if bg != 'FFFFFF':
                shading = OxmlElement('w:shd')
                shading.set(qn('w:fill'), bg)
                shading.set(qn('w:val'), 'clear')
                cell._tc.get_or_add_tcPr().append(shading)

    # Caption below table
    if caption:
        cap_para = doc.add_paragraph()
        cap_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = cap_para.add_run(caption)
        run.italic = True
        run.font.size = Pt(9)
        run.font.color.rgb = SOPRA_PURPLE


def add_executive_summary(doc, section, lang="en"):
    """Add a structured executive summary section.
    
    section format:
    {
        "type": "executive_summary",
        "heading": "Executive Summary",
        "customer": "Customer Name",
        "overview": "1-2 sentence strategic positioning...",
        "win_themes": ["Theme 1 description", "Theme 2 description"],
        "highlights": [
            {"area": "Cloud Platform", "summary": "Full Azure managed service with IaC..."},
            {"area": "Security", "summary": "24/7 SOC with SIEM/SOAR..."},
        ],
        "references": [
            {"name": "Bane NOR", "relevance": "Comparable SIAM model for critical infrastructure"},
        ],
        "next_steps": "Optional closing paragraph about next steps..."
    }
    """
    from docx.oxml.ns import qn
    from docx.oxml import OxmlElement

    heading = section.get("heading", "Executive Summary" if lang == "en" else "Sammendrag")
    
    # Page break before executive summary
    doc.add_page_break()
    add_paragraph_with_style(doc, heading, "Heading 1")

    # Strategic overview paragraph
    if section.get("overview"):
        add_content_paragraphs(doc, section["overview"])

    # Win themes as key takeaway block
    win_themes = section.get("win_themes", [])
    if win_themes:
        themes_label = "Strategic win themes" if lang == "en" else "Strategiske vinnertemaer"
        add_paragraph_with_style(doc, themes_label, "Key take-away", bold=True)
        add_bullet_list(doc, win_themes)

    # Highlights table — compact overview of each response area
    highlights = section.get("highlights", [])
    if highlights:
        hl_heading = "Response Highlights" if lang == "en" else "Hovedpunkter"
        add_paragraph_with_style(doc, hl_heading, "Heading 2")

        table = doc.add_table(rows=1 + len(highlights), cols=2)
        table.autofit = True

        tbl = table._tbl
        tbl_pr = tbl.tblPr if tbl.tblPr is not None else OxmlElement('w:tblPr')
        borders = OxmlElement('w:tblBorders')
        for border_name in ('top', 'left', 'bottom', 'right', 'insideH', 'insideV'):
            border = OxmlElement(f'w:{border_name}')
            border.set(qn('w:val'), 'single')
            border.set(qn('w:sz'), '4')
            border.set(qn('w:space'), '0')
            border.set(qn('w:color'), '999999')
            borders.append(border)
        tbl_pr.append(borders)

        # Header row
        for i, h_text in enumerate(
            ["Area", "Sopra Steria Response"] if lang == "en" else ["Område", "Sopra Sterias svar"]
        ):
            cell = table.rows[0].cells[i]
            cell.text = ""
            run = cell.paragraphs[0].add_run(h_text)
            run.bold = True
            run.font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)
            run.font.size = Pt(9)
            shading = OxmlElement('w:shd')
            shading.set(qn('w:fill'), '4C1F82')
            shading.set(qn('w:val'), 'clear')
            cell._tc.get_or_add_tcPr().append(shading)

        for row_idx, hl in enumerate(highlights):
            cells = table.rows[1 + row_idx].cells
            cells[0].text = ""
            run = cells[0].paragraphs[0].add_run(hl.get("area", ""))
            run.bold = True
            run.font.size = Pt(9)

            cells[1].text = ""
            run = cells[1].paragraphs[0].add_run(hl.get("summary", ""))
            run.font.size = Pt(9)

        doc.add_paragraph()

    # Key references
    references = section.get("references", [])
    if references:
        ref_heading = "Key References" if lang == "en" else "Nøkkelreferanser"
        add_paragraph_with_style(doc, ref_heading, "Heading 2")
        ref_items = [f"**{r.get('name', '')}** — {r.get('relevance', '')}" for r in references]
        # Render as bold name + plain relevance (since bullet list doesn't support inline bold,
        # we do this as paragraphs)
        for ref in references:
            para = doc.add_paragraph()
            style = get_style_safe(doc, "List Paragraph", "List Bullet")
            if style:
                para.style = style
            run = para.add_run(ref.get("name", ""))
            run.bold = True
            run.font.size = Pt(10)
            run = para.add_run(f" — {ref.get('relevance', '')}")
            run.font.size = Pt(10)

    # Next steps
    if section.get("next_steps"):
        ns_heading = "Next Steps" if lang == "en" else "Veien videre"
        add_paragraph_with_style(doc, ns_heading, "Heading 2")
        add_content_paragraphs(doc, section["next_steps"])


def add_company_overview(doc, section, lang="en"):
    """Add the standard 'About Sopra Steria' and 'About DPS' pages.
    
    These are standardised content blocks that should appear in every RFI response,
    typically right after the Introduction. The section type can override the default
    text with custom content if provided, but defaults to the standard corporate facts.
    
    section format:
    {
        "type": "company_overview",
        "heading": "About Sopra Steria" (optional, auto-set by language),
        "custom_ss_text": "Override text for About Sopra Steria" (optional),
        "custom_dps_text": "Override text for About DPS" (optional)
    }
    """
    # --- About Sopra Steria ---
    if lang == "no":
        ss_heading = section.get("heading", "Om Sopra Steria")
        ss_default = (
            "Sopra Steria er en ledende europeisk aktør innen teknologi med en omsetning på EUR 5,6 milliarder, "
            "51 275 ansatte og tilstedeværelse i rundt 30 land. Konsernet er notert på Euronext Paris og er "
            "uavhengig eid. Virksomheten er organisert i tre hovedområder: Systems Integration (60 %), "
            "Digital Platform Services (13 %) og Consulting (9 %). Benelux utgjør 9 % av konsernets omsetning. "
            "Gjennom oppkjøpet av Tobania i 2023 styrket Sopra Steria sin tilstedeværelse i Belgia. "
            "Energy & Utilities utgjør 7 % av konsernets vertikaler."
        )
        dps_heading = "Om Digital Platform Services"
        dps_default = (
            "Digital Platform Services (DPS) er Sopra Sterias forretningsenhet for administrerte tjenester, "
            "med en omsetning på EUR 728 millioner og over 6 500 spesialister fordelt på 14 land. "
            "DPS opererer to Global Delivery Centres (India og Polen) og leverer 24/7 Follow-the-Sun-tjenester. "
            "Porteføljen omfatter rundt 400 standardiserte tjenester (SKU-er) organisert i fem pilarer. "
            "DPS er anerkjent som leder av Gartner og ISG, og leverer med over 350 roboter, "
            "250+ sky-sertifiseringer og mer enn 50 000 servere under forvaltning."
        )
    else:
        ss_heading = section.get("heading", "About Sopra Steria")
        ss_default = (
            "Sopra Steria is a leading European technology company with EUR 5.6 billion in revenue, "
            "51,275 employees, and a presence in approximately 30 countries. The company is listed on "
            "Euronext Paris and independently owned. Operations are organised across three main areas: "
            "Systems Integration (60%), Digital Platform Services (13%), and Consulting (9%). "
            "The Benelux region accounts for 9% of Group revenue. Through the acquisition of Tobania "
            "in 2023, Sopra Steria strengthened its presence in Belgium. Energy & Utilities represents "
            "7% of the Group's industry verticals."
        )
        dps_heading = "About Digital Platform Services"
        dps_default = (
            "Digital Platform Services (DPS) is Sopra Steria's managed services business unit, "
            "with EUR 728 million in revenue and over 6,500 specialists across 14 countries. "
            "DPS operates two Global Delivery Centres (India and Poland) and delivers 24/7 "
            "Follow-the-Sun services. The portfolio comprises approximately 400 standardised "
            "services (SKUs) organised across five pillars. DPS holds Gartner and ISG leader "
            "recognitions, and delivers with over 350 robots, 250+ cloud certifications, "
            "and more than 50,000 servers under management."
        )

    ss_text = section.get("custom_ss_text", ss_default)
    dps_text = section.get("custom_dps_text", dps_default)

    add_paragraph_with_style(doc, ss_heading, "Heading 2")
    add_content_paragraphs(doc, ss_text)

    add_paragraph_with_style(doc, dps_heading, "Heading 2")
    add_content_paragraphs(doc, dps_text)


def add_appendix_heading(doc, section, appendix_counter):
    """Add an appendix heading with letter-based numbering (Appendix A, B, C...).
    
    section format:
    {
        "type": "appendix",
        "heading": "Reference Case Details",
        "content": "Optional intro text...",
        "tables": [...],        # optional inline tables
        "bullets": [...]        # optional bullet lists
    }
    
    Returns the appendix letter used.
    """
    letter = chr(64 + appendix_counter)  # 1→A, 2→B, etc.
    heading_text = section.get("heading", "")
    full_heading = f"Appendix {letter}: {heading_text}" if heading_text else f"Appendix {letter}"

    doc.add_page_break()
    add_paragraph_with_style(doc, full_heading, "Heading 1")

    if section.get("content"):
        add_content_paragraphs(doc, section["content"])

    if section.get("bullets"):
        add_bullet_list(doc, section["bullets"])

    return letter


def render_sections(doc, sections, lang, state=None):
    """Render a list of sections into the document.
    
    This is the core rendering loop, extracted so it can be called for:
    - Flat responses (original mode)
    - Shared sections in a lot-based document
    - Per-lot sections in a lot-based document
    
    state is a mutable dict tracking:
    - first_h1: whether we've seen the first H1 (for page break logic)
    - appendix_counter: current appendix letter counter
    """
    if state is None:
        state = {"first_h1": True, "appendix_counter": 0}
    
    for section in sections:
        section_type = section.get("type", "requirement")
        heading = section.get("heading", "")

        if section_type == "h1":
            if not state["first_h1"]:
                doc.add_page_break()
            state["first_h1"] = False
            add_paragraph_with_style(doc, heading, "Heading 1")

        elif section_type == "h2":
            add_paragraph_with_style(doc, heading, "Heading 2")

        elif section_type == "requirement":
            heading_style = section.get("heading_style", "Heading 2")
            add_paragraph_with_style(doc, heading, heading_style)
            if section.get("key_takeaway"):
                add_paragraph_with_style(doc, section["key_takeaway"], "Key take-away", bold=True)
            if section.get("content"):
                add_content_paragraphs(doc, section["content"])
            if section.get("tables"):
                for tbl_data in section["tables"]:
                    add_inline_table(doc, tbl_data, lang=lang)
            if section.get("bullets"):
                add_bullet_list(doc, section["bullets"])

        elif section_type == "text":
            add_content_paragraphs(doc, section.get("content", ""))

        elif section_type == "table":
            if heading:
                add_paragraph_with_style(doc, heading, section.get("heading_style", "Heading 2"))
            if section.get("content"):
                add_content_paragraphs(doc, section["content"])
            add_inline_table(doc, section, lang=lang)

        elif section_type == "compliance_matrix":
            if heading:
                add_paragraph_with_style(doc, heading, section.get("heading_style", "Heading 1"))
            if section.get("content"):
                add_content_paragraphs(doc, section["content"])
            add_compliance_matrix(doc, section, lang=lang)

        elif section_type == "figure_placeholder":
            add_figure_placeholder(doc, section, lang=lang)

        elif section_type == "executive_summary":
            add_executive_summary(doc, section, lang=lang)

        elif section_type == "company_overview":
            add_company_overview(doc, section, lang=lang)

        elif section_type == "appendix":
            state["appendix_counter"] += 1
            add_appendix_heading(doc, section, state["appendix_counter"])
            if section.get("tables"):
                for tbl_data in section["tables"]:
                    add_inline_table(doc, tbl_data, lang=lang)
    
    return state


def add_ai_disclaimer(doc, lang="en"):
    """Add a subtle AI usage disclaimer at the bottom of the cover page.
    
    Rendered in small (7pt), italic, light-gray text to be present but unobtrusive.
    """
    if lang == "no":
        disclaimer_text = (
            "AI-brukserklæring: Dette dokumentet ble utarbeidet med assistanse fra kunstig intelligens. "
            "Innholdet er gjennomgått, faktasjekket og redigert av et menneske for å sikre kvalitet. "
            "Forfatteren tar fullt ansvar for det endelige resultatet."
        )
    else:
        disclaimer_text = (
            "AI Usage Disclosure: This document was created with assistance of Artificial Intelligence. "
            "The content has been reviewed, fact-checked, and edited by a human to ensure quality. "
            "The author takes full responsibility for the final output."
        )
    
    para = doc.add_paragraph()
    para.alignment = WD_ALIGN_PARAGRAPH.LEFT
    # Add spacing above to push it toward the bottom of the cover page
    para.paragraph_format.space_before = Pt(60)
    para.paragraph_format.space_after = Pt(0)
    run = para.add_run(disclaimer_text)
    run.italic = True
    run.font.size = Pt(7)
    run.font.color.rgb = RGBColor(0xA0, 0xA0, 0xA0)  # Light gray


def prepare_document(template_path, output_path, responses, title=None, subtitle=None):
    """Create and prepare a document from the template with cover page and ToC.
    
    Shared setup used by both flat and lot-based generation modes.
    Returns (doc, tmp_docx_path, lang).
    """
    template_path = Path(template_path)
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    tmp_docx = output_path.parent / "_tmp_template.docx"
    if template_path.suffix.lower() == ".dotx":
        convert_dotx_to_docx(template_path, tmp_docx)
        doc = Document(tmp_docx)
    else:
        doc = Document(template_path)

    clear_body_content(doc)

    from docx.oxml.ns import qn as _qn
    from docx.oxml import OxmlElement as _OE
    settings = doc.settings.element
    update_fields = settings.find(_qn('w:updateFields'))
    if update_fields is None:
        update_fields = _OE('w:updateFields')
        settings.append(update_fields)
    update_fields.set(_qn('w:val'), 'true')

    customer_name = responses.get("customer", "")
    if title:
        update_sdt_content(doc, "Name of document", title)
    if subtitle:
        update_sdt_content(doc, "Subheading", subtitle)
    if customer_name:
        update_sdt_content(doc, "Customer", customer_name)
    from datetime import date
    lang = responses.get("language", "en")
    today = date.today()
    if lang == "no":
        no_months = ["januar","februar","mars","april","mai","juni",
                     "juli","august","september","oktober","november","desember"]
        date_str = f"{today.day}. {no_months[today.month-1]} {today.year}"
    else:
        date_str = today.strftime("%B %d, %Y")
    update_sdt_content(doc, "Date", date_str)
    add_ai_disclaimer(doc, lang)
    add_table_of_contents(doc)

    return doc, tmp_docx, lang


def is_lot_based(responses):
    """Check if the responses JSON uses lot-based structure."""
    return "lots" in responses and isinstance(responses["lots"], list)


def generate_document(template_path, responses_path, output_path, title=None, subtitle=None, mode="auto"):
    """Generate the final branded RFI response document.
    
    Supports two JSON formats:
    1. Flat: {"sections": [...]}  — original format
    2. Lot-based: {"shared_sections": [...], "lots": [...], "shared_appendices": [...]}
    
    mode:
    - "auto": detect from JSON structure
    - "combined": lot-based, single document with lot chapters
    - "per_lot": lot-based, separate document per lot (each includes shared sections)
    - "flat": force flat rendering even if lots are present
    """
    with open(responses_path, "r", encoding="utf-8") as f:
        responses = json.load(f)

    output_path = Path(output_path)

    # Detect mode
    if mode == "auto":
        if is_lot_based(responses):
            mode = "combined"
        else:
            mode = "flat"

    if mode == "flat" or not is_lot_based(responses):
        # --- Original flat rendering ---
        doc, tmp_docx, lang = prepare_document(template_path, output_path, responses, title, subtitle)
        render_sections(doc, responses.get("sections", []), lang)
        doc.save(output_path)
        if tmp_docx.exists():
            tmp_docx.unlink()
        print(f"✅ RFI response saved: {output_path}")
        return [output_path]

    elif mode == "combined":
        # --- Lot-based: single combined document ---
        doc, tmp_docx, lang = prepare_document(template_path, output_path, responses, title, subtitle)
        state = {"first_h1": True, "appendix_counter": 0}

        # Render shared sections first (exec summary, introduction, etc.)
        shared = responses.get("shared_sections", [])
        if shared:
            state = render_sections(doc, shared, lang, state)

        # Render each lot as a chapter
        for lot in responses.get("lots", []):
            lot_id = lot.get("lot_id", "")
            lot_name = lot.get("lot_name", "")
            lot_heading = f"{lot_id}: {lot_name}" if lot_name else lot_id
            
            # Lot chapter heading
            if not state["first_h1"]:
                doc.add_page_break()
            state["first_h1"] = False
            add_paragraph_with_style(doc, lot_heading, "Heading 1")
            
            # Lot intro text
            if lot.get("intro"):
                add_content_paragraphs(doc, lot["intro"])
            
            # Consortium info
            if lot.get("consortium_lead"):
                lead = lot["consortium_lead"]
                if lead.lower() != "sopra steria":
                    note = f"This lot is proposed for delivery by consortium partner: {lead}."
                    add_content_paragraphs(doc, note)
            
            # Per-lot compliance matrix
            if lot.get("compliance_matrix"):
                render_sections(doc, [lot["compliance_matrix"]], lang, state)
            
            # Lot sections (requirements, tables, figures, etc.)
            lot_sections = lot.get("sections", [])
            state = render_sections(doc, lot_sections, lang, state)

        # Shared appendices
        shared_appendices = responses.get("shared_appendices", [])
        if shared_appendices:
            state = render_sections(doc, shared_appendices, lang, state)

        doc.save(output_path)
        if tmp_docx.exists():
            tmp_docx.unlink()
        print(f"✅ Combined lot-based response saved: {output_path}")
        return [output_path]

    elif mode == "per_lot":
        # --- Lot-based: separate document per lot ---
        output_paths = []
        
        for lot in responses.get("lots", []):
            lot_id = lot.get("lot_id", "Lot").replace(" ", "_")
            lot_name = lot.get("lot_name", "")
            lot_file = output_path.parent / f"{output_path.stem}_{lot_id}{output_path.suffix}"
            
            lot_title = f"{title} — {lot.get('lot_id', '')}: {lot_name}" if title else f"{lot.get('lot_id', '')}: {lot_name}"
            
            doc, tmp_docx, lang = prepare_document(template_path, lot_file, responses, lot_title, subtitle)
            state = {"first_h1": True, "appendix_counter": 0}

            # Shared sections
            shared = responses.get("shared_sections", [])
            if shared:
                state = render_sections(doc, shared, lang, state)

            # Lot heading
            lot_heading = f"{lot.get('lot_id', '')}: {lot_name}" if lot_name else lot.get("lot_id", "")
            if not state["first_h1"]:
                doc.add_page_break()
            state["first_h1"] = False
            add_paragraph_with_style(doc, lot_heading, "Heading 1")
            
            if lot.get("intro"):
                add_content_paragraphs(doc, lot["intro"])
            
            if lot.get("compliance_matrix"):
                render_sections(doc, [lot["compliance_matrix"]], lang, state)
            
            lot_sections = lot.get("sections", [])
            state = render_sections(doc, lot_sections, lang, state)

            # Shared appendices
            shared_appendices = responses.get("shared_appendices", [])
            if shared_appendices:
                state = render_sections(doc, shared_appendices, lang, state)

            doc.save(lot_file)
            if tmp_docx.exists():
                tmp_docx.unlink()
            print(f"✅ {lot.get('lot_id', 'Lot')} response saved: {lot_file}")
            output_paths.append(lot_file)
        
        return output_paths

    else:
        raise ValueError(f"Unknown mode: {mode}. Use 'auto', 'flat', 'combined', or 'per_lot'.")


def main():
    parser = argparse.ArgumentParser(description="Generate branded RFI response document")
    parser.add_argument("--template", required=True, help="Path to .dotx or .docx template")
    parser.add_argument("--responses", required=True, help="Path to responses JSON")
    parser.add_argument("--output", required=True, help="Output .docx path")
    parser.add_argument("--title", help="Document title for cover page")
    parser.add_argument("--subtitle", help="Subtitle for cover page")
    parser.add_argument("--mode", default="auto", choices=["auto", "flat", "combined", "per_lot"],
                        help="Output mode: auto (detect), flat, combined (one doc), per_lot (separate docs)")

    args = parser.parse_args()
    generate_document(args.template, args.responses, args.output, args.title, args.subtitle, args.mode)


if __name__ == "__main__":
    main()
