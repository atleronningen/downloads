#!/usr/bin/env python3
"""
extract_section.py — Extract a specific section from a Word document by paragraph range.

Used to load individual product sections from the catalog on demand,
keeping context usage efficient.

Usage:
    python3 extract_section.py --file catalog.docx --start 71 --end 968 --output section.txt
    python3 extract_section.py --file catalog.docx --heading "MS04 – RightSecurity" --output section.txt
"""

import argparse
import sys
import re
from pathlib import Path

try:
    from docx import Document
except ImportError:
    import subprocess
    subprocess.check_call([sys.executable, "-m", "pip", "install", "python-docx", "--break-system-packages", "-q"])
    from docx import Document


def find_section_by_heading(doc, heading_query):
    """Find a section's paragraph range by heading text (fuzzy match)."""
    query_lower = heading_query.lower().strip()
    start_idx = None
    start_level = None

    for i, para in enumerate(doc.paragraphs):
        style_name = para.style.name.lower() if para.style else ""
        text = para.text.strip().lower()

        if not text:
            continue

        # Determine heading level
        level = None
        if "heading 1" in style_name:
            level = 1
        elif "heading 2" in style_name:
            level = 2
        elif "heading 3" in style_name:
            level = 3

        if level is None:
            continue

        # Check for match
        if start_idx is None:
            if query_lower in text or text in query_lower:
                start_idx = i
                start_level = level
        else:
            # Found start — look for end (next heading at same or higher level)
            if level <= start_level:
                return start_idx, i

    if start_idx is not None:
        return start_idx, len(doc.paragraphs)

    return None, None


def extract_section(doc, start, end):
    """Extract text content from a paragraph range."""
    lines = []
    for i in range(start, min(end, len(doc.paragraphs))):
        para = doc.paragraphs[i]
        style_name = para.style.name if para.style else "Normal"
        text = para.text.strip()

        if not text:
            continue

        # Format based on style
        if "Heading 1" in style_name:
            lines.append(f"\n# {text}\n")
        elif "Heading 2" in style_name:
            lines.append(f"\n## {text}\n")
        elif "Heading 3" in style_name:
            lines.append(f"\n### {text}\n")
        elif "Subheading" in style_name:
            lines.append(f"\n**{text}**\n")
        elif "Key take" in style_name.lower():
            lines.append(f"\n> **{text}**\n")
        elif "List" in style_name:
            lines.append(f"- {text}")
        elif "Caption" in style_name:
            lines.append(f"*{text}*")
        else:
            lines.append(text)

    return "\n".join(lines)


def extract_tables_in_range(doc, start, end):
    """Extract tables that fall within the paragraph range."""
    tables_text = []
    # This is approximate — python-docx doesn't track table positions by paragraph index
    # We include all tables and let the caller filter
    for t_idx, table in enumerate(doc.tables):
        rows_text = []
        for row in table.rows:
            cells = [cell.text.strip()[:100] for cell in row.cells]
            rows_text.append(" | ".join(cells))
        if rows_text:
            tables_text.append("\n".join(rows_text))
    return tables_text


def main():
    parser = argparse.ArgumentParser(description="Extract a section from a Word document")
    parser.add_argument("--file", required=True, help="Word document path")
    parser.add_argument("--start", type=int, help="Start paragraph index")
    parser.add_argument("--end", type=int, help="End paragraph index")
    parser.add_argument("--heading", help="Find section by heading text (alternative to start/end)")
    parser.add_argument("--output", help="Output text file (prints to stdout if not set)")

    args = parser.parse_args()

    doc = Document(args.file)

    if args.heading:
        start, end = find_section_by_heading(doc, args.heading)
        if start is None:
            print(f"❌ Heading not found: '{args.heading}'", file=sys.stderr)
            # List available headings
            print("\nAvailable headings:", file=sys.stderr)
            for i, p in enumerate(doc.paragraphs):
                if p.style and "heading" in p.style.name.lower() and p.text.strip():
                    print(f"  P{i} [{p.style.name}]: {p.text.strip()[:80]}", file=sys.stderr)
            sys.exit(1)
    else:
        start = args.start or 0
        end = args.end or len(doc.paragraphs)

    text = extract_section(doc, start, end)
    word_count = len(text.split())

    if args.output:
        Path(args.output).parent.mkdir(parents=True, exist_ok=True)
        with open(args.output, "w", encoding="utf-8") as f:
            f.write(text)
        print(f"✅ Extracted {word_count} words (paras {start}-{end}) → {args.output}")
    else:
        print(text)
        print(f"\n--- {word_count} words, paragraphs {start}-{end} ---", file=sys.stderr)


if __name__ == "__main__":
    main()
