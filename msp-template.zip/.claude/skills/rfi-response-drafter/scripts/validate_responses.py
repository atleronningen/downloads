#!/usr/bin/env python3
"""
validate_responses.py — Pre-generation quality assurance check.

Validates the responses JSON before generating the final document.
Catches common issues: missing responses, empty key takeaways, commercial
questions without pricing caveats, win theme coverage, numbering gaps, etc.

Usage:
    python3 validate_responses.py --responses responses.json [--rfi-parsed rfi_parsed.json]

Output: Prints a QA report with issues categorized as ERROR (blocking),
WARNING (should fix), or INFO (advisory).
"""

import argparse
import json
import sys
import re
from pathlib import Path


def validate_responses(responses, rfi_parsed=None):
    """Run all validation checks on the responses JSON.
    
    Returns a dict with:
    - errors: List of blocking issues (should fix before generating)
    - warnings: List of quality issues (recommended to fix)
    - info: List of advisory notes
    - stats: Summary statistics
    """
    errors = []
    warnings = []
    info = []
    
    lang = responses.get("language", "en")
    customer = responses.get("customer", "")
    
    if not customer:
        errors.append("Missing 'customer' field in responses JSON")
    
    # Detect format: lot-based or flat
    is_lot_based = "lots" in responses and isinstance(responses.get("lots"), list)
    
    if is_lot_based:
        # Gather all sections from lot-based structure
        sections = list(responses.get("shared_sections", []))
        for lot in responses.get("lots", []):
            if lot.get("compliance_matrix"):
                sections.append(lot["compliance_matrix"])
            sections.extend(lot.get("sections", []))
        sections.extend(responses.get("shared_appendices", []))
        
        # Lot-specific checks
        lots = responses.get("lots", [])
        if not lots:
            errors.append("Lot-based format but 'lots' array is empty")
        for lot in lots:
            lid = lot.get("lot_id", "?")
            if not lot.get("lot_name"):
                warnings.append(f"{lid}: missing lot_name")
            if not lot.get("sections"):
                warnings.append(f"{lid}: no requirement sections")
            if not lot.get("consortium_lead"):
                info.append(f"{lid}: no consortium_lead specified (defaults to Sopra Steria)")
        
        if not responses.get("shared_sections"):
            warnings.append("No shared_sections — consider adding an introduction and executive summary")
    else:
        sections = responses.get("sections", [])
    
    if not sections:
        errors.append("No sections found in responses JSON")
        return {"errors": errors, "warnings": warnings, "info": info, "stats": {}}
    
    # --- Structural checks ---
    
    # Check section ordering
    section_types = [s.get("type", "?") for s in sections]
    
    has_exec_summary = "executive_summary" in section_types
    has_compliance = "compliance_matrix" in section_types
    has_appendix = "appendix" in section_types
    
    # Executive summary should be first (if present)
    if has_exec_summary:
        exec_idx = section_types.index("executive_summary")
        if exec_idx > 0:
            warnings.append(f"Executive summary is at position {exec_idx+1} — should be the first section")
    
    # Appendices should be last
    if has_appendix:
        first_appendix = section_types.index("appendix")
        non_appendix_after = [s for s in section_types[first_appendix:] if s != "appendix"]
        if non_appendix_after:
            warnings.append("Non-appendix sections found after the first appendix — appendices should be at the end")
    
    # --- Requirement checks ---
    
    requirements = [s for s in sections if s.get("type") == "requirement"]
    
    if not requirements:
        errors.append("No requirement sections found — the response has no actual answers")
    
    # Check each requirement
    missing_takeaways = []
    empty_content = []
    short_content = []
    
    for i, req in enumerate(requirements):
        heading = req.get("heading", f"(unnamed requirement {i+1})")
        
        # Missing key takeaway
        if not req.get("key_takeaway"):
            missing_takeaways.append(heading[:60])
        
        # Empty content
        content = req.get("content", "")
        if not content or not content.strip():
            empty_content.append(heading[:60])
        elif len(content.split()) < 30:
            short_content.append(f"{heading[:50]} ({len(content.split())} words)")
    
    if empty_content:
        errors.append(f"Requirements with NO content ({len(empty_content)}): {'; '.join(empty_content[:5])}")
    if missing_takeaways:
        warnings.append(f"Requirements missing key takeaway ({len(missing_takeaways)}): {'; '.join(missing_takeaways[:5])}")
    if short_content:
        warnings.append(f"Requirements with very short content <30 words ({len(short_content)}): {'; '.join(short_content[:5])}")
    
    # --- Word count limit checks ---
    
    word_limits = responses.get("word_limits", {})
    global_max_per_req = word_limits.get("max_words_per_requirement")
    global_max_total = word_limits.get("max_total_words")
    global_max_pages = word_limits.get("max_pages")  # ~250 words per page (Word, standard)
    
    if global_max_pages and not global_max_total:
        global_max_total = global_max_pages * 250
    
    over_limit = []
    for req in requirements:
        heading = req.get("heading", "(unnamed)")
        content = req.get("content", "")
        bullets = req.get("bullets", [])
        key_takeaway = req.get("key_takeaway", "")
        
        # Total words for this requirement: content + bullets + key takeaway
        req_words = len(content.split()) + sum(len(b.split()) for b in bullets) + len(key_takeaway.split())
        
        # Per-requirement override takes priority over global limit
        req_max = req.get("max_words") or global_max_per_req
        
        if req_max and req_words > req_max:
            overage = req_words - req_max
            pct = round(100 * overage / req_max)
            over_limit.append(f"{heading[:50]} ({req_words}/{req_max} words, +{pct}%)")
    
    if over_limit:
        warnings.append(f"Requirements exceeding word limit ({len(over_limit)}): {'; '.join(over_limit[:5])}")
    
    # Global total word count check
    total_words_all = sum(
        len(s.get("content", "").split()) +
        sum(len(b.split()) for b in s.get("bullets", [])) +
        len(s.get("key_takeaway", "").split())
        for s in sections if s.get("type") == "requirement"
    )
    
    if global_max_total and total_words_all > global_max_total:
        overage = total_words_all - global_max_total
        page_est = round(total_words_all / 250, 1)
        max_page_est = round(global_max_total / 250, 1)
        warnings.append(
            f"Total response word count ({total_words_all:,}) exceeds limit ({global_max_total:,}) "
            f"by {overage:,} words (~{page_est} pages vs ~{max_page_est} page limit)"
        )
    
    # --- Commercial question checks ---
    
    pricing_caveats = [
        "indicative", "subject to", "not a commitment", "detailed scoping",
        "broad market", "indikativ", "forbehold", "ikke bindende",
        "avhengig av", "nærmere avklaring",
    ]
    
    for req in requirements:
        content = (req.get("content", "") + " " + req.get("key_takeaway", "")).lower()
        heading = req.get("heading", "").lower()
        
        # Detect commercial questions by keyword
        commercial_kw = ["price", "pricing", "cost", "commercial", "pris", "kostnad", "honorar"]
        is_commercial = any(kw in heading for kw in commercial_kw)
        
        if is_commercial and content:
            has_caveat = any(c in content for c in pricing_caveats)
            if not has_caveat:
                warnings.append(f"Commercial question '{req.get('heading', '')[:50]}' may lack pricing caveats")
    
    # --- Compliance matrix checks ---
    
    if has_compliance:
        matrix = next(s for s in sections if s.get("type") == "compliance_matrix")
        matrix_rows = matrix.get("rows", [])
        
        if not matrix_rows:
            errors.append("Compliance matrix has no rows")
        else:
            # Check for missing statuses
            empty_status = [r for r in matrix_rows if not r.get("status")]
            if empty_status:
                errors.append(f"Compliance matrix: {len(empty_status)} rows with empty status")
            
            # Check that all requirements are covered
            if rfi_parsed:
                rfi_count = rfi_parsed.get("requirement_count", 0)
                if len(matrix_rows) < rfi_count:
                    warnings.append(f"Compliance matrix has {len(matrix_rows)} rows but RFI has {rfi_count} requirements — some may be missing")
    elif len(requirements) >= 5:
        info.append("Consider adding a compliance matrix — the response has 5+ requirements")
    
    # --- Executive summary checks ---
    
    if not has_exec_summary and len(requirements) >= 8:
        info.append("Consider adding an executive summary — the response has 8+ requirements")
    
    if has_exec_summary:
        exec_section = next(s for s in sections if s.get("type") == "executive_summary")
        if not exec_section.get("overview"):
            warnings.append("Executive summary has no overview text")
        if not exec_section.get("win_themes"):
            warnings.append("Executive summary has no win themes")
        if not exec_section.get("highlights"):
            warnings.append("Executive summary has no highlights table")
    
    # --- Win theme coverage check ---
    
    if has_exec_summary:
        exec_section = next(s for s in sections if s.get("type") == "executive_summary")
        win_themes = exec_section.get("win_themes", [])
        
        if win_themes and requirements:
            # Per-response win theme tracking
            theme_keywords = {}
            for idx, theme in enumerate(win_themes):
                # Extract 3–5 meaningful words per theme for matching
                words = [w.lower().strip(".,;:'\"") for w in theme.split() if len(w) > 4][:5]
                theme_keywords[idx] = words
            
            theme_coverage = {idx: [] for idx in range(len(win_themes))}
            uncovered_reqs = []
            
            for req in requirements:
                heading = req.get("heading", "")[:50]
                content = (req.get("content", "") + " " + req.get("key_takeaway", "")).lower()
                
                req_themes = []
                for t_idx, t_words in theme_keywords.items():
                    if t_words and any(w in content for w in t_words):
                        req_themes.append(t_idx)
                        theme_coverage[t_idx].append(heading)
                
                if not req_themes:
                    uncovered_reqs.append(heading)
            
            # Check 30% coverage rule per theme
            min_coverage = max(1, int(len(requirements) * 0.3))
            for t_idx, theme in enumerate(win_themes):
                covered = len(theme_coverage[t_idx])
                if covered == 0:
                    warnings.append(f"Win theme not found in any response: '{theme[:60]}'")
                elif covered < min_coverage:
                    warnings.append(
                        f"Win theme below 30% coverage ({covered}/{len(requirements)}): "
                        f"'{theme[:50]}'"
                    )
            
            if uncovered_reqs and len(uncovered_reqs) > len(requirements) * 0.5:
                warnings.append(
                    f"{len(uncovered_reqs)}/{len(requirements)} requirements have no win theme "
                    f"threading: {'; '.join(uncovered_reqs[:3])}"
                )
    
    # --- Heading numbering check ---
    
    headings = [req.get("heading", "") for req in requirements]
    numbered = [h for h in headings if re.match(r'^\d', h)]
    if numbered:
        # Check for sequential numbering
        numbers = []
        for h in numbered:
            m = re.match(r'^([\d.]+)', h)
            if m:
                numbers.append(m.group(1))
        
        if len(numbers) > 1:
            # Simple check: are there gaps?
            for i in range(1, len(numbers)):
                # This is a heuristic — just check the numbers are progressing
                if numbers[i] == numbers[i-1]:
                    warnings.append(f"Duplicate heading number: '{numbers[i]}' appears twice")
    
    # --- Table numbering check ---
    
    table_captions = []
    for s in sections:
        if s.get("type") == "requirement" and s.get("tables"):
            for t in s["tables"]:
                if t.get("caption"):
                    table_captions.append(t["caption"])
        if s.get("type") == "table" and s.get("caption"):
            table_captions.append(s["caption"])
    
    if table_captions:
        table_nums = []
        for cap in table_captions:
            m = re.search(r'[Tt]able\s+(\d+)', cap)
            if m:
                table_nums.append(int(m.group(1)))
        if table_nums and table_nums != sorted(table_nums):
            warnings.append(f"Table numbering may not be sequential: {table_nums}")
        if table_nums and len(table_nums) != len(set(table_nums)):
            warnings.append("Duplicate table numbers detected")
    
    # --- Figure placeholder check ---
    
    figures = [s for s in sections if s.get("type") == "figure_placeholder"]
    if figures:
        fig_nums = [f.get("figure_number", 0) for f in figures]
        if fig_nums != sorted(fig_nums):
            warnings.append(f"Figure numbering not sequential: {fig_nums}")
        
        # Check that figures are referenced in content
        all_text = " ".join(s.get("content", "") for s in sections if s.get("content"))
        for fig in figures:
            fig_num = fig.get("figure_number", "?")
            if f"Figure {fig_num}" not in all_text and f"Figur {fig_num}" not in all_text:
                warnings.append(f"Figure {fig_num} may not be referenced in the narrative text")
    
    # --- Language consistency ---
    
    if lang == "no":
        # Check each requirement for English content in a Norwegian document
        # Use common English function words that rarely appear in Norwegian prose
        en_markers = [
            " the ", " is ", " are ", " was ", " were ", " has ", " have ",
            " this ", " that ", " with ", " from ", " which ", " their ",
            " would ", " should ", " could ", " been ", " being ",
            " through ", " between ", " however ", " therefore ",
            " ensure ", " provide ", " deliver ",
        ]
        mixed_lang_reqs = []
        for req in requirements:
            content = req.get("content", "").lower()
            if not content or len(content) < 50:
                continue
            hits = sum(1 for m in en_markers if m in content)
            # 5+ hits strongly suggests English text
            if hits >= 5:
                mixed_lang_reqs.append(req.get("heading", "")[:40])
        if mixed_lang_reqs:
            warnings.append(
                f"Likely English text in Norwegian document ({len(mixed_lang_reqs)} requirements): "
                f"{'; '.join(mixed_lang_reqs[:3])}"
            )
    
    elif lang == "en":
        # Check for Norwegian content in an English document
        no_markers = [
            " og ", " er ", " som ", " til ", " på ", " av ",
            " med ", " kan ", " har ", " vil ", " skal ",
            " denne ", " dette ", " disse ", " også ",
        ]
        mixed_lang_reqs = []
        for req in requirements:
            content = req.get("content", "").lower()
            if not content or len(content) < 50:
                continue
            hits = sum(1 for m in no_markers if m in content)
            if hits >= 5:
                mixed_lang_reqs.append(req.get("heading", "")[:40])
        if mixed_lang_reqs:
            warnings.append(
                f"Likely Norwegian text in English document ({len(mixed_lang_reqs)} requirements): "
                f"{'; '.join(mixed_lang_reqs[:3])}"
            )
    
    # --- Confidence scoring check ---
    
    # If requirements have confidence tags, summarise the distribution
    confidence_counts = {"high": 0, "medium": 0, "low": 0}
    low_confidence_reqs = []
    has_confidence = False
    for req in requirements:
        conf = req.get("confidence", "").lower()
        if conf in confidence_counts:
            has_confidence = True
            confidence_counts[conf] += 1
            if conf == "low":
                low_confidence_reqs.append(req.get("heading", "")[:50])
    
    if has_confidence:
        if low_confidence_reqs:
            warnings.append(
                f"Low-confidence responses ({len(low_confidence_reqs)}) — "
                f"prioritise SME review: {'; '.join(low_confidence_reqs[:3])}"
            )
        info.append(
            f"Confidence distribution: {confidence_counts['high']} high, "
            f"{confidence_counts['medium']} medium, {confidence_counts['low']} low"
        )
    
    # --- Company overview check ---
    
    has_company_overview = any(s.get("type") == "company_overview" for s in sections)
    if not has_company_overview and len(requirements) >= 3:
        info.append("Consider adding a company_overview section (About Sopra Steria / About DPS)")
    
    # --- Stats ---
    
    total_words = sum(len(s.get("content", "").split()) for s in sections if s.get("content"))
    
    stats = {
        "total_sections": len(sections),
        "requirements": len(requirements),
        "lots": len(responses.get("lots", [])) if is_lot_based else 0,
        "tables": sum(
            len(s.get("tables", [])) for s in sections if s.get("tables")
        ),
        "figures": len(figures),
        "appendices": sum(1 for s in sections if s.get("type") == "appendix"),
        "has_executive_summary": has_exec_summary,
        "has_compliance_matrix": has_compliance,
        "has_company_overview": has_company_overview,
        "total_response_words": total_words,
        "word_limit_per_req": global_max_per_req,
        "word_limit_total": global_max_total,
        "reqs_over_limit": len(over_limit),
        "confidence": confidence_counts if has_confidence else None,
        "errors": len(errors),
        "warnings": len(warnings),
    }
    
    return {"errors": errors, "warnings": warnings, "info": info, "stats": stats}


def format_qa_report(result):
    """Format the QA result as a readable report."""
    lines = ["# Pre-Generation QA Report\n"]
    
    stats = result["stats"]
    lines.append(f"📊 **Document stats**: {stats['requirements']} requirements, "
                 f"{stats['tables']} tables, {stats['figures']} figures, "
                 f"{stats['appendices']} appendices, ~{stats['total_response_words']:,} words")
    lot_str = f"Lots: {stats['lots']} | " if stats.get("lots") else ""
    lines.append(f"   {lot_str}Executive summary: {'✅' if stats['has_executive_summary'] else '❌'} | "
                 f"Compliance matrix: {'✅' if stats['has_compliance_matrix'] else '❌'} | "
                 f"Company overview: {'✅' if stats.get('has_company_overview') else '❌'}")
    if stats.get("word_limit_per_req") or stats.get("word_limit_total"):
        limit_parts = []
        if stats.get("word_limit_per_req"):
            limit_parts.append(f"{stats['word_limit_per_req']} words/requirement")
        if stats.get("word_limit_total"):
            pages = round(stats['word_limit_total'] / 250, 1)
            limit_parts.append(f"{stats['word_limit_total']:,} total (~{pages} pages)")
        over = stats.get("reqs_over_limit", 0)
        status = f"⚠️ {over} over limit" if over else "✅ all within limits"
        lines.append(f"   Word limits: {' | '.join(limit_parts)} — {status}")
    if stats.get("confidence"):
        c = stats["confidence"]
        lines.append(f"   Confidence: 🟢 {c['high']} high | 🟡 {c['medium']} medium | 🔴 {c['low']} low")
    lines.append("")
    
    if result["errors"]:
        lines.append(f"## ❌ Errors ({len(result['errors'])})\n")
        for e in result["errors"]:
            lines.append(f"- **ERROR**: {e}")
        lines.append("")
    
    if result["warnings"]:
        lines.append(f"## ⚠️ Warnings ({len(result['warnings'])})\n")
        for w in result["warnings"]:
            lines.append(f"- **WARNING**: {w}")
        lines.append("")
    
    if result["info"]:
        lines.append(f"## ℹ️ Info ({len(result['info'])})\n")
        for i in result["info"]:
            lines.append(f"- {i}")
        lines.append("")
    
    if not result["errors"] and not result["warnings"]:
        lines.append("## ✅ All checks passed!\n")
        lines.append("The responses JSON looks good — ready to generate.")
    elif not result["errors"]:
        lines.append("---\n")
        lines.append("No blocking errors. Warnings are advisory — you can generate now or fix them first.")
    else:
        lines.append("---\n")
        lines.append("⛔ **Blocking errors found.** Fix these before generating the document.")
    
    return "\n".join(lines)


def main():
    parser = argparse.ArgumentParser(description="Pre-generation QA check")
    parser.add_argument("--responses", required=True, help="Path to responses JSON")
    parser.add_argument("--rfi-parsed", help="Optional: path to parsed RFI JSON (for cross-reference checks)")
    parser.add_argument("--output", help="Write QA report to this file (prints to stdout if not set)")
    
    args = parser.parse_args()
    
    with open(args.responses, "r", encoding="utf-8") as f:
        responses = json.load(f)
    
    rfi_parsed = None
    if args.rfi_parsed:
        with open(args.rfi_parsed, "r", encoding="utf-8") as f:
            rfi_parsed = json.load(f)
    
    result = validate_responses(responses, rfi_parsed)
    report = format_qa_report(result)
    
    if args.output:
        Path(args.output).parent.mkdir(parents=True, exist_ok=True)
        with open(args.output, "w", encoding="utf-8") as f:
            f.write(report)
        print(f"✅ QA report: {args.output}")
    else:
        print(report)
    
    # Exit with error code if blocking issues found
    if result["errors"]:
        sys.exit(1)


if __name__ == "__main__":
    main()
