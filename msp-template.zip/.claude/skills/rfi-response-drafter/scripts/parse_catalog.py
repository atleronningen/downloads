#!/usr/bin/env python3
"""
parse_catalog.py — Build a lightweight product index from Sopra Steria catalog documents.

Extracts a structured index of products/services from one or more Word documents,
producing a compact JSON summary suitable for loading into Claude's context.

Usage:
    python3 parse_catalog.py --files doc1.docx doc2.docx [doc3.docx] --output index.json

Output: JSON with product hierarchy, names, codes, and 1-2 sentence summaries.
"""

import argparse
import json
import sys
import re
import hashlib
import os
from pathlib import Path
from datetime import datetime, timezone

try:
    from docx import Document
except ImportError:
    import subprocess
    subprocess.check_call([sys.executable, "-m", "pip", "install", "python-docx", "--break-system-packages", "-q"])
    from docx import Document


def extract_heading_tree(doc_path):
    """Extract a heading-based tree structure from a Word document."""
    doc = Document(doc_path)
    entries = []

    for i, para in enumerate(doc.paragraphs):
        style_name = para.style.name.lower() if para.style else ""
        text = para.text.strip()
        if not text:
            continue

        level = None
        if "heading 1" in style_name:
            level = 1
        elif "heading 2" in style_name:
            level = 2
        elif "heading 3" in style_name:
            level = 3
        elif "subheading" in style_name:
            level = 4

        if level is not None:
            entries.append({
                "para_idx": i,
                "level": level,
                "text": text,
            })

    return entries, doc


def summarise_section(doc, start_idx, end_idx, max_chars=300):
    """Extract a short summary from the first few content paragraphs of a section."""
    summary_parts = []
    chars = 0
    for i in range(start_idx + 1, min(end_idx, start_idx + 15)):
        para = doc.paragraphs[i]
        style_name = para.style.name.lower() if para.style else ""
        text = para.text.strip()

        # Skip headings, captions, empty
        if not text or "heading" in style_name or "caption" in style_name:
            continue
        # Skip very short lines (likely labels)
        if len(text) < 20:
            continue

        summary_parts.append(text)
        chars += len(text)
        if chars >= max_chars:
            break

    full = " ".join(summary_parts)
    if len(full) > max_chars:
        full = full[:max_chars].rsplit(" ", 1)[0] + "…"
    return full


def collect_section_text(doc, start_idx, end_idx):
    """Collect all text content from a section for keyword extraction."""
    texts = []
    for i in range(start_idx, min(end_idx, len(doc.paragraphs))):
        para = doc.paragraphs[i]
        text = para.text.strip()
        if text and len(text) > 5:
            texts.append(text)
    return " ".join(texts)


# ---- Keyword extraction ----

# Stopwords for both English and Norwegian — compact set covering the most common
STOPWORDS = {
    # English
    "the", "a", "an", "and", "or", "but", "in", "on", "at", "to", "for", "of", "with",
    "by", "from", "is", "are", "was", "were", "be", "been", "being", "have", "has", "had",
    "do", "does", "did", "will", "would", "shall", "should", "may", "might", "can", "could",
    "not", "no", "this", "that", "these", "those", "it", "its", "we", "our", "you", "your",
    "their", "they", "he", "she", "all", "each", "every", "both", "any", "such", "more",
    "most", "other", "some", "than", "when", "where", "which", "who", "what", "how", "if",
    "as", "so", "up", "out", "also", "very", "just", "about", "over", "into", "through",
    "between", "after", "before", "during", "under", "above", "below", "then", "there",
    "here", "only", "own", "same", "new", "used", "use", "using", "based", "within",
    "across", "well", "including", "includes", "include", "ensure", "ensures", "ensuring",
    "provide", "provides", "providing", "support", "supports", "supporting", "e.g", "i.e",
    "etc", "per", "via", "see", "key", "part", "set", "following", "related", "relevant",
    # Norwegian
    "og", "er", "i", "på", "for", "av", "med", "til", "fra", "som", "en", "et", "den",
    "det", "de", "har", "vil", "kan", "skal", "må", "om", "ikke", "ved", "eller", "seg",
    "sin", "sitt", "sine", "var", "bli", "blir", "blitt", "ble", "alle", "andre", "dette",
    "denne", "disse", "noen", "hver", "mange", "mer", "mest", "også", "etter", "under",
    "over", "mellom", "gjennom", "mot", "når", "hvor", "slik", "samt", "herunder",
    # Generic IT/document noise — too common to be distinctive
    "service", "services", "solution", "solutions", "management", "system", "systems",
    "customer", "customers", "data", "information", "process", "processes", "level",
    "model", "platform", "digital", "technology", "organisation", "organization",
    "delivery", "standard", "practice", "practices", "approach", "capability",
    "description", "table", "figure", "page", "document", "section", "appendix",
}


def extract_keywords(text, max_keywords=30):
    """Extract distinctive keywords/phrases from section text using term frequency.
    
    Returns a list of (term, count) tuples sorted by relevance.
    Captures both single words and 2-word phrases (bigrams) that look like
    domain terms (e.g. 'azure kubernetes', 'service desk', 'zero trust').
    """
    import re
    from collections import Counter
    
    text_lower = text.lower()
    # Tokenize: keep alphanumeric, hyphens, dots (for product codes like MS0201-001)
    tokens = re.findall(r'[a-zA-Z0-9][\w.-]*[a-zA-Z0-9]|[a-zA-Z0-9]', text_lower)
    
    # Single-word terms (exclude stopwords and very short tokens)
    meaningful = [t for t in tokens if t not in STOPWORDS and len(t) > 2]
    word_counts = Counter(meaningful)
    
    # Bigrams — capture multi-word domain terms
    bigrams = []
    for i in range(len(tokens) - 1):
        a, b = tokens[i], tokens[i + 1]
        if a not in STOPWORDS and b not in STOPWORDS and len(a) > 2 and len(b) > 2:
            bigrams.append(f"{a} {b}")
    bigram_counts = Counter(bigrams)
    
    # Combine: bigrams with count >= 2 are strong signals, singles by frequency
    results = {}
    for term, count in bigram_counts.items():
        if count >= 2:
            results[term] = count * 3  # Boost bigrams — they're more specific
    for term, count in word_counts.items():
        if count >= 2 and term not in results:
            results[term] = count
    
    # Sort by score, take top N
    sorted_terms = sorted(results.items(), key=lambda x: -x[1])
    return sorted_terms[:max_keywords]


def extract_capability_tags(text):
    """Extract high-level capability tags from section text.
    
    These are broad categories that help match requirements to products
    at a higher abstraction level than keywords.
    """
    text_lower = text.lower()
    
    tag_patterns = {
        "cloud": ["cloud", "azure", "aws", "gcp", "iaas", "paas", "saas", "hybrid cloud", "multi-cloud"],
        "workplace": ["workplace", "end-user", "end user", "laptop", "desktop", "device", "vdi", "digital workplace"],
        "identity": ["identity", "access management", "iam", "iga", "entra", "active directory", "sso", "mfa", "privileged"],
        "security": ["security", "soc", "siem", "soar", "threat", "vulnerability", "cyber", "zero trust", "penetration", "endpoint detection"],
        "network": ["network", "lan", "wan", "wifi", "wlan", "sd-wan", "firewall", "connectivity", "routing", "switching"],
        "monitoring": ["monitoring", "observability", "alerting", "aiops", "dashboar", "event correlation", "log management"],
        "service_management": ["itsm", "itil", "servicenow", "siam", "service integration", "service desk", "incident", "problem", "change management"],
        "application": ["application management", "application operations", "application lifecycle", "devops", "ci/cd", "containeriz"],
        "collaboration": ["microsoft 365", "m365", "teams", "sharepoint", "copilot", "exchange", "onedrive", "collaboration"],
        "finops": ["finops", "cost optimi", "cost management", "license", "rightsiz", "cloud spend", "tbm"],
        "automation": ["automat", "self-service", "self service", "chatbot", "ai-driven", "ai-powered", "robotic", "rpa"],
        "governance": ["governance", "compliance", "audit", "risk management", "iso 27001", "isae", "gdpr", "nis2"],
        "transition": ["transition", "migration", "onboarding", "establishment", "navigator", "cmo", "tmo", "fmo"],
        "printing": ["print", "printing", "printer", "mps", "managed print"],
        "database": ["database", "sql", "oracle", "postgresql", "mysql", "db2", "data platform"],
        "backup": ["backup", "recovery", "disaster recovery", "business continuity", "dr", "archiv"],
        "service_desk": ["service desk", "servicedesk", "helpdesk", "help desk", "support", "first line", "second line", "l1", "l2"],
    }
    
    tags = []
    for tag, patterns in tag_patterns.items():
        if any(p in text_lower for p in patterns):
            tags.append(tag)
    
    return tags


def fingerprint_files(file_paths):
    """Compute a combined fingerprint (SHA-256) for a set of catalog files.
    
    Returns a dict with per-file hashes, a combined hash, and timestamps.
    This is embedded in the product index JSON so staleness can be detected later.
    """
    file_info = []
    hasher = hashlib.sha256()
    
    for fpath in sorted(file_paths):
        fpath = Path(fpath)
        with open(fpath, "rb") as f:
            file_bytes = f.read()
        file_hash = hashlib.sha256(file_bytes).hexdigest()[:16]
        hasher.update(file_bytes)
        
        stat = os.stat(fpath)
        file_info.append({
            "name": fpath.name,
            "hash": file_hash,
            "size_bytes": stat.st_size,
            "modified": datetime.fromtimestamp(stat.st_mtime, tz=timezone.utc).isoformat(),
        })
    
    return {
        "combined_hash": hasher.hexdigest()[:16],
        "built_at": datetime.now(timezone.utc).isoformat(),
        "files": file_info,
    }


def check_index_freshness(index_path, upload_dir="/mnt/user-data/uploads"):
    """Check if the product index is still fresh against current uploads.
    
    Compares the stored file fingerprints against the actual files in the uploads directory.
    
    Returns a dict:
    - fresh: True if all indexed files match their current hashes
    - stale_files: list of filenames that have changed
    - missing_files: list of indexed files no longer present in uploads
    - new_catalog_files: list of catalog-looking files in uploads not in the index
    
    Usage from bash:
        python3 parse_catalog.py --check-freshness /home/claude/product_index.json
    """
    with open(index_path, "r", encoding="utf-8") as f:
        index = json.load(f)
    
    fingerprint = index.get("fingerprint")
    if not fingerprint:
        return {"fresh": False, "reason": "Index has no fingerprint (built before staleness tracking was added)",
                "stale_files": [], "missing_files": [], "new_catalog_files": []}
    
    upload_dir = Path(upload_dir)
    stale = []
    missing = []
    
    for fi in fingerprint.get("files", []):
        fpath = upload_dir / fi["name"]
        if not fpath.exists():
            missing.append(fi["name"])
            continue
        
        with open(fpath, "rb") as f:
            current_hash = hashlib.sha256(f.read()).hexdigest()[:16]
        
        if current_hash != fi["hash"]:
            stale.append(fi["name"])
    
    # Check for new catalog-like files that weren't indexed
    indexed_names = {fi["name"] for fi in fingerprint.get("files", [])}
    new_files = []
    if upload_dir.exists():
        catalog_patterns = ["appendix", "catalog", "catalogue", "portfolio", "service", "solution"]
        for f in upload_dir.iterdir():
            if f.suffix.lower() == ".docx" and f.name not in indexed_names:
                name_lower = f.name.lower()
                if any(p in name_lower for p in catalog_patterns):
                    new_files.append(f.name)
    
    fresh = not stale and not missing
    return {
        "fresh": fresh,
        "stale_files": stale,
        "missing_files": missing,
        "new_catalog_files": new_files,
        "index_built_at": fingerprint.get("built_at", "unknown"),
    }


def build_index(files):
    """Build a product index from one or more catalog documents."""
    index = {
        "catalog_files": [],
        "products": [],
        "sections": [],
    }

    for fpath in files:
        fpath = Path(fpath)
        index["catalog_files"].append(fpath.name)

        headings, doc = extract_heading_tree(fpath)
        total_paras = len(doc.paragraphs)

        for i, entry in enumerate(headings):
            # Determine end of this section
            end_idx = total_paras
            for j in range(i + 1, len(headings)):
                if headings[j]["level"] <= entry["level"]:
                    end_idx = headings[j]["para_idx"]
                    break

            # Count content words
            word_count = sum(
                len(doc.paragraphs[k].text.split())
                for k in range(entry["para_idx"], end_idx)
            )

            summary = summarise_section(doc, entry["para_idx"], end_idx)
            
            # Collect full section text for keyword extraction
            section_text = collect_section_text(doc, entry["para_idx"], end_idx)
            
            # Extract keywords and capability tags
            keywords = extract_keywords(section_text, max_keywords=25)
            capability_tags = extract_capability_tags(section_text)

            section_entry = {
                "file": fpath.name,
                "heading": entry["text"],
                "level": entry["level"],
                "para_start": entry["para_idx"],
                "para_end": end_idx,
                "word_count": word_count,
                "summary": summary,
                "keywords": [term for term, count in keywords],
                "keyword_scores": {term: count for term, count in keywords},
                "capability_tags": capability_tags,
            }

            # Detect MS product codes (e.g. MS01, MS0901-001)
            ms_match = re.match(r"(MS\d{2,4}(?:-\d{3})?)\s*[–-]\s*(.+)", entry["text"])
            if ms_match:
                section_entry["product_code"] = ms_match.group(1)
                section_entry["product_name"] = ms_match.group(2).strip()
                # Determine parent code for sub-products (e.g. MS0201 → MS02)
                code = ms_match.group(1)
                if len(code) > 4:
                    section_entry["parent_code"] = code[:4]
                index["products"].append(section_entry)
            else:
                index["sections"].append(section_entry)

    # Sort products by code
    index["products"].sort(key=lambda x: x.get("product_code", ""))
    
    # Embed file fingerprint for staleness detection
    index["fingerprint"] = fingerprint_files(files)

    return index


def format_compact_index(index):
    """Produce a compact text version of the index for context loading.
    
    Includes auto-extracted keywords and capability tags for each product,
    enabling accurate requirement-to-product matching.
    """
    lines = ["# Sopra Steria Product Catalog Index\n"]
    lines.append(f"Source files: {', '.join(index['catalog_files'])}")
    fp = index.get("fingerprint", {})
    if fp.get("built_at"):
        lines.append(f"Built: {fp['built_at']} | Hash: {fp.get('combined_hash', '?')}")
    lines.append("")

    # Products — grouped by top-level code
    if index["products"]:
        lines.append("## Products & Services\n")
        current_top = None
        for p in index["products"]:
            code = p.get("product_code", "")
            # Group by top-level MS code (first 4 chars)
            top = code[:4] if len(code) >= 4 else code
            
            tags = p.get("capability_tags", [])
            keywords = p.get("keywords", [])
            
            if top != current_top:
                current_top = top
                lines.append(f"\n### {p['heading']}")
                if p["summary"]:
                    lines.append(f"  {p['summary']}")
                if tags:
                    lines.append(f"  Capabilities: {', '.join(tags)}")
                if keywords:
                    lines.append(f"  Keywords: {', '.join(keywords[:15])}")
                lines.append(f"  [{p['word_count']} words | paras {p['para_start']}-{p['para_end']} in {p['file']}]")
            else:
                # Sub-product
                sub_info = f"  - {code}: {p.get('product_name', p['heading'])} ({p['word_count']} words)"
                if tags:
                    sub_info += f" [{', '.join(tags)}]"
                lines.append(sub_info)
                if keywords:
                    lines.append(f"    Keywords: {', '.join(keywords[:10])}")

    # Key non-product sections
    if index["sections"]:
        lines.append("\n## Other Sections\n")
        for s in index["sections"]:
            if s["level"] <= 2 and s["word_count"] > 100:
                tags = s.get("capability_tags", [])
                tag_str = f" [{', '.join(tags)}]" if tags else ""
                lines.append(f"- **{s['heading']}** ({s['word_count']} words, {s['file']}){tag_str}")
                if s["summary"]:
                    lines.append(f"  {s['summary']}")

    return "\n".join(lines)


def main():
    parser = argparse.ArgumentParser(description="Build product catalog index")
    parser.add_argument("--files", nargs="+", help="Catalog .docx files")
    parser.add_argument("--output", help="Output JSON path")
    parser.add_argument("--compact", help="Also write a compact text index to this path")
    parser.add_argument("--check-freshness", dest="check_freshness",
                        help="Check if an existing index is still fresh (pass index JSON path)")

    args = parser.parse_args()

    # Freshness check mode
    if args.check_freshness:
        result = check_index_freshness(args.check_freshness)
        if result["fresh"]:
            print(f"✅ Product index is fresh (built {result.get('index_built_at', '?')})")
        else:
            reason = result.get("reason", "")
            if reason:
                print(f"⚠️  {reason}")
            if result["stale_files"]:
                print(f"⚠️  Changed files: {', '.join(result['stale_files'])}")
            if result["missing_files"]:
                print(f"⚠️  Missing files: {', '.join(result['missing_files'])}")
            if result.get("new_catalog_files"):
                print(f"ℹ️  New catalog-like files not in index: {', '.join(result['new_catalog_files'])}")
            print("→ Rebuild the index with --files to pick up changes.")
        # Output as JSON for programmatic use
        print(json.dumps(result, indent=2))
        sys.exit(0 if result["fresh"] else 1)

    # Normal build mode
    if not args.files or not args.output:
        parser.error("--files and --output are required for building an index")

    index = build_index(args.files)

    # Write JSON
    output_path = Path(args.output)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(index, f, ensure_ascii=False, indent=2)
    print(f"✅ Index saved: {output_path} ({len(index['products'])} products, {len(index['sections'])} sections)")

    # Write compact text version
    if args.compact:
        compact_path = Path(args.compact)
        compact_text = format_compact_index(index)
        with open(compact_path, "w", encoding="utf-8") as f:
            f.write(compact_text)
        print(f"✅ Compact index: {compact_path}")


if __name__ == "__main__":
    main()
