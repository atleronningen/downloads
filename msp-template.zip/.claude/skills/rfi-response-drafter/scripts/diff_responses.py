#!/usr/bin/env python3
"""
diff_responses.py — Compare two versions of an RFI responses JSON and produce a changelog.

Tracks what changed between refinement rounds: added/removed requirements,
content changes, word count deltas, and status changes. Useful for bid review
meetings and audit trails.

Usage:
    python3 diff_responses.py --old v1_responses.json --new v2_responses.json [--output changelog.md]

If --output is not set, prints to stdout.

The changelog can also be embedded in the responses JSON itself (see --embed mode).
"""

import argparse
import json
import sys
import re
from pathlib import Path
from datetime import datetime, timezone


def extract_requirements(responses):
    """Extract all requirement sections from a responses JSON (flat or lot-based)."""
    reqs = {}
    
    is_lot_based = "lots" in responses and isinstance(responses.get("lots"), list)
    
    if is_lot_based:
        sections = list(responses.get("shared_sections", []))
        for lot in responses.get("lots", []):
            sections.extend(lot.get("sections", []))
        sections.extend(responses.get("shared_appendices", []))
    else:
        sections = responses.get("sections", [])
    
    for s in sections:
        if s.get("type") == "requirement":
            heading = s.get("heading", "")
            # Use heading as key; if numbered, extract number for stable matching
            num_match = re.match(r'^([\d.]+)', heading)
            key = num_match.group(1) if num_match else heading.strip()[:80]
            reqs[key] = s
    
    return reqs


def word_count(text):
    """Count words in a string, handling None gracefully."""
    if not text:
        return 0
    return len(text.split())


def diff_requirement(old_req, new_req):
    """Compare two versions of the same requirement. Returns a change dict or None if identical."""
    changes = {}
    
    # Key takeaway
    old_kt = (old_req.get("key_takeaway") or "").strip()
    new_kt = (new_req.get("key_takeaway") or "").strip()
    if old_kt != new_kt:
        changes["key_takeaway"] = {"old": old_kt[:100], "new": new_kt[:100]}
    
    # Content
    old_content = (old_req.get("content") or "").strip()
    new_content = (new_req.get("content") or "").strip()
    if old_content != new_content:
        old_wc = word_count(old_content)
        new_wc = word_count(new_content)
        delta = new_wc - old_wc
        sign = "+" if delta > 0 else ""
        changes["content"] = {
            "old_words": old_wc,
            "new_words": new_wc,
            "delta": f"{sign}{delta}",
            "changed": True,
        }
        
        # Detect type of change by comparing first/last sentences
        old_sentences = [s.strip() for s in re.split(r'[.!?]\s', old_content) if s.strip()]
        new_sentences = [s.strip() for s in re.split(r'[.!?]\s', new_content) if s.strip()]
        
        if old_sentences and new_sentences:
            if old_sentences[0] != new_sentences[0]:
                changes["content"]["opening_changed"] = True
            if old_sentences[-1] != new_sentences[-1]:
                changes["content"]["closing_changed"] = True
    
    # Bullets
    old_bullets = old_req.get("bullets", [])
    new_bullets = new_req.get("bullets", [])
    if old_bullets != new_bullets:
        added = [b for b in new_bullets if b not in old_bullets]
        removed = [b for b in old_bullets if b not in new_bullets]
        if added or removed:
            changes["bullets"] = {"added": len(added), "removed": len(removed)}
    
    # Tables
    old_tables = len(old_req.get("tables", []))
    new_tables = len(new_req.get("tables", []))
    if old_tables != new_tables:
        changes["tables"] = {"old": old_tables, "new": new_tables}
    
    # Max words limit
    old_max = old_req.get("max_words")
    new_max = new_req.get("max_words")
    if old_max != new_max:
        changes["max_words"] = {"old": old_max, "new": new_max}
    
    return changes if changes else None


def diff_responses(old_path, new_path):
    """Compare two responses JSON files and produce a structured changelog."""
    with open(old_path, "r", encoding="utf-8") as f:
        old = json.load(f)
    with open(new_path, "r", encoding="utf-8") as f:
        new = json.load(f)
    
    old_reqs = extract_requirements(old)
    new_reqs = extract_requirements(new)
    
    old_keys = set(old_reqs.keys())
    new_keys = set(new_reqs.keys())
    
    added = new_keys - old_keys
    removed = old_keys - new_keys
    common = old_keys & new_keys
    
    # Diff common requirements
    modified = {}
    unchanged = []
    for key in sorted(common):
        changes = diff_requirement(old_reqs[key], new_reqs[key])
        if changes:
            heading = new_reqs[key].get("heading", key)
            modified[key] = {"heading": heading, "changes": changes}
        else:
            unchanged.append(key)
    
    # Global metadata changes
    meta_changes = {}
    for field in ["customer", "rfi_title", "language"]:
        old_val = old.get(field, "")
        new_val = new.get(field, "")
        if old_val != new_val:
            meta_changes[field] = {"old": old_val, "new": new_val}
    
    # Word count totals
    old_total = sum(word_count(r.get("content")) for r in old_reqs.values())
    new_total = sum(word_count(r.get("content")) for r in new_reqs.values())
    
    # Word limits changes
    old_limits = old.get("word_limits", {})
    new_limits = new.get("word_limits", {})
    limit_changes = {}
    for field in ["max_words_per_requirement", "max_total_words", "max_pages"]:
        if old_limits.get(field) != new_limits.get(field):
            limit_changes[field] = {"old": old_limits.get(field), "new": new_limits.get(field)}
    
    changelog = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "old_file": str(old_path),
        "new_file": str(new_path),
        "summary": {
            "total_requirements_old": len(old_reqs),
            "total_requirements_new": len(new_reqs),
            "added": len(added),
            "removed": len(removed),
            "modified": len(modified),
            "unchanged": len(unchanged),
            "total_words_old": old_total,
            "total_words_new": new_total,
            "word_delta": new_total - old_total,
        },
        "meta_changes": meta_changes,
        "word_limit_changes": limit_changes,
        "added_requirements": [
            {"key": k, "heading": new_reqs[k].get("heading", k)} for k in sorted(added)
        ],
        "removed_requirements": [
            {"key": k, "heading": old_reqs[k].get("heading", k)} for k in sorted(removed)
        ],
        "modified_requirements": modified,
        "unchanged_keys": sorted(unchanged),
    }
    
    return changelog


def format_changelog_md(changelog):
    """Format the changelog as a readable Markdown report."""
    lines = ["# RFI Response Changelog\n"]
    lines.append(f"Generated: {changelog['generated_at']}")
    lines.append(f"Comparing: `{Path(changelog['old_file']).name}` → `{Path(changelog['new_file']).name}`\n")
    
    s = changelog["summary"]
    delta_sign = "+" if s["word_delta"] > 0 else ""
    lines.append(f"## Summary\n")
    lines.append(f"| Metric | Old | New | Delta |")
    lines.append(f"|--------|-----|-----|-------|")
    lines.append(f"| Requirements | {s['total_requirements_old']} | {s['total_requirements_new']} | {s['total_requirements_new'] - s['total_requirements_old']:+d} |")
    lines.append(f"| Total words | {s['total_words_old']:,} | {s['total_words_new']:,} | {delta_sign}{s['word_delta']:,} |")
    lines.append(f"| Modified | — | — | {s['modified']} |")
    lines.append(f"| Unchanged | — | — | {s['unchanged']} |")
    lines.append("")
    
    # Meta changes
    if changelog.get("meta_changes"):
        lines.append("## Metadata Changes\n")
        for field, change in changelog["meta_changes"].items():
            lines.append(f"- **{field}**: `{change['old']}` → `{change['new']}`")
        lines.append("")
    
    # Word limit changes
    if changelog.get("word_limit_changes"):
        lines.append("## Word Limit Changes\n")
        for field, change in changelog["word_limit_changes"].items():
            lines.append(f"- **{field}**: `{change['old']}` → `{change['new']}`")
        lines.append("")
    
    # Added
    if changelog["added_requirements"]:
        lines.append(f"## ➕ Added Requirements ({len(changelog['added_requirements'])})\n")
        for r in changelog["added_requirements"]:
            lines.append(f"- **{r['key']}**: {r['heading']}")
        lines.append("")
    
    # Removed
    if changelog["removed_requirements"]:
        lines.append(f"## ➖ Removed Requirements ({len(changelog['removed_requirements'])})\n")
        for r in changelog["removed_requirements"]:
            lines.append(f"- **{r['key']}**: {r['heading']}")
        lines.append("")
    
    # Modified
    if changelog["modified_requirements"]:
        lines.append(f"## ✏️ Modified Requirements ({len(changelog['modified_requirements'])})\n")
        for key, info in sorted(changelog["modified_requirements"].items()):
            heading = info["heading"]
            changes = info["changes"]
            lines.append(f"### {key}: {heading}\n")
            
            if "key_takeaway" in changes:
                kt = changes["key_takeaway"]
                lines.append(f"- **Key takeaway changed**")
                if kt["old"]:
                    lines.append(f"  - Was: _{kt['old']}_")
                lines.append(f"  - Now: _{kt['new']}_")
            
            if "content" in changes:
                c = changes["content"]
                lines.append(f"- **Content rewritten** ({c['old_words']} → {c['new_words']} words, {c['delta']})")
                if c.get("opening_changed"):
                    lines.append(f"  - Opening paragraph changed")
                if c.get("closing_changed"):
                    lines.append(f"  - Closing paragraph changed")
            
            if "bullets" in changes:
                b = changes["bullets"]
                parts = []
                if b["added"]:
                    parts.append(f"+{b['added']} added")
                if b["removed"]:
                    parts.append(f"-{b['removed']} removed")
                lines.append(f"- **Bullets**: {', '.join(parts)}")
            
            if "tables" in changes:
                t = changes["tables"]
                lines.append(f"- **Tables**: {t['old']} → {t['new']}")
            
            if "max_words" in changes:
                m = changes["max_words"]
                lines.append(f"- **Word limit**: {m['old']} → {m['new']}")
            
            lines.append("")
    
    # Unchanged count
    if changelog["unchanged_keys"]:
        lines.append(f"## ✅ Unchanged ({len(changelog['unchanged_keys'])})\n")
        lines.append(f"{', '.join(changelog['unchanged_keys'])}")
        lines.append("")
    
    return "\n".join(lines)


def embed_changelog(responses_path, changelog):
    """Embed a changelog entry into the responses JSON's _changelog array.
    
    This creates an audit trail inside the responses file itself.
    
    Usage:
        python3 diff_responses.py --old v1.json --new v2.json --embed
    """
    with open(responses_path, "r", encoding="utf-8") as f:
        responses = json.load(f)
    
    if "_changelog" not in responses:
        responses["_changelog"] = []
    
    # Compact version for embedding (skip unchanged_keys to save space)
    compact = {
        "version": len(responses["_changelog"]) + 2,  # v2, v3, ...
        "timestamp": changelog["generated_at"],
        "compared_to": Path(changelog["old_file"]).name,
        "summary": changelog["summary"],
        "meta_changes": changelog.get("meta_changes", {}),
        "added": [r["key"] for r in changelog["added_requirements"]],
        "removed": [r["key"] for r in changelog["removed_requirements"]],
        "modified": {
            k: {
                field: info["changes"][field]
                for field in info["changes"]
                if field == "content"
            }
            for k, info in changelog["modified_requirements"].items()
        },
    }
    
    responses["_changelog"].append(compact)
    
    with open(responses_path, "w", encoding="utf-8") as f:
        json.dump(responses, f, ensure_ascii=False, indent=2)
    
    print(f"✅ Changelog v{compact['version']} embedded in {responses_path}")


def main():
    parser = argparse.ArgumentParser(description="Compare two RFI response drafts and produce a changelog")
    parser.add_argument("--old", required=True, help="Path to the previous version of responses JSON")
    parser.add_argument("--new", required=True, help="Path to the current version of responses JSON")
    parser.add_argument("--output", help="Write changelog to this file (prints to stdout if not set)")
    parser.add_argument("--json", action="store_true", help="Output as JSON instead of Markdown")
    parser.add_argument("--embed", action="store_true",
                        help="Embed a compact changelog into the --new file's _changelog array")
    
    args = parser.parse_args()
    
    changelog = diff_responses(args.old, args.new)
    
    if args.embed:
        embed_changelog(args.new, changelog)
    
    if args.json:
        output_text = json.dumps(changelog, indent=2, ensure_ascii=False)
    else:
        output_text = format_changelog_md(changelog)
    
    if args.output:
        Path(args.output).parent.mkdir(parents=True, exist_ok=True)
        with open(args.output, "w", encoding="utf-8") as f:
            f.write(output_text)
        print(f"✅ Changelog saved: {args.output}")
    else:
        print(output_text)


if __name__ == "__main__":
    main()
