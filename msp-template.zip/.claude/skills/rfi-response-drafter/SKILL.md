---
name: rfi-response-drafter
description: "Draft professional RFI responses for Sopra Steria's Digital Platform Services (DPS) business line. Parses RFI documents (Word/PDF), maps requirements to Sopra Steria's managed services portfolio (Right* products), and generates branded Word documents with narrative responses in the customer's language. The skill uses an interactive workflow: parse → review → draft → refine → generate. Use this skill whenever the user mentions: \"RFI\", \"RFI response\", \"RFI draft\", \"respond to RFI\", \"answer RFI\", \"RFI besvarelse\", \"besvar RFI\", \"skriv RFI-svar\", \"draft RFI\", \"RFI document\", or uploads a document that appears to be a Request for Information. Also trigger when the user asks to \"respond to customer questions\", \"draft a managed services response\", \"answer these requirements\", or anything involving mapping customer needs to the Sopra Steria service portfolio. Even partial mentions like \"this RFI\" or \"the customer's questions\" should trigger this skill."
---

# RFI Response Drafter — Sopra Steria DPS

This skill helps draft professional RFI (Request for Information) responses for Sopra Steria's
Digital Platform Services division. It produces branded Word documents with narrative responses
that match Sopra Steria's authentic advisory voice.

## Overview of the Workflow

```
Step 1: Gather inputs     → User uploads RFI (.docx/.pdf); catalog via vault skill or upload
Step 2: Parse & index     → Extract requirements, build product index, detect format/language
Step 3: Review            → Show customer context + requirements with product suggestions
Step 4: Introduction      → Draft strategic framing: customer's goals → Sopra Steria's fit
Step 5: Draft & refine    → For each requirement, draft a response and let user refine
Step 6: Generate          → Produce final branded Word document with ToC and cover page
```

The workflow is interactive — the user reviews and refines at every stage.

### The loop

Step 5 runs as a loop: **one requirement is the iteration unit.** Draft → present → user
feedback → refine, repeating until the user approves that requirement (or that batch), then
move to the next. This inner loop runs largely on its own — the user reacts to each draft
rather than being asked before every action.

The **approval gate** sits at the outer boundary, not inside the loop: Step 6d (the QA
validator) and the Customer Value review (Step 6, before 6e) both run before generation, and
the document itself is never produced without the user's explicit sign-off. Nothing about the
inner per-requirement loop bypasses that outer gate.

If a session ends mid-loop (some requirements approved, others still drafts), record exactly
where things stand — which requirements are approved, which are open, what's pending — in the
case's `STATUS.md` before closing out, so the next session resumes the loop instead of
restarting it.

---

## Step 1: Gather Inputs

The user needs to provide:

1. **The RFI document** (.docx or .pdf) — the customer's Request for Information
2. **Product catalog information** — Sopra Steria's Right* service descriptions, via one of
   two sources (check which is available before asking the user for anything):

   - **Catalog path (preferred when available)**: if the `service-catalog` skill is
     installed and the local `service-catalog` clone's `content/dps-contract/` has content,
     use that as the source of product truth instead of asking the user to upload catalog
     files. It holds the same
     Right* portfolio content (Appendix 2 Solution Specification, product IDs, SLAs,
     delivery model, AIOps AI policy) as structured markdown, kept current independent of
     any one RFI engagement. When this path is available, skip straight to asking for the
     RFI document only — don't request Appendix 2/5/6 uploads.
   - **Uploaded-files path (fallback)**: if the catalog isn't available, fall back to asking
     the user to upload the product catalog files directly (.docx) — typically Appendix 2
     (Solution Specification), Appendix 5 (SLAs), Appendix 6 (Admin). These are parsed and
     indexed as described in Step 2b.

If the user has already uploaded files in this conversation, check `/mnt/user-data/uploads/` for them.
If files are missing, ask the user to upload them — unless the catalog path applies, in which case
only the RFI document is needed from the user.

**Bid Manager answer templates**: Sometimes the user will upload a pre-structured answer document
(prepared by the Bid Manager) that already contains the questions and desired response structure.
When this happens, use the answer template as the primary structure — it supersedes the raw RFI.
The parser detects this as `answer_template` format.

**Optional extras** the user may also provide:
- Reference case documents or presentations
- Win themes or specific differentiators to emphasise
- Customer-specific context (industry, size, current IT setup)

Start the conversation like this:

> If the vault path applies:
> "I'll help you draft an RFI response. I'll pull product details from the DPS product vault
> as I go, so I just need the RFI document (the customer's questions) — have you uploaded it,
> or do you want to drop it in now?"
>
> If falling back to uploaded files:
> "I'll help you draft an RFI response. I need two things:
> 1. The RFI document (the customer's questions)
> 2. Your product catalog files (the Right* portfolio appendices)
>
> Do you have these ready, or have you already uploaded them?"

---

## Step 2: Parse & Index

Once files are available, run the parsing scripts. Find the skill directory first:

```bash
SKILL_DIR=$(find /mnt/skills -path "*/rfi-response-drafter/SKILL.md" -exec dirname {} \; 2>/dev/null | head -1)
```

### 2a: Parse the RFI

The parser supports both .docx and .pdf files and auto-detects the RFI format:
- **heading_based**: Questions as headings (e.g. Nortura style)
- **table_based**: Questions in table cells (e.g. Vinmonopolet style)
- **scope_document**: Descriptive sections with implicit requirements (e.g. TenneT style)

```bash
python3 "$SKILL_DIR/scripts/parse_rfi.py" \
  --file "/mnt/user-data/uploads/[RFI_FILENAME].docx" \
  --output /home/claude/rfi_parsed.json \
  --summary /home/claude/rfi_summary.txt \
  --product-index /home/claude/product_index.json
```

Note: build the product index (Step 2b) first, then re-run the parser with `--product-index`
to get automatic product-to-requirement suggestions.

Read the summary to understand what was extracted. The summary includes:
- **Customer context**: company name, industry, employee count, goals/strategy
- **Detected format and language**: used to calibrate the response approach
- **Requirements with product suggestions**: each requirement shows which Right* products are relevant

### 2b: Build the product index

**This step applies to the uploaded-files path only.** If you're on the vault path (Step 1),
skip building a `product_index.json` altogether — there are no catalog .docx files to parse.
Instead, run the RFI parser (2a) without `--product-index`, and look up products directly
against the vault during Step 5 (5a/5b below) as each requirement comes up. The vault is
already organised by product, so there's no need for a pre-built keyword index to match
against it.

```bash
python3 "$SKILL_DIR/scripts/parse_catalog.py" \
  --files "/mnt/user-data/uploads/[CATALOG_FILE_1].docx" "/mnt/user-data/uploads/[CATALOG_FILE_2].docx" \
  --output /home/claude/product_index.json \
  --compact /home/claude/product_index.txt
```

Read the compact index — this is the lightweight reference you'll use to match requirements to products.

The index now extracts for each product section:
- **Keywords**: Auto-extracted distinctive terms (single words + bigrams) with frequency scores.
  Bigrams like "container orchestration" or "zero trust" are boosted 3× since they're more
  specific than single words.
- **Capability tags**: Broad categories (cloud, workplace, identity, security, network,
  monitoring, service_management, application, collaboration, finops, automation, governance,
  transition, printing, database, backup, service_desk) — used for fast category matching.
- **Sub-product mapping**: Sub-products (e.g. MS0201 Device Lifecycle) are linked to their
  parent (MS02 RightExperience) so matching works at both levels.

The index now includes a **file fingerprint** (SHA-256 hash + timestamp) for each source file.
This enables staleness detection — if catalog files are re-uploaded mid-session, you can check
whether the index needs rebuilding.

**Checking index freshness** (run before drafting if the user mentions updated files):

```bash
python3 "$SKILL_DIR/scripts/parse_catalog.py" \
  --check-freshness /home/claude/product_index.json
```

This compares stored file hashes against the current uploads directory and reports:
- ✅ Fresh — all files match, safe to proceed
- ⚠️ Changed files — specific catalog files have been re-uploaded with different content
- ⚠️ Missing files — indexed files no longer in uploads
- ℹ️ New catalog-like files — new `.docx` files in uploads that look like catalogs but aren't indexed

If the index is stale, rebuild it with `--files` before continuing to draft.

**When to check freshness:**
- If the user says "I've uploaded a new version" or "use the updated catalog"
- At the start of Step 5 if significant time has passed since Step 2
- If product matching seems off (wrong products suggested for requirements)

### 2c: Review parser output

The parser now auto-detects:
- **Language** (Norwegian or English) — all responses must match the RFI language
- **Format** — determines how requirements are extracted:
  - `heading_based`: questions as headings (e.g. Nortura)
  - `table_based`: questions in table cells (e.g. Vinmonopolet)
  - `scope_document`: descriptive sections with implicit requirements (e.g. TenneT PDF)
  - `answer_template`: questions in custom/non-heading styles (e.g. Bid Manager pre-structured templates)
  - `mixed`: combination of formats
- **Customer context** — company info, industry, employee count, goals
- **Requirement categories** — each requirement is tagged:
  - 🔧 `scope`: technical/functional requirements
  - 💰 `commercial`: pricing, costs, commercial models
  - 📋 `procedural`: tender process, evaluation criteria
  - 📎 `reference`: case studies, experience, certifications
  - ⚠️ `risk`: risks, concerns, challenges
  - 🔄 `transition`: transition approach, implementation
- **Evaluation criteria** — if the RFI contains evaluation weightings (e.g. "Quality 60%,
  Price 40%"), the parser extracts them with percentage weights and validates whether
  they sum to 100%. This helps prioritize effort on high-weight areas.
- **PDF table extraction** — for PDF files, the parser now extracts structured tables
  preserving row/column layout. This handles table-based RFIs delivered as PDF (e.g.
  requirement ID + question + response columns). The parser auto-detects question columns
  by scanning headers for keywords like "requirement", "question", "krav", "spørsmål".

Use this information to calibrate the response approach before presenting to the user.

### 2d: Lot / tower detection

The parser auto-detects lot/tower structure by scanning for patterns like "Lot 1: Cloud Platform",
"Tower A: Infrastructure", "Del 1: Plattformtjenester" etc. in headings and body text.

When lots are detected, the parser:
1. Groups requirements by lot based on document position (which lot heading they appear under)
2. Identifies "shared" requirements that appear before any lot heading
3. Outputs a `lot_structure` with `shared` requirements and per-lot `lots[]`

If the parser detects lots, present the lot structure to the user:

> "I've detected a **multi-lot structure** with [N] lots:
>
> - 📦 **Lot 1: Cloud Platform** — [X] requirements
> - 📦 **Lot 2: Digital Workplace** — [Y] requirements
> - 📦 **Lot 3: Security Operations** — [Z] requirements
> - 🔗 **Shared (cross-lot)** — [W] requirements
>
> For each lot, I'll need to know:
> 1. **Who leads delivery?** (Sopra Steria, or a consortium partner)
> 2. **Which lots are you bidding on?** (skip lots you won't respond to)
>
> Also: do you want **one combined document** or **separate documents per lot**?"

---

## Step 3: Review Extracted Requirements

Present the customer context and extracted requirements to the user. Format clearly:

> "Here's what I understand about **[Customer Name]**:
> - Industry: [industry]
> - Scale: [employee count] employees
> - Document format: [answer_template / scope_document / heading_based / table_based]
> - Language: [English / Norwegian]
> - Key goals: [summarised from parser output]
>
> I've extracted **[N] requirements** across these categories:
> - 🔧 Scope: [count] questions
> - 💰 Commercial: [count] questions
> - 📋 Procedural: [count] questions
> - 📎 References: [count] questions
> - ⚠️ Risk: [count] questions
>
> **R01** 🔧: [requirement text] → _MS02 RightExperience (score: 84), sub: MS0201 Device Lifecycle_
> **R02** 💰: [requirement text] → _No product mapping (commercial question)_
> ...
>
> Does this look complete? Should I add, remove, or reword any requirements?"

### Handling different formats

**Answer templates** (Bid Manager pre-structured documents): when the user uploads a document
that already contains the questions and desired structure, use that structure exactly. Preserve
the customer's section numbering (2.1.1, 2.1.2, etc.) in your response headings. The answer
template IS the response structure — do not reorganise it.

**Scope documents** (market consultations, tender prep documents): the parser extracts sections
as implicit requirements. These may need consolidation — e.g. multiple sub-sections about
"Workplace" should be grouped into a single requirement area. Present the grouping to the user
for confirmation.

**PDF documents**: the parser uses font size analysis to detect headings, which may produce
some noise from headers/footers (e.g. "PAGE 8 of 11" detected as a heading). Filter these
during review — they are artefacts of the PDF extraction, not real requirements.

### Category-specific handling

**🔧 Scope questions**: Draft full narrative responses grounded in the product catalog.
Use the standard writing style: Key take-away → narrative → bullet summary.

**💰 Commercial questions**: **NEVER commit to specific pricing without explicit user
instruction.** Always use language like "indicative range", "subject to detailed scoping",
"broad market reference — not a commitment". Ask the user what level of pricing detail to
include before drafting. If the user provides pricing guidance, present it with appropriate
caveats.

When answering commercial model questions (not just price numbers), read the commercial
model section in `references/style_guide.md` and use these concepts:
- The Price Cube (4 dimensions: SLA, operating model, platform, TMO/FMO) for differentiated pricing
- "All inclusive" model as a differentiator vs transactional competitors
- Pay-as-you-go with no minimum commit for flexibility positioning
- Partner-based contract mechanisms (profit sharing, RightCost) for long-term competitiveness
- Benefit realisation through CMO→TMO→FMO transformation for TCO development narrative

**NEVER share internal cost structures, margin percentages, hourly rates, or Price Workbook
details. These are strictly confidential.** Only use the conceptual commercial framework.

**📋 Procedural questions**: Use a collaborative, advisory tone — not product-focused.
These are about the tender process, not about Sopra Steria's services. Frame responses as
helpful advice from an experienced market participant.

**📎 Reference questions**: Draw from the reference cases index. Always explain relevance
to this specific customer. Offer to provide contact persons during the formal tender.

**⚠️ Risk questions**: Be transparent and structured. Identify genuine risks, propose
mitigations, and demonstrate maturity. This is where the "honest self-assessment" pattern
from the style guide applies — acknowledge challenges rather than glossing over them.

### Numbering and structure

**Always preserve the customer's numbering scheme.** If the RFI uses 2.1.1, 2.1.2, etc.,
use those same numbers in the response headings. This makes it easy for the evaluator to
cross-reference the response against the questions.

### Win themes and strategic positioning

After confirming the requirements, capture the win themes for this bid. Win themes are the
2–4 strategic messages that should run consistently through every response.

> "Before I start drafting, let's lock in the **win themes** for this bid.
> Based on the RFI and your customer context, I'd suggest:
>
> 1. **[Theme 1]** — e.g. 'Nordic delivery footprint with local presence'
> 2. **[Theme 2]** — e.g. 'Industrialised portfolio — not bespoke, not rigid'
> 3. **[Theme 3]** — e.g. 'Partnership model with shared incentives'
>
> Want to adjust these, add more, or replace any? I'll weave these into
> every response so the evaluator sees a consistent strategic narrative."

**How to infer win themes** (if the user doesn't provide them):
- What does the RFI emphasise most? (cost, quality, innovation, risk reduction, partnership)
- What are Sopra Steria's strongest differentiators for this customer's industry?
- Which reference cases are most relevant — and what do they prove?
- Is there an incumbent? If so, the win theme should address why to switch.

**Common win theme patterns:**
- Cost: "All-inclusive pricing with FinOps-driven optimisation"
- Scale: "Proven delivery to [similar-sized] organisations across Europe"
- Partnership: "Strategic advisor, not just a service provider"
- Innovation: "AI-first automation embedded in every service tower"
- Risk: "Structured transition methodology with 100+ comparable engagements"
- Sovereignty: "European data sovereignty through SovereignCloud / SolidCloud"

Store the agreed win themes — they are used in Step 4 (Introduction) and Step 5 (every response).

Also ask:
- Whether certain reference cases should be highlighted
- What register/tone to use (formal third-person vs. advisory first-person)

### Word and page limits

Many procurement teams set page or word count limits. Ask the user during Step 3:

> "Does this RFI have any **response length constraints**? For example:
> - Maximum pages per requirement (e.g. 'max 2 pages per answer')
> - Maximum total document length (e.g. '40 pages')
> - Maximum words per answer
>
> If there are limits, I'll track compliance during drafting and flag any overruns."

If the user provides limits, add a `word_limits` block to the responses JSON:

```json
{
    "word_limits": {
        "max_words_per_requirement": 300,
        "max_total_words": 10000,
        "max_pages": 40
    }
}
```

Fields (all optional — set only what's relevant):
- `max_words_per_requirement`: Global per-requirement word limit. Individual requirements
  can override this with a `max_words` field on the requirement section itself.
- `max_total_words`: Maximum total words across all requirement responses.
- `max_pages`: Maximum page count (converted to ~250 words/page for validation).

The pre-generation validator (Step 6d) checks these limits and flags overruns as warnings.
During drafting (Step 5), use these limits to calibrate response length — aim for ~80% of
the limit to leave room for formatting overhead in Word.

---

## Step 4: Draft the Introduction

**Always start the response document with an Introduction section.** This is not a generic
"about Sopra Steria" — it is a strategic framing that demonstrates understanding of the
customer's situation and maps it to Sopra Steria's fit.

The Introduction should contain three parts:

### Part 1: The customer's intent and goals (1-2 paragraphs)
Show that Sopra Steria has understood what the customer is trying to achieve. Use the customer
context extracted by the parser and any additional context from the RFI. Mention specific goals,
challenges, or strategic priorities from the document.

### Part 2: Sopra Steria's strategic fit (1-2 paragraphs)
Explain — at a high level — why Sopra Steria is well positioned to support the customer.
Reference the Right* portfolio, relevant delivery model characteristics, and any immediate
alignment with the customer's stated ambitions. Do not go into product-level detail here —
that comes in the requirement responses.

**Thread the win themes here.** The introduction is where win themes are established for
the first time. Each agreed win theme should appear at least once — either as an explicit
statement or woven into the narrative. The evaluator's first impression of Sopra Steria's
positioning is formed here.

### Part 3: Document structure (1 short paragraph)
Briefly outline how the response is structured, so the reader knows what to expect.

**Example pattern** (English, formal register):

> **Key take-away**: Sopra Steria's standardised managed services portfolio aligns directly
> with [Customer]'s ambition to [stated goal from RFI].
>
> [Customer] is seeking [summarise the core need in 1-2 sentences, drawn from the RFI].
> This is a challenge that Sopra Steria understands well — having delivered comparable services
> to [mention 1-2 reference names] in the [industry] sector.
>
> Sopra Steria's Digital Platform Services division delivers [relevant capabilities] through
> a standardised, industrialised portfolio. The delivery model is designed for [key attributes
> that match the customer's needs: scalability / multi-geography / partnership / etc.].
>
> This response addresses each area outlined in [Customer]'s document. For each area,
> Sopra Steria provides an assessment of capability and advisory input.

Present the introduction to the user for review before moving to requirement responses.

---

## Step 5: Draft & Refine Requirement Responses

This is the core of the skill. Two modes are available:

### Choosing the drafting mode

At the start of Step 5, assess the number and mix of requirements, then propose a mode:

> "I've got **[N] requirements** to draft. I can work in two modes:
>
> **Sequential mode** (best for ≤8 requirements or when you want tight control):
> I draft each requirement one at a time — you review and refine before I move on.
>
> **Batch mode** (best for 8+ requirements or when you want speed):
> I draft all [scope/commercial/etc.] questions in one pass, present the full set for
> consolidated review, and you flag which ones need rework.
>
> Which do you prefer — or shall I suggest based on the requirement mix?"

**Default recommendation:**
- ≤8 requirements total → Sequential
- 9+ requirements → Batch (grouped by category)
- Mix of simple scope + complex commercial → Batch the scope, sequential the commercial

### Batch Drafting Mode

When batch mode is selected, follow this workflow:

**5-batch-a: Group requirements by category**

Group requirements into drafting batches. Recommended groupings:
- 🔧 **Scope batch**: All technical/functional requirements (usually the largest batch)
- 💰 **Commercial batch**: Pricing and commercial model questions (draft with extra caution)
- 📎🔄 **Reference & transition batch**: Case studies, experience, transition approach
- 📋⚠️ **Procedural & risk batch**: Tender process, risk questions

Present the grouping:

> "I'll draft in these batches:
> 1. **Scope** (R01, R03, R05–R12) — 10 requirements
> 2. **Reference & transition** (R02, R04) — 2 requirements
> 3. **Commercial** (R13–R15) — 3 requirements ← I'll ask for pricing guidance before this batch
>
> Starting with the scope batch. Generating drafts now…"

**5-batch-b: Draft the batch**

For each requirement in the batch:
1. Load relevant product catalog sections (use `extract_section.py`)
2. Read the style guide
3. Draft the response following the standard writing principles

Present the full batch as a consolidated review:

> "Here are all **10 scope drafts**. For each one I show the key take-away and a
> 1-line summary — expand any you want to see in full.
>
> | # | Requirement | Key Take-away | Status |
> |---|-------------|---------------|--------|
> | R01 | End-user services | RightExperience: modern workplace with M365, Autopilot, self-service | ✏️ Draft |
> | R03 | Cloud platform | RightCloud: Azure with IaC, FinOps, multi-region | ✏️ Draft |
> | R05 | Security operations | RightSecurity: 24/7 SOC, SIEM/SOAR, zero-trust | ✏️ Draft |
> | … | … | … | … |
>
> **Review options:**
> - Say **"approve all"** to accept the full batch
> - Say **"show R05"** to expand and review a specific draft
> - Say **"rework R01, R03"** to flag specific ones for revision
> - Say **"R05: make it shorter"** for targeted feedback on specific items"

**5-batch-c: Consolidated refinement**

Process user feedback:
- **"approve all"** → Mark all as approved, move to next batch
- **"show R05"** → Display the full draft for R05 (key takeaway + narrative + bullets)
- **"rework R01, R03"** → Redraft those specific requirements, re-present for review
- **"R05: [specific feedback]"** → Apply feedback, show revised draft for confirmation
- **"approve all except R01"** → Approve the batch, keep R01 for rework

Track status per requirement: `✏️ Draft` → `✅ Approved` or `🔄 Rework`.
Continue until all requirements in the batch are approved, then move to the next batch.

**5-batch-d: Commercial batch special handling**

Before drafting the commercial batch, always pause and ask:

> "I'm about to draft the **commercial questions** (R13–R15). These cover:
> - R13: Pricing model
> - R14: Cost breakdown structure
> - R15: Contract flexibility
>
> **What level of pricing detail should I include?**
> - Conceptual only (Price Cube framework, all-inclusive model — no numbers)
> - Indicative ranges (if you give me ballpark figures)
> - Specific figures (if you provide exact numbers to include)
>
> Also: any specific commercial differentiators to emphasise?"

### Sequential Drafting Mode (default for small RFIs)

For each requirement:

### 5a: Identify relevant products

**On the catalog path**, there's no pre-scored index to read — instead, use the
`service-catalog` skill directly for each requirement. Reason about which Right*
product(s) the requirement is really asking about (e.g. device/endpoint questions →
RightExperience, security operations → RightSecurity), then query the skill for that
product's scope, product IDs, SLA detail, and delivery model. Do this per requirement as
you draft, rather than building a lookup table up front. If a requirement plausibly spans
more than one product, query each candidate and let the actual scope returned — not a
keyword score — decide which one(s) belong in the response.

> "For R01 ('[requirement summary]'), this looks like end-user/workplace scope — checking
> RightExperience (and its device lifecycle sub-product) in the DPS vault…"

**On the uploaded-files path**, the parser auto-suggests products for each requirement,
ranked by match score. Higher scores mean stronger alignment. Present the top matches to
the user:

> "For R01 ('[requirement summary]'), the parser suggests:
> - **MS02 – RightExperience** (score: 84) — end-user and workplace services
>   └ Sub-match: MS0201 Device Lifecycle Management (score: 59)
> - **MS05 – RightService** (score: 32) — ITSM / SIAM
>
> The scoring is based on keyword and capability overlap with the product catalog.
> Should I also draw on any other products?"

Products with scores above 50 are strong matches — load those catalog sections first.
Products scoring 20–50 may be relevant as secondary references. Below 20, review manually.

If the parser didn't suggest products (e.g. for manually added requirements), use the product
index keywords and capability tags to identify relevant matches.

### 5b: Load relevant catalog sections

**On the catalog path**, this is already done as part of 5a — the `service-catalog`
skill returns the grounding content directly from the catalog files, so there's no separate
extraction step. Treat that returned content the same way you'd treat an extracted catalog
section: read it fully before drafting, and cite the specific product/product ID it came
from rather than paraphrasing generically.

**On the uploaded-files path**, use the extract script to load the full product descriptions
you need:

```bash
python3 "$SKILL_DIR/scripts/extract_section.py" \
  --file "/mnt/user-data/uploads/[CATALOG_FILE].docx" \
  --heading "MS04 – RightSecurity" \
  --output /home/claude/section_ms04.txt
```

Read the extracted section to ground your response in actual product capabilities.

### 5c: Draft the response

Before writing, read the style guide:

```bash
cat "$SKILL_DIR/references/style_guide.md"
```

**Writing principles** (from the style guide — internalise these):

1. **Match the RFI language** (Norwegian or English)
2. **Lead with a Key Take-away** — a bold strategic statement summarising your answer
3. **Write flowing narrative prose** — not a table, not bullet-only. Full paragraphs that read
   like a professional consultant wrote them.
4. **Anchor in the Right* portfolio** — always name the specific products/services
5. **Reference frameworks** where relevant: Navigator, CMO→TMO→FMO, CSI, ITSM/ITIL
6. **Include relevant reference cases** if provided — with explicit relevance to this customer
7. **Be advisory** — don't just answer what's asked, recommend what the customer *should* do
8. **Use the correct register**:
   - Government/public sector: "Leverandøren" (third person, formal)
   - Private sector: "Sopra Steria" / "vi" (first person, consultative)
9. **Thread at least one win theme** — every requirement response must reinforce at least one
   of the agreed win themes from Step 3. This doesn't mean repeating the theme verbatim —
   it means connecting the specific answer to the broader strategic message. Examples:
   - Win theme "Partnership model" → "…designed for joint governance and shared accountability…"
   - Win theme "AI-first automation" → "…with NowAssist and AgenticAI embedded from day one…"
   - Win theme "Nordic delivery footprint" → "…delivered from our Nordic centres of excellence…"
   
   Not every response needs all themes — pick the one(s) that naturally fit. But across the
   full document, every win theme should appear in at least 30% of the responses.

Present the draft to the user:

> "Here's my draft for R01:
>
> **Key take-away**: [strategic summary]
>
> [Full narrative response...]
>
> How does this look? Should I adjust the tone, add more detail, or change the focus?"

### 5d: Refine

Iterate on the response based on user feedback. Common refinements:
- More/less technical detail
- Stronger/softer advisory tone
- Add/remove reference cases
- Emphasise different differentiators
- Adjust length

Once the user approves, move to the next requirement. Track all approved responses.

### Working through requirements efficiently

For long RFIs with many requirements, you can batch related ones:

> "R03, R04, and R05 all relate to security operations. Want me to draft these as
> a group, or address each one separately?"

This saves time while keeping the user in control.

### 5e: Version tracking and changelogs

When refinements are significant (rework of multiple requirements, structural changes, or
feedback from a bid review meeting), save a versioned snapshot of the responses JSON before
applying changes:

```bash
# Save the current state as a versioned snapshot
cp /home/claude/responses.json /home/claude/responses_v1.json
```

After applying changes to `responses.json`, generate a changelog:

```bash
python3 "$SKILL_DIR/scripts/diff_responses.py" \
  --old /home/claude/responses_v1.json \
  --new /home/claude/responses.json
```

This produces a Markdown changelog showing:
- **Added/removed requirements** — requirements present in one version but not the other
- **Modified requirements** — per-requirement detail: key takeaway changes, word count deltas,
  opening/closing paragraph changes, bullet and table changes
- **Metadata changes** — customer name, RFI title, language
- **Word limit changes** — if limits were added or adjusted between versions
- **Summary table** — total words old vs new, requirements modified vs unchanged

**Embedding the changelog** in the responses JSON (creates an audit trail):

```bash
python3 "$SKILL_DIR/scripts/diff_responses.py" \
  --old /home/claude/responses_v1.json \
  --new /home/claude/responses.json \
  --embed
```

This adds a `_changelog` array inside the responses JSON. Each entry records the version
number, timestamp, what was compared, and a compact summary of changes. The generator
script ignores this field — it's purely for audit and review.

**When to create snapshots:**
- Before applying batch rework from user feedback
- Before and after a bid review meeting round of changes
- When switching from sequential to batch mode mid-session
- Any time the user says "let's save this version before we change things"

**Presenting changelogs** to the user:

> "I've applied your feedback to 4 requirements. Here's what changed since v1:
>
> | Metric | v1 | v2 | Delta |
> |--------|----|----|-------|
> | Total words | 2,450 | 3,120 | +670 |
> | Modified | — | — | 4 |
> | Unchanged | — | — | 8 |
>
> Key changes:
> - **R01 Cloud Platform**: Key takeaway revised, +120 words (added FinOps detail)
> - **R05 Security**: Content rewritten, -40 words (tightened per your feedback)
> - **R08 Transition**: New bullets added (3), table added
> - **R12 Pricing**: Pricing caveats added per commercial review
>
> Ready to proceed to document generation, or further edits?"

---

## Step 6: Generate Final Document

Once all responses are approved, build the responses JSON and generate the branded document.

### 6a: Build the responses JSON

Create a file at `/home/claude/responses.json` with this structure.

**Recommended document section order:**
1. Executive Summary (for 8+ requirements or large tenders)
2. Introduction (H1) + strategic framing text
3. Compliance Matrix (for 5+ requirements)
4. Detailed Responses (H1) + requirement sections with inline tables
5. Appendices (reference details, certifications, key personnel, etc.)

```json
{
    "customer": "Customer Name",
    "rfi_title": "RFI Title",
    "language": "en",
    "word_limits": {
        "max_words_per_requirement": 300,
        "max_total_words": 10000
    },
    "sections": [
        {
            "heading": "Introduction",
            "type": "h1"
        },
        {
            "type": "text",
            "content": "Strategic framing paragraph(s) from Step 4..."
        },
        {
            "heading": "Compliance Overview",
            "type": "compliance_matrix",
            "content": "The table below summarises Sopra Steria's compliance status for each requirement area. Detailed responses follow in subsequent sections.",
            "rows": [
                {
                    "req_id": "R01",
                    "requirement": "End-user and workplace services",
                    "status": "Fully Compliant",
                    "section_ref": "2.1"
                },
                {
                    "req_id": "R02",
                    "requirement": "Cloud platform management",
                    "status": "Fully Compliant",
                    "section_ref": "2.2"
                },
                {
                    "req_id": "R03",
                    "requirement": "Legacy mainframe operations",
                    "status": "Alternative Proposed",
                    "section_ref": "2.3"
                }
            ]
        },
        {
            "heading": "Section Title",
            "type": "h1"
        },
        {
            "heading": "Requirement question text",
            "type": "requirement",
            "heading_style": "Heading 2",
            "key_takeaway": "Strategic summary statement",
            "content": "Full narrative response paragraph(s)...",
            "max_words": 200,
            "tables": [
                {
                    "headers": ["Tier", "Availability", "Response Time"],
                    "rows": [["Gold", "99.95%", "15 min"], ["Silver", "99.9%", "30 min"]],
                    "caption": "Table 1: SLA tiers",
                    "style": "branded"
                }
            ],
            "bullets": ["Optional bullet 1", "Optional bullet 2"]
        }
    ]
}
```

Section types:
- `"h1"` — Major section heading (Heading 1)
- `"h2"` — Sub-section heading (Heading 2)
- `"requirement"` — A requirement with key takeaway + narrative + optional tables + bullets
- `"text"` — Plain narrative text (no heading)
- `"table"` — Standalone table with optional heading and intro text
- `"compliance_matrix"` — Compliance summary table with colored status indicators
- `"figure_placeholder"` — Numbered figure placeholder with description and caption
- `"executive_summary"` — Structured executive summary with highlights table and references
- `"appendix"` — Appendix section with letter-based numbering (A, B, C…)

Optional top-level fields:
- `"word_limits"` — Global word/page limits (see Step 3: Word and page limits)
- `"_changelog"` — Audit trail of version changes (populated by `diff_responses.py --embed`)

Optional per-requirement field:
- `"max_words"` — Overrides the global `max_words_per_requirement` for this specific requirement

#### Lot-based JSON format (for multi-lot tenders)

When the RFI has a lot/tower structure, use this format instead of the flat `"sections"` array.
The generator auto-detects which format is used.

```json
{
    "customer": "Customer Name",
    "rfi_title": "RFI Title",
    "language": "en",
    "shared_sections": [
        {"type": "executive_summary", "...": "..."},
        {"heading": "Introduction", "type": "h1"},
        {"type": "text", "content": "Shared intro text..."}
    ],
    "lots": [
        {
            "lot_id": "Lot 1",
            "lot_name": "Cloud Platform",
            "consortium_lead": "Sopra Steria",
            "intro": "Optional lot intro paragraph...",
            "compliance_matrix": {
                "type": "compliance_matrix",
                "heading": "Lot 1 Compliance Overview",
                "heading_style": "Heading 2",
                "rows": [{"req_id": "L1-R01", "requirement": "...", "status": "Fully Compliant", "section_ref": "L1.1"}]
            },
            "sections": [
                {"type": "requirement", "heading": "L1.1 ...", "...": "..."}
            ]
        },
        {
            "lot_id": "Lot 3",
            "lot_name": "Security Operations",
            "consortium_lead": "SecureOps GmbH",
            "intro": "Delivered by consortium partner...",
            "sections": [{"type": "requirement", "...": "..."}]
        }
    ],
    "shared_appendices": [
        {"type": "appendix", "heading": "Certifications", "...": "..."}
    ]
}
```

**Structure:**
- `shared_sections`: Rendered first — executive summary, introduction, shared content
- `lots[]`: Each lot becomes a Heading 1 chapter. Contains `intro`, optional `compliance_matrix`,
  and `sections[]` with the lot-specific requirements
- `shared_appendices`: Rendered last — appendices shared across all lots

**Per-lot fields:**
- `lot_id`: Display ID (e.g. "Lot 1", "Lot A")
- `lot_name`: Descriptive name (e.g. "Cloud Platform")
- `consortium_lead`: Who delivers this lot. If not "Sopra Steria", the generator adds a note
- `intro`: Optional paragraph introducing the lot response
- `compliance_matrix`: Optional per-lot compliance matrix (rendered as Heading 2 under the lot)
- `sections[]`: Requirement responses, tables, figures, etc. for this lot

**Output modes** (pass `--mode` to the generator):
- `combined` — One document: shared sections → Lot 1 chapter → Lot 2 chapter → … → shared appendices
- `per_lot` — Separate document per lot. Each includes shared sections + one lot + shared appendices.
  Files are named `[output]_Lot_1.docx`, `[output]_Lot_2.docx`, etc.
- `auto` (default) — Uses `combined` if lots are detected, `flat` otherwise

```bash
# Combined (single document with lot chapters)
python3 "$SKILL_DIR/scripts/generate_response.py" \
  --template "$SKILL_DIR/assets/EN_Sopra_Steria_offer_or_document_template_with_cover_page.dotx" \
  --responses /home/claude/responses.json \
  --output "/mnt/user-data/outputs/[Customer]_RFI_Response.docx" \
  --title "RFI Response — [Customer]" \
  --subtitle "Sopra Steria — Digital Platform Services" \
  --mode combined

# Per-lot (separate documents)
python3 "$SKILL_DIR/scripts/generate_response.py" \
  --template "$SKILL_DIR/assets/EN_Sopra_Steria_offer_or_document_template_with_cover_page.dotx" \
  --responses /home/claude/responses.json \
  --output "/mnt/user-data/outputs/[Customer]_RFI_Response.docx" \
  --title "RFI Response — [Customer]" \
  --subtitle "Sopra Steria — Digital Platform Services" \
  --mode per_lot
```

**Workflow for multi-lot RFIs:**

At Step 3 (review), present the lot structure and ask:
1. Which lots is Sopra Steria bidding on?
2. Any consortium partners for specific lots?
3. Combined document or separate per-lot?

At Step 5 (draft), work lot by lot — batch mode within each lot is recommended.
Draft shared sections (introduction, company overview) once, then per-lot requirements.

At Step 6 (generate), build the lot-based JSON. Ask the user about output mode before generating.

#### Compliance Matrix guidance

The compliance matrix is a procurement-friendly summary table placed early in the document.
It renders as a styled Word table with Sopra Steria purple headers and color-coded status cells.

**Status values** (use exactly these strings):
- English: `"Fully Compliant"`, `"Partially Compliant"`, `"Alternative Proposed"`, `"Not Applicable"`
- Norwegian: `"Fullt samsvar"`, `"Delvis samsvar"`, `"Alternativ foreslått"`, `"Ikke aktuelt"`

**When to include:**
- Always for RFIs with 5+ requirements
- Always for EU/lot-based tenders (procurement teams expect this format)
- Optional for small RFIs (≤4 requirements) — ask the user

**Populating the matrix:**
Build the matrix from the approved responses. For each requirement:
1. `req_id`: Use the requirement ID (R01, R02, etc.) or the customer's numbering (2.1.1, etc.)
2. `requirement`: A short summary (max ~10 words) — not the full question text
3. `status`: Assess based on the drafted response:
   - **Fully Compliant**: Sopra Steria's portfolio directly addresses the requirement
   - **Partially Compliant**: Addressed with caveats or not all sub-requirements covered
   - **Alternative Proposed**: Sopra Steria recommends a different approach than requested
   - **Not Applicable**: Requirement doesn't apply to Sopra Steria's scope
4. `section_ref`: The heading number where the detailed response appears

#### Figure Placeholders

Use figure placeholders when a response references a diagram, process flow, or architecture
illustration that should be added by the user after generation. This is much better than
just writing "see figure below" with nothing there.

**JSON format:**
```json
{
    "type": "figure_placeholder",
    "figure_number": 1,
    "caption": "Overview of the SIAM operating model",
    "description": "Diagram showing the layered governance model with strategic, tactical, and operational levels. Customer, service integrator, and vendor boxes with RACI arrows.",
    "size": "half"
}
```

Fields:
- `figure_number`: Sequential number (1, 2, 3…) — used in "Figure N:" caption and "[Insert Figure N here]" label
- `caption`: The figure caption shown below the placeholder (language-aware: "Figure N" / "Figur N")
- `description`: Instructions describing what should be illustrated — helps the user (or a designer) create the right visual
- `size`: `"half"` (default, ~5cm tall) or `"full"` (~8cm tall)

**Rendered output:** A dashed-border grey box with the insert instruction and description, followed by a purple italic caption. This gives the document a professional look even before the actual figures are added.

**When to include figure placeholders:**
- Transition/establishment methodology → process flow diagram
- SIAM operating model → governance layers diagram
- Service architecture → topology or component diagram
- CMO→TMO→FMO transformation → timeline/phase diagram
- Any response where you write "as illustrated in Figure X" or similar

**Figure numbering:** Track figure numbers sequentially across the entire document.
When writing the narrative, reference figures naturally: "Figure 2 illustrates the
proposed transition timeline" / "Figur 3 viser den foreslåtte styringsmodellen".

#### Inline Tables

Tables can appear inside `requirement` sections (via the `tables` field) or as standalone
`table` sections. Both use the same format.

**JSON format (inside a requirement):**
```json
{
    "type": "requirement",
    "heading": "2.1 Cloud Platform Services",
    "key_takeaway": "...",
    "content": "Narrative text referencing the table below...",
    "tables": [
        {
            "headers": ["Tier", "Availability", "Response Time", "Support Hours"],
            "rows": [
                ["Gold", "99.95%", "15 min (P1)", "24/7/365"],
                ["Silver", "99.9%", "30 min (P1)", "24/7/365"],
                ["Bronze", "99.5%", "2 hours (P1)", "8x5"]
            ],
            "caption": "Table 1: RightCloud SLA tiers",
            "style": "branded"
        }
    ],
    "bullets": ["..."]
}
```

**Standalone table (outside a requirement):**
```json
{
    "type": "table",
    "heading": "Lot-to-Product Mapping",
    "content": "Optional intro text...",
    "headers": ["Lot", "Lot Name", "Sopra Steria Service"],
    "rows": [["Lot 1", "Cloud Platform", "RightCloud"]],
    "caption": "Table 4: Lot mapping",
    "style": "branded"
}
```

Fields:
- `headers`: Array of column header strings (required)
- `rows`: Array of arrays — each inner array is one row of cell values (required)
- `caption`: Optional caption shown below the table in purple italic
- `style`: `"branded"` (purple header, default) or `"plain"` (grey header)

**Rendering:** Purple or grey header row with white/dark text, alternating zebra stripes on
data rows, first column bold. Tables render inline — they appear between narrative text and
bullet points within the same section.

**When to include tables in requirement responses:**
- SLA tiers → show availability, response times, support hours
- SIAM levels → show integration levels with descriptions
- Lot/tower mapping → map customer lots to Right* products
- RACI matrices → show responsibility allocation
- Feature comparison → show capabilities across tiers or options
- Transition timeline summary → show phases, durations, key milestones

**Table numbering:** Number tables sequentially across the document ("Table 1", "Table 2"…).
Reference them naturally in the narrative: "The table below shows…" or "as detailed in Table 3."

#### Executive Summary

The executive summary is a structured 1-page section placed at the start of the document
(before the Introduction). It gives decision-makers the key messages without reading the
full response.

**JSON format:**
```json
{
    "type": "executive_summary",
    "heading": "Executive Summary",
    "overview": "1-2 sentence strategic positioning statement...",
    "win_themes": ["Theme 1 description", "Theme 2 description"],
    "highlights": [
        {"area": "Cloud Platform", "summary": "Short capability summary"},
        {"area": "Security", "summary": "Short capability summary"}
    ],
    "references": [
        {"name": "Bane NOR", "relevance": "Why this reference matters for the customer"}
    ],
    "next_steps": "Optional closing paragraph..."
}
```

Fields:
- `overview`: Strategic positioning paragraph — connects customer need to Sopra Steria's fit
- `win_themes`: The agreed win themes from Step 3, rendered as a Key Take-away block with bullets
- `highlights`: One row per major response area, rendered as a branded 2-column table (Area | Response)
- `references`: Key reference cases with relevance, rendered as bold-name bullet list
- `next_steps`: Optional closing paragraph (call to action, offer of reference visits, etc.)

**When to include:**
- Always for RFIs with 8+ requirements
- Always for market consultations and large-scope tenders
- Optional for smaller RFIs — ask the user

**Building the executive summary:**
Generate this **after** all requirement responses are approved. Pull content from:
1. `overview` — from the Introduction (Step 4)
2. `win_themes` — from Step 3 win theme capture
3. `highlights` — the key takeaway from each requirement, condensed to ~15 words
4. `references` — the 2–3 most relevant reference cases cited in the responses
5. `next_steps` — standard closing or customer-specific call to action

#### Appendices

Appendices appear at the end of the document with letter-based numbering (Appendix A, B, C…).
Each appendix gets a page break and a Heading 1 entry in the Table of Contents.

**JSON format:**
```json
{
    "type": "appendix",
    "heading": "Reference Case Details",
    "content": "Optional intro paragraph...",
    "tables": [
        {
            "headers": ["Customer", "Industry", "Contract Value"],
            "rows": [["Bane NOR", "Railway", "~300 MNOK/yr"]],
            "caption": "Table A.1: Reference overview",
            "style": "plain"
        }
    ],
    "bullets": ["Optional bullet list items"]
}
```

The letter is assigned automatically based on order — the first `appendix` section becomes
"Appendix A", the second "Appendix B", etc. No need to specify the letter in the JSON.

**Common appendix types:**
- **Reference case details** — expanded descriptions of reference customers with tables
- **Certifications and standards** — ISO, ISAE, NIS2, GDPR compliance details
- **Proposed key personnel** — role, responsibility, allocation table
- **SLA catalogue** — full SLA definitions beyond the summary in the main response
- **Glossary** — terms, abbreviations, product code explanations
- **Team CVs** — brief profiles of proposed key staff (can be tables or narrative)

**Appendix table style:** Use `"plain"` (grey headers) for appendix tables by default —
this visually distinguishes supporting material from the main response body which uses
`"branded"` (purple headers).

### 6b: Build the executive summary (for large RFIs)

After all responses are approved, propose an executive summary:

> "All [N] responses are approved. Before generating, I'll build an executive summary.
> Here's what I'll include:
>
> **Overview:** [1-2 sentence strategic positioning]
> **Win themes:** [the 3 themes from Step 3]
> **Highlights:** [key takeaway from each major response area, condensed]
> **References:** [top 2-3 references cited in the responses]
> **Next steps:** [standard call to action]
>
> Should I adjust anything before I compile the document?"

### 6c: Propose appendices

Based on the RFI content and responses, suggest relevant appendices:

> "I'd recommend including these appendices:
> - **Appendix A: Reference Case Details** — expanded table with all cited references
> - **Appendix B: Certifications and Standards** — ISO 27001, ISAE 3402, NIS2, etc.
> - **Appendix C: Proposed Key Personnel** — roles and allocations for the engagement
>
> Want me to add any of these, or others?"

Build the appendix sections based on user confirmation. Use `"plain"` table style for
appendix tables to visually distinguish them from the main response body.

### 6d: Pre-generation QA check

Before generating, run the validation script to catch common issues:

```bash
python3 "$SKILL_DIR/scripts/validate_responses.py" \
  --responses /home/claude/responses.json \
  --rfi-parsed /home/claude/rfi_parsed.json
```

The validator checks for:
- **Errors** (blocking): missing customer name, empty requirement content, empty compliance statuses
- **Warnings** (quality): missing key takeaways, short responses (<30 words), commercial questions
  without pricing caveats, section ordering issues, win theme coverage gaps, numbering problems,
  **word count limit violations** (per-requirement and total)
- **Info** (advisory): suggestions to add executive summary or compliance matrix

When `word_limits` are set in the responses JSON, the QA report includes a word limit status line
showing the configured limits, how many requirements exceed them, and estimated page counts.

Present the QA report to the user. If there are errors, fix them before generating.
If only warnings, let the user decide whether to fix or proceed.

### Before generating: Customer Value review

Before asking the user to approve final generation, invoke the `customer-value-reviewer`
sub-agent on the drafted response (all approved requirement sections, the introduction, and
the executive summary if present). This is a distinct check from the QA validator above —
6d checks completeness and compliance mechanics; this checks whether the response actually
creates value for the customer rather than reading as generic or self-referential.

Surface the reviewer's findings to the user before asking for sign-off to generate:

> "Before generating, here's the Customer Value review:
>
> [reviewer's verdict + findings]
>
> Want me to address any of these first, or generate as-is?"

If the user wants changes, apply them and move on — don't re-run the reviewer automatically
unless the user asks for another pass. Only proceed to Step 6e once the user has responded to
the review (fix first, or explicitly proceed as-is).

### 6e: Generate the document

```bash
python3 "$SKILL_DIR/scripts/generate_response.py" \
  --template "$SKILL_DIR/assets/EN_Sopra_Steria_offer_or_document_template_with_cover_page.dotx" \
  --responses /home/claude/responses.json \
  --output "/mnt/user-data/outputs/[Customer]_RFI_Response.docx" \
  --title "RFI Response — [Customer Name]" \
  --subtitle "Sopra Steria — Digital Platform Services"
```

The generator now handles:
- Cover page title and subtitle (populates the template's structured document tags)
- Table of Contents (auto-generated from Heading 1/2 structure, includes appendices)
- Sopra Steria branding (logo, headers, purple headings preserved from template)
- Inline tables within requirement responses (branded or plain style, zebra stripes)
- Executive summary with highlights table, win themes, and key references
- Appendices with automatic letter-based numbering (A, B, C…)
- Compliance matrix with color-coded status cells
- Figure placeholders with numbered captions

### 6f: Present to user

Present the file and give a concise summary:

> "Here's the final RFI response document. It covers [N] requirements across [topics].
> You may want to review [specific areas] and add any figures or diagrams where noted."

**Remind the user** that they should:
- Review the cover page title and subtitle
- Add any figures/diagrams referenced in the text
- Have the response reviewed by relevant subject matter experts
- Check any commercial or legal commitments before submission

---

## Important Notes

### Product Catalog Updates

**Catalog path**: product content lives in `content/dps-contract/` inside your local
`service-catalog` git clone, maintained independently of any one RFI session — there's
nothing to re-upload or re-parse, just a `git pull` in that clone. Freshness is the
`service-catalog` skill's responsibility — it runs the check in
`.claude/rules/dps-contract-access.md` (which pulls automatically when the clone is behind)
before answering any lookup, so under normal use this drafter doesn't need to check it
separately. If the clone's `content/dps-contract/` is ever read without going through that
skill and answers seem stale, run the same freshness check directly rather than assuming it's
covered.

**Uploaded-files path**: the catalog files are uploaded per session. The user can upload
new versions at any time — the skill parses them fresh each time. No pre-processing or
codification is needed between versions.

**Staleness detection** (uploaded-files path only): The product index now includes file
fingerprints. If the user re-uploads catalog files, run `parse_catalog.py --check-freshness`
to verify whether the index needs rebuilding (see Step 2b). This avoids drafting responses
against an outdated index.

### Handling Large Catalogs
The product catalog (Appendix 2) is typically ~56,000 words. Never try to load the whole thing.
Always use the index + targeted section extraction approach:
1. Build the lightweight index (~2-3k tokens)
2. For each requirement, load only the relevant product sections (~2-12k words each)

### Multiple Output Languages
The output language always matches the RFI language. If the user wants both Norwegian and English
versions, generate them separately with appropriate language flags.

### When the Parser Fails
The RFI parser handles common formats but may miss requirements in unusual structures.
If the user reports missing requirements, fall back to reading the document directly:

```python
from docx import Document
doc = Document("/mnt/user-data/uploads/[FILE].docx")
for i, p in enumerate(doc.paragraphs):
    if p.text.strip():
        print(f"P{i} [{p.style.name}]: {p.text[:150]}")
```

### Reference Cases Available
The user has provided reference cases for these customers (use when relevant):

**Nordic:**
- Kongsberg Gruppen (defence/aerospace, ~120 MNOK, Azure platform)
- Bane NOR (railway infrastructure, ~300 MNOK/yr, hybrid cloud, SIAM)
- Oslo kommune (municipal services, ~1200 MNOK, end-to-end IT)
- Trondheim kommune (municipal services, cloud transformation)
- SINTEF (research institute, standardised platform, DevOps)
- Vår Energi (oil & gas, infrastructure operations)
- Lyse (energy/telecom, end-user services)
- SpareBank 1 Utvikling (banking alliance, Azure platform, M365)
- DOF (maritime, 70+ vessels, via Marin IT acquisition)
- Archer (oil services, first-time outsourcing)

**International:**
- European Commission COSMOS (EU institutions, large consortium with NTT/Proximus/Arhs/Atos)

Match reference cases to the customer's industry and needs. Always explain *why* a reference
is relevant to this specific customer. For international tenders, prefer the European Commission
reference to demonstrate multi-country delivery and consortium capability.