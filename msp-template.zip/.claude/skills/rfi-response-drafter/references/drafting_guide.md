# RFI Response Drafting Guide

Read this file when entering Step 3 (review) or Step 5 (drafting). It covers win themes,
category-specific handling, batch vs sequential workflows, and word limit management.

---

## Win Themes

Win themes are 2–4 strategic messages that run consistently through every response.
Capture them after confirming requirements, before drafting.

**Prompt pattern:**

> "Before I start drafting, let's lock in the **win themes** for this bid.
> Based on the RFI and your customer context, I'd suggest:
>
> 1. **[Theme 1]** — e.g. 'Nordic delivery footprint with local presence'
> 2. **[Theme 2]** — e.g. 'Industrialised portfolio — not bespoke, not rigid'
> 3. **[Theme 3]** — e.g. 'Partnership model with shared incentives'
>
> Want to adjust these? I'll weave them into every response."

**How to infer win themes** (if user doesn't provide):
- What does the RFI emphasise most? (cost, quality, innovation, risk reduction, partnership)
- What are Sopra Steria's strongest differentiators for this customer's industry?
- Which reference cases are most relevant — and what do they prove?
- Is there an incumbent? If so, address why to switch.

**Common win theme patterns:**
- Cost: "All-inclusive pricing with FinOps-driven optimisation"
- Scale: "Proven delivery to [similar-sized] organisations across Europe"
- Partnership: "Strategic advisor, not just a service provider"
- Innovation: "AI-first automation embedded in every service tower"
- Risk: "Structured transition methodology with 100+ comparable engagements"
- Sovereignty: "European data sovereignty through SovereignCloud / SolidCloud"

**Coverage rule:** Every win theme should appear in at least 30% of responses. Not every
response needs all themes — pick the ones that naturally fit. Thread them as natural
connections, not verbatim repetitions.

---

## Word and Page Limits

Ask during Step 3:

> "Does this RFI have **response length constraints**? (e.g., max 2 pages per answer,
> max 40 pages total, max words per answer)"

If yes, add a `word_limits` block to the responses JSON (see `references/json_formats.md`).
During drafting, aim for ~80% of the limit to leave room for Word formatting overhead.
Individual requirements can override with `max_words` field.

---

## Category-Specific Handling

### 🔧 Scope Questions
Draft full narrative responses grounded in the product catalog.
Pattern: Key take-away → narrative → bullet summary.

### 💰 Commercial Questions
**NEVER commit to specific pricing without explicit user instruction.**
Always use: "indicative range", "subject to detailed scoping", "not a commitment".
Ask what level of pricing detail to include before drafting.

For commercial model questions (not just price numbers), read the commercial model
section in `references/style_guide.md` and use:
- The Price Cube (4 dimensions: SLA, operating model, platform, TMO/FMO)
- "All inclusive" model as differentiator
- Pay-as-you-go with no minimum commit
- Partner-based contract mechanisms (profit sharing, RightCost)
- Benefit realisation through CMO→TMO→FMO

**NEVER share internal cost structures, margin percentages, hourly rates, or Price Workbook details.**

### 📋 Procedural Questions
Collaborative, advisory tone — not product-focused. Frame responses as helpful advice
from an experienced market participant about the tender process.

### 📎 Reference Questions
Draw from `references/reference_cases.md`. Always explain relevance to this specific customer.
Offer to provide contact persons during formal tender.

### ⚠️ Risk Questions
Transparent and structured. Identify genuine risks, propose mitigations, demonstrate maturity.
Use the "honest self-assessment" pattern from the style guide.

---

## Choosing the Drafting Mode

At the start of Step 5, propose a mode:

> "I've got **[N] requirements** to draft:
>
> **Sequential mode** (best for ≤8 or when you want tight control):
> I draft each one, you review before I move on.
>
> **Batch mode** (best for 8+ or when you want speed):
> I draft all [scope/commercial/etc.] in one pass, you flag which need rework.
>
> Which do you prefer?"

**Defaults:**
- ≤8 requirements → Sequential
- 9+ requirements → Batch (grouped by category)
- Mix of simple scope + complex commercial → Batch the scope, sequential the commercial

---

## Batch Drafting Workflow

### Group requirements into batches
Recommended groupings:
- 🔧 **Scope batch**: All technical/functional (usually largest)
- 💰 **Commercial batch**: Pricing and commercial model (draft with extra caution)
- 📎🔄 **Reference & transition batch**: Case studies, experience, transition
- 📋⚠️ **Procedural & risk batch**: Tender process, risk questions

### Draft and present batch
For each requirement: load relevant catalog sections, read style guide, draft.
Present as consolidated review:

> "Here are all **10 scope drafts**:
>
> | # | Requirement | Key Take-away | Status |
> |---|-------------|---------------|--------|
> | R01 | End-user services | RightExperience: modern workplace | ✏️ Draft |
> | R03 | Cloud platform | RightCloud: Azure with IaC, FinOps | ✏️ Draft |
>
> **Review options:**
> - **"approve all"** — accept the full batch
> - **"show R05"** — expand a specific draft
> - **"rework R01, R03"** — flag for revision
> - **"R05: make it shorter"** — targeted feedback"

### Consolidated refinement
- **"approve all"** → Mark all ✅, move to next batch
- **"show R05"** → Display full draft for R05
- **"rework R01, R03"** → Redraft those, re-present
- **"approve all except R01"** → Approve batch, keep R01 for rework

Track status: `✏️ Draft` → `✅ Approved` or `🔄 Rework`

### Commercial batch special handling
Before drafting commercial batch, always pause:

> "I'm about to draft **commercial questions** (R13–R15).
> **What level of pricing detail should I include?**
> - Conceptual only (framework, no numbers)
> - Indicative ranges (if you give me ballpark figures)
> - Specific figures (if you provide exact numbers)"

---

## Sequential Drafting Workflow

For each requirement:

### 1. Identify relevant products
Parser auto-suggests products ranked by score. Scores above 50 = strong match.
20–50 = secondary. Below 20 = review manually.

### 2. Load catalog sections
```bash
python3 "$SKILL_DIR/scripts/extract_section.py" \
  --file "/mnt/user-data/uploads/[CATALOG].docx" \
  --heading "MS04 – RightSecurity" \
  --output /home/claude/section_ms04.txt
```

### 3. Draft the response
Read the style guide: `cat "$SKILL_DIR/references/style_guide.md"`

**Writing principles** (core — style guide has full detail):
1. Match the RFI language
2. Lead with a Key Take-away
3. Write flowing narrative prose, not bullet-only
4. Anchor in the Right* portfolio — name specific products
5. Reference frameworks: Navigator, CMO→TMO→FMO, CSI, ITSM/ITIL
6. Include relevant reference cases with explicit relevance
7. Be advisory — recommend what the customer *should* do
8. Use correct register (government: "Leverandøren", private: "vi"/"Sopra Steria")
9. Thread at least one win theme per response

### 4. Refine
Common refinements: more/less detail, stronger/softer tone, add/remove references,
emphasise different differentiators, adjust length.

### 5. Tag confidence
After drafting each response, assign a confidence level:
- **high** — Strong product match (parser score 50+), relevant references available
- **medium** — Partial match, some interpretation needed, niche area
- **low** — Outside core portfolio, speculative, needs SME review

Add `"confidence": "high|medium|low"` to each requirement in the responses JSON.
The validator will summarise the distribution and flag low-confidence items.

---

## Version Tracking

When applying significant changes, save a snapshot before editing:

```bash
cp /home/claude/responses.json /home/claude/responses_v1.json
```

After changes, generate a changelog:

```bash
python3 "$SKILL_DIR/scripts/diff_responses.py" \
  --old /home/claude/responses_v1.json \
  --new /home/claude/responses.json
```

Embed audit trail in the responses JSON:

```bash
python3 "$SKILL_DIR/scripts/diff_responses.py" \
  --old /home/claude/responses_v1.json \
  --new /home/claude/responses.json \
  --embed
```

**When to snapshot:** Before batch rework, before/after bid review meetings,
when switching drafting modes, or when user asks to save current state.
