# RFI Response JSON Formats Reference

Read this file when building the responses JSON in Step 6. It documents all section types,
the flat and lot-based formats, and the `word_limits` / `_changelog` metadata.

---

## Flat Format (standard)

```json
{
    "customer": "Customer Name",
    "rfi_title": "RFI Title",
    "language": "en",
    "word_limits": {
        "max_words_per_requirement": 300,
        "max_total_words": 10000,
        "max_pages": 40
    },
    "sections": [
        {
            "type": "executive_summary",
            "heading": "Executive Summary",
            "overview": "1-2 sentence strategic positioning...",
            "win_themes": ["Theme 1", "Theme 2"],
            "highlights": [
                {"area": "Cloud Platform", "summary": "Short capability summary"}
            ],
            "references": [
                {"name": "Bane NOR", "relevance": "Why this matters for this customer"}
            ],
            "next_steps": "Optional closing paragraph..."
        },
        {"heading": "Introduction", "type": "h1"},
        {"type": "text", "content": "Strategic framing paragraphs..."},
        {"type": "company_overview"},
        {
            "type": "compliance_matrix",
            "heading": "Compliance Overview",
            "content": "Summary intro text...",
            "rows": [
                {"req_id": "R01", "requirement": "End-user services", "status": "Fully Compliant", "section_ref": "2.1"},
                {"req_id": "R02", "requirement": "Cloud platform", "status": "Fully Compliant", "section_ref": "2.2"},
                {"req_id": "R03", "requirement": "Legacy mainframe", "status": "Alternative Proposed", "section_ref": "2.3"}
            ]
        },
        {"heading": "Detailed Responses", "type": "h1"},
        {
            "heading": "Requirement question text",
            "type": "requirement",
            "heading_style": "Heading 2",
            "key_takeaway": "Strategic summary statement",
            "content": "Full narrative response paragraph(s)...",
            "max_words": 200,
            "confidence": "high",
            "tables": [
                {
                    "headers": ["Tier", "Availability", "Response Time"],
                    "rows": [["Gold", "99.95%", "15 min"], ["Silver", "99.9%", "30 min"]],
                    "caption": "Table 1: SLA tiers",
                    "style": "branded"
                }
            ],
            "bullets": ["Optional bullet 1", "Optional bullet 2"]
        },
        {
            "type": "figure_placeholder",
            "figure_number": 1,
            "caption": "Overview of the SIAM operating model",
            "description": "Diagram showing layered governance...",
            "size": "half"
        },
        {
            "type": "appendix",
            "heading": "Reference Case Details",
            "content": "Optional intro...",
            "tables": [{"headers": ["Customer", "Industry"], "rows": [["Bane NOR", "Railway"]], "style": "plain"}]
        }
    ]
}
```

---

## Section Types

| Type | Purpose |
|------|---------|
| `h1` | Major section heading (Heading 1) |
| `h2` | Sub-section heading (Heading 2) |
| `text` | Plain narrative text (no heading) |
| `requirement` | Requirement with key takeaway + narrative + optional tables + bullets |
| `table` | Standalone table with optional heading and intro text |
| `compliance_matrix` | Compliance summary table with colored status indicators |
| `company_overview` | Standard "About Sopra Steria" + "About DPS" pages (auto-generated) |
| `figure_placeholder` | Numbered figure placeholder with description and caption |
| `executive_summary` | Structured exec summary with highlights table and references |
| `appendix` | Appendix section with auto-numbered letters (A, B, C…) |

### Requirement Fields
- `heading`: The requirement question or section number (required)
- `heading_style`: Override heading level, default "Heading 2"
- `key_takeaway`: Bold strategic summary displayed before the narrative
- `content`: Full narrative prose (required)
- `max_words`: Per-requirement word limit override (optional)
- `confidence`: Self-assessed confidence — `"high"`, `"medium"`, or `"low"` (optional, see below)
- `tables`: Array of inline tables (optional)
- `bullets`: Array of bullet point strings (optional)

### Compliance Matrix
- Status values EN: `"Fully Compliant"`, `"Partially Compliant"`, `"Alternative Proposed"`, `"Not Applicable"`
- Status values NO: `"Fullt samsvar"`, `"Delvis samsvar"`, `"Alternativ foreslått"`, `"Ikke aktuelt"`
- Include when: 5+ requirements (always), EU tenders (always), small RFIs (ask user)

### Figure Placeholders
- `figure_number`: Sequential (1, 2, 3…)
- `caption`: Language-aware ("Figure N:" / "Figur N:")
- `description`: Instructions for designer/user
- `size`: `"half"` (~5cm) or `"full"` (~8cm)
- Reference figures in narrative: "Figure 2 illustrates..." / "Figur 3 viser..."

### Tables (inline or standalone)
- `headers`: Array of column header strings
- `rows`: Array of arrays (each inner array = one row)
- `caption`: Optional, shown below in purple italic
- `style`: `"branded"` (purple header, default) or `"plain"` (grey header — use for appendices)

### Executive Summary
- Include when: 8+ requirements or large tenders
- Build **after** all responses are approved — pull from Introduction, win themes, key takeaways
- `highlights`: One row per major response area, condensed to ~15 words

### Appendices
- Auto-numbered A, B, C… based on order
- Use `"plain"` table style to distinguish from main response
- Common types: Reference case details, Certifications, Proposed key personnel, SLA catalogue, Glossary

---

## Lot-Based Format (multi-lot tenders)

Use when the parser detects lot/tower structure. The generator auto-detects which format is used.

```json
{
    "customer": "Customer Name",
    "rfi_title": "RFI Title",
    "language": "en",
    "shared_sections": [
        {"type": "executive_summary", "...": "..."},
        {"heading": "Introduction", "type": "h1"},
        {"type": "text", "content": "Shared intro text..."}
    ],
    "lots": [
        {
            "lot_id": "Lot 1",
            "lot_name": "Cloud Platform",
            "consortium_lead": "Sopra Steria",
            "intro": "Optional lot intro paragraph...",
            "compliance_matrix": {
                "type": "compliance_matrix",
                "heading": "Lot 1 Compliance Overview",
                "heading_style": "Heading 2",
                "rows": [{"req_id": "L1-R01", "requirement": "...", "status": "Fully Compliant", "section_ref": "L1.1"}]
            },
            "sections": [
                {"type": "requirement", "heading": "L1.1 ...", "...": "..."}
            ]
        }
    ],
    "shared_appendices": [
        {"type": "appendix", "heading": "Certifications", "...": "..."}
    ]
}
```

**Structure:**
- `shared_sections`: Rendered first — executive summary, introduction
- `lots[]`: Each lot becomes a Heading 1 chapter
- `shared_appendices`: Rendered last

**Per-lot fields:**
- `lot_id`: Display ID (e.g. "Lot 1", "Lot A")
- `lot_name`: Descriptive name
- `consortium_lead`: Who delivers this lot. If not "Sopra Steria", a note is added
- `intro`: Optional intro paragraph
- `compliance_matrix`: Optional per-lot compliance matrix
- `sections[]`: Requirement responses for this lot

**Output modes** (`--mode` flag):
- `combined` — One document with lot chapters (default when lots detected)
- `per_lot` — Separate document per lot (files named `[output]_Lot_1.docx`, etc.)
- `flat` — Force flat rendering even if lots present

---

## Top-Level Metadata Fields

| Field | Required | Description |
|-------|----------|-------------|
| `customer` | Yes | Customer name for cover page |
| `rfi_title` | Yes | RFI title for cover page |
| `language` | Yes | `"en"` or `"no"` — controls all language-specific output |
| `word_limits` | No | Global word/page limits (see below) |
| `_changelog` | No | Audit trail from `diff_responses.py --embed` |

### Word Limits

```json
"word_limits": {
    "max_words_per_requirement": 300,
    "max_total_words": 10000,
    "max_pages": 40
}
```

- All fields optional — set only what the procurement requires
- `max_pages` converts to `max_total_words` at ~250 words/page
- Individual requirements can override with `"max_words"` field
- Validator checks these and flags overruns as warnings

---

## Recommended Document Section Order

1. Executive Summary (for 8+ requirements or large tenders)
2. Introduction (H1) + strategic framing text
3. Company Overview (About Sopra Steria + About DPS)
4. Compliance Matrix (for 5+ requirements)
5. Detailed Responses (H1) + requirement sections with inline tables
6. Appendices (reference details, certifications, key personnel)

---

## Company Overview Section

The `company_overview` section type generates two standardised Heading 2 sections:
"About Sopra Steria" and "About Digital Platform Services" with the current corporate facts.
Content is auto-generated in the correct language. Place it right after the Introduction.

```json
{"type": "company_overview"}
```

That's all that's needed — the generator handles the rest. To override the default text:

```json
{
    "type": "company_overview",
    "heading": "About Sopra Steria",
    "custom_ss_text": "Custom text for the About Sopra Steria section...",
    "custom_dps_text": "Custom text for the About DPS section..."
}
```

**When to include:** Always, unless the RFI explicitly says not to include company background.

---

## Confidence Scoring

Requirements can carry an optional `"confidence"` field to help the bid team prioritise review:

```json
{
    "type": "requirement",
    "heading": "2.1 Cloud Platform",
    "confidence": "high",
    "key_takeaway": "...",
    "content": "..."
}
```

Values:
- `"high"` — Strong product match (score 50+), multiple relevant references, clear alignment
- `"medium"` — Partial match, interpretation required, or niche requirement
- `"low"` — Outside core portfolio, speculative, or requires significant SME input

**How to assign:** When drafting in Step 5, assess based on:
- Product match score from the parser (50+ = high, 20–50 = medium, <20 = low)
- Whether reference cases are available for this requirement area
- Whether the response required extrapolation beyond the product catalog

**What the validator does:** Summarises the distribution (e.g., "8 high, 3 medium, 1 low")
and flags low-confidence responses by name for priority SME review. The confidence field is
not rendered in the output document — it's metadata for the bid team only.
