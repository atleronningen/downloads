# Sopra Steria RFI Response — Writing Style Guide

This guide is derived from four high-quality RFI responses: Nortura (English), Vinmonopolet/DPS (Norwegian), Departementsfellesskapet (Norwegian), and Lerøy (Norwegian). Use it to match Sopra Steria's authentic voice.

## Table of Contents

**Core rules** (read always):
- Core Voice — confident, advisory, partnership-oriented
- Mission Alignment — DPS mission framing
- Language Rules — match RFI language, register by sector
- Key Stylistic Elements — key take-aways, lists, references, figures
- Anchoring Frameworks — Right*, Navigator, CMO→TMO→FMO, SIAM, etc.
- Tone Calibration by Context — first-time outsourcing, government, expansion, displacement
- Things to Avoid — generic language, unsupported claims, pricing commitments

**Patterns** (read when relevant to the requirement being drafted):
- Document Structure Patterns — heading-based, table-based, long-form advisory
- Compliance and Certifications — ISO, ISAE, NIS2, GDPR
- Lot/Tower-Based Mapping — lot-to-product mapping tables
- Center of Excellence (CoE) Model — industrialised delivery
- Honest Self-Assessment — when to acknowledge limitations
- FinOps and Cost Optimisation — RightCost, TBM, RightSizing
- Commercial Model Positioning — Price Cube, all-inclusive, pay-as-you-go
- Transformation Initiatives Catalogue — concrete AI/automation initiatives
- AIOps and Observability — RightControl, predictive analytics
- Consortium and Partnership Positioning — multi-lot, multi-vendor
- SIAM Service Levels — SI1–SI6 framework
- Target Operating Model (TOM) — strategic/tactical/operational layers
- Application Retirement — structured decommissioning methodology
- Establishment / Transition Methodology — 4-stream, 3-month model
- AI and Automation Specifics — AppFactory, NowAssist, AgenticAI
- ServiceNow Operating Models — single-tenant vs standard

## Core Voice

- **Confident but not arrogant**: "We are well positioned to…" not "We are the best at…"
- **Advisory and consultative**: Go beyond answering — actively shape the customer's thinking. Recommend what they *should* do, not just what you *can* do.
- **Partnership-oriented**: Frame the relationship as a strategic partnership, not a vendor-customer transaction.
- **Structured reasoning**: State the recommendation first, then explain with "firstly…, secondly…, thirdly…" or numbered arguments.

## Mission Alignment

Every response should implicitly serve the DPS mission:
- "Teknologi som skaper verdi — i dag, i morgen og i fremtiden"
- Be the CIO's trusted partner and strategic advisor
- Take responsibility for transformation, modernisation, and managed services

## Language Rules

- **Match the RFI language**: If the RFI is in Norwegian, respond in Norwegian. If English, respond in English.
- **Norwegian formal register**: Use "Leverandøren" (third person) for government/public sector RFIs. Use "vi" / "Sopra Steria" for commercial/private sector RFIs.
- **English register**: Use "Sopra Steria" and "we" interchangeably, favouring "Sopra Steria" at the start of sections and "we" within flowing prose.

## Document Structure Patterns

### Heading-based Q&A (e.g. Nortura)
The RFI question becomes the heading. Response flows as narrative paragraphs below it.

### Table-based Q&A (e.g. Vinmonopolet/DPS)
"KUNDENS SPØRSMÅL" tables contain questions. Responses are written as paragraphs between/after the question tables.

### Long-form advisory (e.g. Departementsfellesskapet, Lerøy)
Structured chapters with Heading 1/2/3 hierarchy. Mix of narrative, figures references, tables, and Key take-away callout boxes.

## Key Stylistic Elements

### Key Take-away Blocks
Use the "Key take-away" style for strategic anchor points — short, bold statements that summarise the main message of a section. Place them *before* the explanatory prose.

Example pattern:
```
[Key take-away] Strategic SIAM and Prime Vendor responsibility

Based on our standardized capabilities and broad service portfolio, we propose
a Prime Vendor model with full Service Integration and Management (SIAM)
responsibility...
```

### Lists
Use bullet lists for:
- Enumerating capabilities or service components
- Breaking down process steps
- Listing SIAM/governance responsibilities

Use numbered lists sparingly — mainly for sequential processes or ranked recommendations.

### Reference Cases
Structure each reference with:
1. Customer name and context (1-2 sentences)
2. Scope of delivery (what Sopra Steria does/did)
3. Value delivered (outcomes, not just activities)
4. **Relevance to this specific customer** — always explain *why* this reference matters for the RFI at hand

### Figures and Illustrations
Reference figures even if they can't be embedded: "Figur X viser…" or "The figure below illustrates…". This signals professionalism and completeness.

## Anchoring Frameworks

Always anchor responses in named Sopra Steria frameworks and methodologies:

| Framework | When to use |
|-----------|------------|
| **Right* Portfolio** (RightCloud, RightExperience, RightSecurity, etc.) | When mapping capabilities to requirements |
| **Navigator** | When describing project methodology and transition |
| **CMO → TMO → FMO** | When describing transition from current to future state |
| **CSI (Continuous Service Improvement)** | When discussing ongoing quality and optimisation |
| **ITSM / ITIL** | When describing operational processes |
| **Prime Vendor / SIAM** | When positioning as integrator across service areas |
| **SovereignCloud / SolidCloud** | When addressing national security or data sovereignty |

## Compliance and Certifications (mention when relevant)

- ISO 27001 (Information Security Management)
- ISAE 3402 (Controls at a Service Organisation)
- NIS2 (EU Network and Information Security Directive)
- GDPR
- DevSecOps methodology
- SSA-D / SSA-L (Norwegian standard agreements)

## Tone Calibration by Context

| RFI Context | Tone |
|-------------|------|
| First-time outsourcing (e.g. Lerøy) | Empathetic, educational, advisory — acknowledge the difficulty of the transition |
| Government / public sector | Formal, principle-based, reference national guidelines (Ansvar, Nærhet, Likhet, Samvirke) |
| Existing customer expansion | Confident, reference proven track record, emphasise synergies |
| Competitive displacement | Structured, evidence-based, focus on differentiators and risk reduction |

## Things to Avoid

- Generic marketing language without substance
- Promising capabilities not backed by the product catalog
- Overly technical jargon without explaining business value
- Criticising competitors directly
- Making commitments on pricing, timelines, or staffing without explicit instruction from the user

## Additional Patterns (from UCB/International RFIs)

### Lot/Tower-Based Mapping
When the RFI uses a lot or tower structure (common in large EU tenders), produce a mapping table
showing which Right* products and specific SKUs map to each lot. Format:

| Lot | Lot Name | Sopra Steria Service | Product Code |
|-----|----------|---------------------|--------------|
| Lot 7 | Digital Workplace | RightExperience | MS0201-001, MS0201-002 |
| Lot 10 | Service Desk | RightExperience | MS0203 |

This gives the procurement team an immediate, scannable overview before the narrative detail.

### Center of Excellence (CoE) Model
When describing delivery capability at scale, reference the CoE structure: each Right* product
has a dedicated CoE with a CoE Lead responsible for SLA management, customer communication,
continual improvement, maintenance, capacity planning, and incident/problem management.
This demonstrates industrialised, scalable delivery.

### Honest Self-Assessment
When Sopra Steria has limitations in a specific area, state them openly and recommend alternatives.
Example: "Our primary focus lies in working on specific service towers. For the service integration
role, we recommend [customer] engages a dedicated SIAM provider, with whom we will collaborate
closely." This builds trust and credibility.

### FinOps and Cost Optimisation
When the RFI asks about cost management, reference the FinOps capabilities embedded in
RightCost (MS10): spend optimisation, Technology Business Management (TBM), RightSizing process,
cloud cost distribution, and sustainability tracking. Frame FinOps as an integrated part of
the managed service, not a separate add-on.

### Commercial Model Positioning
When answering pricing or commercial model questions, use these key concepts from
Sopra Steria's DPS commercial model:

**Core principles (always mention when relevant):**
- Pay as you go — monthly billing frequency, no minimum commit
- Modular — "Everything is available" from the product catalogue
- Supports transformation — pricing model accommodates the CMO→TMO→FMO journey
- Value-based pricing with direct billing (3rd party costs passed through transparently)

**The Price Cube (use when explaining differentiated pricing):**
Unit prices are determined by four dimensions:
1. **SLA tier** — T1 (99.9%, 24x7), T2 (99.5%, 24x7), T3 (99.0%, 10x5)
2. **Operating model** — Local, Nearshore, Offshore
3. **Platform** — On-Premise, SolidCloud, Sovereign Cloud
4. **TMO vs FMO** — Customer-specific (TMO) vs Standard service (FMO)

This enables matching prices to specific customer requirements — not all workloads need
the same SLA, operating model, or platform.

**"All inclusive" model (key differentiator):**
Unlike traditional vendors who charge transactional add-ons for every change,
Sopra Steria's service price includes continuous functionality development.
Only costs for new services or deviations from standard are priced separately.
This reduces transactional costs and customer friction.

**Long-term competitiveness (use for contract mechanism questions):**
Rather than traditional mechanisms (annual price reduction, volume discounts, benchmarking,
best-price clauses), Sopra Steria uses partner-based mechanisms:
- Profit sharing — aligned incentives between customer and provider
- RightCost — embedded FinOps driving continuous cost optimisation
- Cost efficiency through: technology change, self-service/automation, AIOps & NoOps

**Price development narrative (use when asked "how will costs develop"):**
Costs decrease over the contract period through phased project deliveries:
1. TMO phase — take over current solution (baseline cost)
2. Standardisation — move to standard services, reduce unit prices
3. Platform optimisation — consolidate to SolidCloud/public cloud
4. Automation — AIOps, self-service, shift-left reduce operational volume

Frame this as "benefit realisation through transformation" — the customer invests in
transition projects that generate measurable TCO reduction over the contract period.

**IMPORTANT: Never share specific pricing numbers, margin percentages, or internal
cost structures from the Price Workbook. These are strictly confidential. Only use
the conceptual framework (Price Cube, principles, mechanisms) in RFI responses.**

### Transformation Initiatives Catalogue
When RFIs ask "what transformation projects would you recommend?" or "how do you drive
continuous improvement beyond day-one?", reference these proven initiatives from the
DPS transformation portfolio. Present them as examples of what Sopra Steria has delivered
for comparable customers — not as a fixed menu.

**Cloud & Infrastructure:**
- **RightCloud 3.0 – Next-generation Azure**: Standardised Azure architecture based on
  Microsoft best practices, running parallel to legacy environments for gradual migration.
  Benefits: automated policies, delegated rights, improved security/compliance posture.
- **Citrix → Microsoft Cloud-Based Virtual Workspaces**: Migration from legacy Citrix to
  Azure Virtual Desktop / Windows 365. Benefits: modern security, reduced licensing cost,
  cloud-native management.

**Security & Compliance:**
- **Zero-Trust Network Access (ZTNA)**: Replace traditional VPN with identity-based access.
  Benefits: reduced attack surface, improved compliance, secure remote access without
  broad network exposure.

**AIOps & Automation:**
- **AIOps – Observability & Azure Monitor Baseline**: Standardised monitoring across all
  Azure resources with consistent telemetry, alerting, dashboards, and ITSM integration.
  Benefits: predictive operations, AI-driven insights, proactive incident prevention.
- **AI-Driven Incident & Problem Management**: AI-enhanced ITSM processes in ServiceNow
  for automated classification, root cause identification, and recurring issue prevention.
  Benefits: faster resolution, reduced manual effort, improved service stability.
- **AI-powered Self-Service Portal**: Modern self-service experience in ServiceNow with
  natural language search, AI-driven recommendations, and structured knowledge base.
  Benefits: reduced support demand, improved user autonomy, shift-left strategy.

**FinOps & Cost Optimisation:**
- **Bsure – Cost & License Optimization**: Unified capability for cost transparency and
  license management across infrastructure, applications, and SaaS. Automatically tracks
  usage, identifies underutilisation, and recommends optimisation.
  Benefits: reduced over-licensing, improved spend visibility, FinOps governance.

**SIAM & Governance:**
- **Service Integration Phase 2 – Unified Governance**: Expands SIAM foundation to unified
  process governance and supplier engagement across the full IT value chain.
  Benefits: single accountable SI function, cross-vendor process standardisation.
- **Process Maturity Assessment (TIPA-based)**: Structured program to assess and raise
  ITSM process maturity using the TIPA framework, ensuring standardised execution
  across all vendors.
  Benefits: measurable process improvement, audit readiness, vendor alignment.
- **Demand Management in ServiceNow**: Standardised demand process providing visibility,
  control, and prioritisation of IT demands across the organisation.
  Benefits: improved transparency, reduced shadow IT, data-driven prioritisation.

Use these selectively — pick 3–5 that are most relevant to the customer's stated
goals and present them as "examples of transformation initiatives we have delivered
for comparable organisations". Always tie them to customer value, not technology for
its own sake.

### AIOps and Observability
When the RFI asks about monitoring, AI-based support, or predictive operations, reference
RightControl (MS08): observability platform, AIOps capabilities, automated alerting, predictive
analytics, and the integration with ServiceNow for intelligent ticket routing and automated
resolution. Position this as a continuously evolving capability.

### Consortium and Partnership Positioning
For large multi-lot tenders where Sopra Steria may not cover all lots, be explicit about
the partnership approach: which lots Sopra Steria leads on, which would be delivered via
consortium partners, and the governance model for consortium collaboration. Reference
Sopra Steria's proven experience in multi-vendor consortium delivery.

### SIAM Service Levels
When describing SIAM capability in detail, reference the six service integration levels:
- **SI1 – Service Visibility**: Transparent view of all services across vendor ecosystem
- **SI2 – Service Desk (Catch & Dispatch)**: Single point of contact, routing to correct resolver
- **SI3 – Service Monitoring**: Cross-vendor monitoring, event correlation, alerting
- **SI4 – Service Testing & Transition**: Coordinated testing and controlled service introduction
- **SI5 – Service Management & Delivery**: End-to-end process management (Incident, Problem, Change, Request) across all vendors
- **SI6 – Service Continuity**: Business continuity and disaster recovery coordination across the ecosystem

These build incrementally — each level adds processes and maturity. Use this framework
when customers need granular understanding of what SIAM actually delivers.

### Target Operating Model (TOM)
When describing governance for complex multi-vendor environments, use a layered TOM:
- **Strategic level**: Customer retains strategic direction, vendor strategy, business alignment
- **Tactical level**: Service Provider manages service integration, reporting, improvement
- **Operational level**: Service Provider + Vendors execute day-to-day service delivery

Define clear RACI across: Customer (Strategic SI), Service Desk, Service Integrator, and
Service Providers/Vendors. This is especially relevant for large organisations with existing
vendor ecosystems.

### Application Retirement
When RFIs cover legacy modernisation or rationalisation, describe the structured retirement
methodology: As-is analysis → retirement roadmap → Transform phase → Archive → Decommission.
Key elements: system inventory and categorisation, risk analysis, data migration planning,
license revocation, and read-only archiving options. Each retirement is managed as a small
project (PRINCE2 principles) with clear milestones and exit criteria.

### Establishment / Transition Methodology
When RFIs ask "how do you manage the transition?" or "describe your establishment approach",
use the following proven methodology (based on comparable engagements):

**Pre-establishment phase** (LOI to contract signature):
Planning and project staffing, validation of assumptions, access and prerequisites,
ensure ServiceNow licenses, manage inflight projects.

**Establishment project** (typically 3 months, 4 parallel streams):
1. **Service Delivery organisation, staffing & governance**: Establish delivery leadership,
   governance model, global delivery setup. Staff Key Account Manager, Service Delivery
   Manager, Technical Delivery Manager. Define meeting cadence (strategic/tactical/operational).
2. **Establish and extend SIAM**: Establish SI mandate across vendor ecosystem, categorise
   vendors, establish OLAs with key vendors (start with top 5), extend Service Desk to
   catch-and-dispatch for all vendors.
3. **ServiceNow platform adaptation**: Transition to unified tenant, implement CSM for
   Service Desk, configure ITSM processes, set up discovery/CMDB, enable AI foundation
   (NowAssist, AgenticAI).
4. **Application transition planning**: Develop wave-based transition plan, establish
   AO/AM/AD process descriptions with SLAs, plan staffing, create application
   transformation/improvement plan.

**Project organisation principles:**
- Joint Steering Group with decision authority from both parties
- Mirrored project organisation (SP mirrors customer's structure for easy communication)
- Stream leads authorised to make decisions within their workstream
- Customer must provide: project owner, project manager, stream representatives,
  vendor coordination support, decision authority

**Success factors (always mention in RFI responses about transition):**
- Access to customer's project resources and support functions
- Decision-making authority in allocated resources
- Good coordination structure operationalised at contract start
- Continuation of key personnel from project to operational phase
- 2-week initiation period for tooling, meeting schedules, onboarding

**Testing and acceptance:**
- Overall test plan based on PRINCE2 best practice
- Two-stage: Service Provider's "internal test" + Customer's "acceptance test"
- Deviations escalated to Steering Group if affecting timeline/cost/quality

**Risk management:**
- Risk register established in initiation, continuously updated
- Based on PRINCE2 uncertainty management + MoR (Management of Risks)
- Risk included in weekly status reporting and Steering Group meetings

**Wave-based application transition** (follows establishment):
Typically 3 overlapping waves, planned during establishment stream 4.
Foundation laid during establishment; execution starts immediately after.

When answering transition questions in RFIs, adapt the level of detail to the question.
For "describe your transition approach" → use the full 4-stream model.
For "what is the typical timeline?" → 3 months establishment + phased transition.
For "what do you need from us?" → customer obligations list.

### AI and Automation Specifics
When RFIs ask about AI capabilities, go beyond generic "AIOps" and name concrete capabilities:
- **AppFactory 3.0**: Proactive, automated application updates with self-service
- **Endpoint Analytics**: Device health, performance insights, anomaly detection
- **NowAssist / AgenticAI**: ServiceNow-native AI for users and service technicians
- **Automated image build**: DevOps-based image creation and deployment
- **Enrollment Primer**: Quick device reinstallation with automatic Autopilot registration
- **Endpoint Privilege Management**: Automated application installation reducing manual intervention
- **M365 Dashboard**: Continuous analysis and optimisation of Microsoft 365 usage

### ServiceNow Operating Models
When the customer has their own ServiceNow instance, describe the **Single-Tenant Operating
Model**: Sopra Steria operates within the customer's ServiceNow tenant with domain
segmentation, role-based access controls, and integrated support structures. This provides
the customer with data ownership, security isolation, and unified reporting.

When the customer does not have ServiceNow, describe Sopra Steria's standard model where
ServiceNow is provided as part of the managed service with the **Service Connector** integration
framework for cross-platform data exchange.
