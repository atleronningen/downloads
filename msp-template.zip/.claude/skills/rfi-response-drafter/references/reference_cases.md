# Sopra Steria DPS — Reference Cases Index

Use these references when drafting RFI responses. Always explain **why** a reference is
relevant to the specific customer's situation.

## Quick Selection Guide

| Customer | Industry | Scale | Best for |
|----------|----------|-------|----------|
| Bane NOR | Railway/infra | ~300 MNOK/yr | End-to-end, SIAM, critical infra |
| Oslo kommune | Public sector | ~1,200 MNOK | Large public, digital transformation |
| Posten Bring | Logistics | ~500 MNOK | Private cloud, IGA, dual-site DC |
| Kongsberg Gruppen | Defence | ~120 MNOK | Cloud, security-sensitive, DevOps |
| Statnett | Energy/grid | Ongoing | Critical national infra, energy |
| Vår Energi | Oil & gas | Ongoing | Offshore, industrial, on-site |
| SpareBank 1 | Banking | Ongoing | Multi-tenant Azure, financial |
| SINTEF | Research | Ongoing | Knowledge-intensive, innovation |
| Lyse | Energy/telecom | Ongoing | Workplace, identity, utilities |
| Trondheim kommune | Public sector | Ongoing | Long-term cloud migration |
| DOF | Maritime | Ongoing | Distributed/remote operations |
| Archer | Oil services | Ongoing | First-time outsourcing |

---

## Nordic References

### Bane NOR
- **Period**: 2020–ongoing
- **Value**: ~300 MNOK/year
- **Industry**: Public infrastructure (railway)
- **Scope**: Hybrid IT platform (private/public cloud, SaaS), SIAM, end-to-end security, end-user services, application and network operations
- **Key products**: RightCloud, RightExperience, RightSecurity (SOC), RightConnectivity, RightService
- **Differentiator**: Full Prime Vendor / SIAM model for critical national infrastructure
- **Relevance**: Ideal for large organisations wanting end-to-end managed services with SIAM, or operating critical infrastructure

### Oslo kommune (Municipality of Oslo)
- **Period**: 2021–ongoing
- **Value**: ~1,200 MNOK total
- **Industry**: Public sector (municipal services: healthcare, education, urban development)
- **Scope**: End-user services, infrastructure, application operations, network, security (SOC), unified ICT platform, hybrid cloud
- **Key products**: All Right* portfolios — full end-to-end delivery
- **Differentiator**: One of Norway's largest managed services contracts; transformation from fragmented to unified IT
- **Relevance**: Strong for large public sector organisations, complex stakeholder environments, digital transformation from legacy

### Posten Bring
- **Period**: Ongoing
- **Value**: ~500 MNOK
- **Industry**: Logistics and postal services
- **Scope**: SolidCloud private cloud platform, RightIdentity / One Identity Manager IGA, dual-site data centre architecture, SIAM integration
- **Key products**: RightCloud (SolidCloud private cloud), RightIdentity, RightService (SIAM)
- **Differentiator**: Sovereign private cloud for Norway's national postal/logistics operator; full IGA transformation with One Identity Manager
- **Relevance**: Organisations requiring private/sovereign cloud, identity governance, or dual-site resilience; logistics and transport sector

### Kongsberg Gruppen
- **Period**: 2021–ongoing
- **Value**: ~120 MNOK total
- **Industry**: Defence, maritime, aerospace (security-sensitive)
- **Scope**: Azure platform with compute, storage, networking, security, identity management, automation
- **Key products**: RightCloud (Azure), Infrastructure-as-Code, DevOps, Kubernetes, Terraform
- **Differentiator**: Azure Expert MSP, managing security-sensitive workloads for a defence contractor
- **Relevance**: Strong for customers needing cloud transformation, DevOps practices, or operating in regulated/security-sensitive environments

### Statnett
- **Period**: Ongoing
- **Industry**: Energy (national transmission grid operator)
- **Scope**: IT infrastructure operations, security operations, managed services for critical national energy infrastructure
- **Key products**: RightCloud, RightSecurity, RightControl
- **Differentiator**: Managed services for the operator of Norway's national power grid — extreme availability and security requirements
- **Relevance**: Energy and utilities, critical national infrastructure, organisations with stringent regulatory and security requirements (NIS2, power sector)

### Vår Energi
- **Period**: 2022–ongoing
- **Industry**: Oil & gas (offshore operations)
- **Scope**: Physical service desk, infrastructure operations (servers, storage, backup, LAN/WAN, databases, Citrix, monitoring), security operations, Cloud Center of Excellence
- **Key products**: RightCloud, RightExperience (Service Desk), RightSecurity, RightControl
- **Differentiator**: Critical operations environment (offshore vessels/platforms), FTE-based delivery model
- **Relevance**: Energy sector, industrial environments, organisations needing physical on-site presence

### SpareBank 1 Utvikling
- **Period**: Ongoing
- **Industry**: Financial services (banking alliance)
- **Scope**: Multi-tenant Azure platform, DevOps/automation, legacy modernisation, M365 management including Copilot rollout
- **Key products**: RightCloud (Azure), RightApplications, RightExperience (M365)
- **Differentiator**: Multi-tenant platform serving 12 banks; Azure Kubernetes, M365 Copilot
- **Relevance**: Financial sector, multi-entity organisations, Azure-heavy environments

### SINTEF
- **Period**: Ongoing
- **Industry**: Research / academia
- **Scope**: Standardised platform, cloud migration, DevOps team, digital workplace, end-to-end services
- **Key products**: RightCloud, RightExperience, RightApplications
- **Differentiator**: Strategic advisor + managed services provider for a world-class research organisation
- **Relevance**: Knowledge-intensive organisations needing modern platforms and rapid innovation

### Lyse
- **Period**: Ongoing
- **Industry**: Energy and telecommunications
- **Scope**: End-user and workplace services, identity and access management, automation, Service Desk
- **Key products**: RightExperience (full portfolio), Service Desk
- **Differentiator**: Modern cloud-based workplace with stringent security (energy/critical infrastructure)
- **Relevance**: Utilities, telecom, organisations modernising end-user services

### Trondheim kommune
- **Period**: Ongoing
- **Industry**: Public sector (municipal services, 210,000 inhabitants)
- **Scope**: Server/application/platform operations, Azure migration, container platforms, 24/7 SOC
- **Key products**: RightCloud, RightApplications, RightSecurity
- **Differentiator**: Cloud transformation roadmap (10–15 year vision from on-prem to cloud)
- **Relevance**: Municipalities and public sector organisations planning long-term cloud migration

### DOF (via Marin IT acquisition)
- **Period**: Ongoing (inherited from Marin IT, acquired 2023)
- **Industry**: Maritime / offshore construction and subsea
- **Scope**: IT operations for 70+ vessels, onshore/offshore infrastructure
- **Differentiator**: Maritime IT operations with extreme availability requirements
- **Relevance**: Maritime, offshore, distributed/remote operations

### Archer
- **Period**: Ongoing
- **Industry**: Oil services (well services, modular rigs)
- **Scope**: IT outsourcing, infrastructure operations
- **Differentiator**: First-time outsourcing engagement with structured transition
- **Relevance**: Companies considering first-time IT outsourcing
