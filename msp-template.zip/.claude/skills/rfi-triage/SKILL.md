---
name: rfi-triage
description: >
  This skill should be used when a new RFI, RFP, or tender document has just landed and
  the user wants a fast go/no-go read before committing to the full rfi-response-drafter
  workflow. Trigger on "triage this RFI", "quick read on this RFI", "give me the rundown
  on this tender", "should we bid on this", "skim this RFI", "what language and sector is
  this one", "how big is this one", or when a new RFI/RFP file has just been dropped into
  a customer subfolder and the user hasn't yet said "let's draft this."
metadata:
  version: "0.1.0"
---

# RFI triage

Do a single fast pass over a newly-received RFI, RFP, or tender document and answer one
question for the bid owner: is this worth committing to, and what will it take? This is a
2-minute gut check, not the drafting workflow.

Do NOT answer requirements, draft responses, open the Word template, or hand off into the
rfi-response-drafter skill's output format as part of this skill. Produce the triage
report below and stop. Proceeding to drafting is a separate decision the user makes
afterward.

## Step 1: Locate and extract the text

Find the RFI document — usually the most recently added `.docx` or `.pdf` in this workspace's
`Customers request/` folder, or a freshly uploaded file. If it's not obvious which file to use,
ask.

Extract plain text:

- `.docx`: try `pandoc file.docx -t plain`; if pandoc isn't available, use Python with
  `python-docx` (`pip install python-docx --break-system-packages` if missing).
- `.pdf`: try `pdftotext file.pdf -` (poppler-utils); if unavailable, use Python with
  `pdfplumber` or `PyPDF2` (`pip install pdfplumber --break-system-packages` if missing).

Only extract enough to triage — for a long document, sample the first several pages plus
headings, numbered clauses, and any table of contents rather than processing every page.

## Step 2: Determine language

Confirm Norwegian or English from the body text. Flag explicitly if the document is
genuinely mixed — the eventual response should commit to one language, never mix.

## Step 3: Determine sector and register

Classify the customer as public sector or private sector, and state the register that
implies per this project's drafting rules:

- Public sector signals: references to "Lov om offentlige anskaffelser" / public
  procurement law, Doffin/TED tender notice numbers, a kommune/fylkeskommune/statlig
  etat/direktorat as the contracting entity, formal tender terminology
  ("konkurransegrunnlag", "tilbudsfrist", "kvalifikasjonskrav").
- Private sector signals: a private company as counterparty, commercial RFP language, no
  procurement-law citation.
- Public sector → formal third person ("Leverandøren"). Private sector → first person,
  consultative ("Sopra Steria" / "vi").

If signals are ambiguous, say so rather than guessing — this determines the voice of the
eventual response and getting it wrong is costly.

## Step 4: Estimate size

- Approximate page count / word count of the source document(s).
- A rough count of discrete requirements or questions (numbered clauses, question marks in
  structured sections, a requirements table, "krav"/"requirement" labeling). Give a range
  if an exact count isn't feasible from a skim (e.g. "roughly 40-60 requirements across 6
  sections").
- Note if there's a separate product/solution catalog (e.g. an Appendix 2) that will need
  cross-referencing later — that adds drafting time.

## Step 5: Find the deadline

Search for "frist", "tilbudsfrist", "deadline", "submission date", "closing date", and any
separate Q&A/clarification-question cutoff. Report the actual date if found; flag clearly
if no deadline was found in the material scanned.

## Step 6: Flag likely Right* product fit

Sopra Steria's DPS portfolio: RightCloud, RightExperience, RightSecurity, RightService,
RightApplications, RightConnectivity, RightIdentity, RightControl, RightCost,
RightIndustry.

First, run the freshness check in `.claude/rules/dps-contract-access.md` — this skill
reads `content/dps-contract/` from the local `service-catalog` clone directly, so confirm the
clone isn't behind `origin/main` before relying on it. Then, before naming any product, skim
its actual definition in `content/dps-contract/` (e.g. `ms02-rightexperience.md`,
`ms05-rightservice.md`) — do not map from the product name alone, several names are
counter-intuitive. In particular: **RightService is SIAM / multi-supplier
governance, not desk-side/on-site end-user support or servicedesk/incident handling** — that
belongs under RightExperience (MS0203-004 IT Service Point). This has been mis-mapped before;
read `content/dps-contract/ms05-rightservice.md` before flagging
RightService for anything end-user-facing.

Scan for keyword signals — cloud/infrastructure, digital workplace/experience,
security/SOC, servicedesk/incident/IMAC (→ RightExperience, not RightService),
SIAM/multi-supplier governance (→ RightService), application management/ALM,
network/connectivity, IAM/identity, governance/compliance, cost/FinOps,
industry-specific systems — and list which products look relevant, cross-checked against
each product's definition file rather than guessed from its name.
This is a first impression for scoping, not a committed mapping; say explicitly that full
mapping happens later via the service-catalog skill during actual drafting.

## Output format

Keep it tight — a 2-minute read, not a document:

**[Customer name] — triage summary**

- **Language:** ...
- **Sector / register:** ...
- **Size:** ... (page/word estimate, requirement count estimate, any catalog to
  cross-reference)
- **Deadline:** ... (or "not found in scanned material — check manually")
- **Likely Right\* products:** ... (comma-separated, first-impression only)
- **Gut call:** one sentence — small/medium/large lift, any red flags (very tight
  deadline, heavy public-sector formality, huge requirement count relative to time
  available), and whether it looks worth committing to.

Don't pad this with caveats beyond what's listed, and don't drift into drafting territory
even if the material is thin enough to plausibly start answering questions — that decision
belongs to the user.
