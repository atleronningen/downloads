#!/usr/bin/env python3
"""
Extract requirement sections (heading, key takeaway, body content) from a generated
RFI response .docx, for use by the rfi-compliance-checker skill when no live
responses.json is available in the session (Path B: checking a finished document).

This is a best-effort structural extraction, not a full re-parse of the document model
rfi-response-drafter uses internally. It walks paragraphs, treats "Heading 1" as chapter/lot
context and "Heading 2" as the start of a new requirement section, and tries to detect the
"key take-away" lead sentence via its bold formatting (matching the house style: every
requirement response opens with a bolded strategic one-liner).

Usage:
    python3 extract_docx_sections.py --file path/to/Customer_RFI_Response.docx --output sections.json
"""
import argparse
import json
from docx import Document


def extract(path):
    doc = Document(path)
    sections = []
    current = None
    current_h1 = None

    for para in doc.paragraphs:
        text = para.text.strip()
        style = para.style.name if para.style else ""

        if not text:
            continue

        if style == "Heading 1":
            current_h1 = text
            continue

        if style == "Heading 2":
            if current is not None:
                current["content"] = current["content"].strip()
                sections.append(current)
            current = {
                "heading": text,
                "h1_context": current_h1,
                "key_takeaway": None,
                "content": "",
            }
            continue

        if current is None:
            # Text before the first Heading 2 (e.g. intro, exec summary) - skip for this
            # extraction; the compliance checker only cares about requirement sections.
            continue

        # Detect the key take-away: the first paragraph in this section that has a
        # meaningfully long bold lead-in. House style bolds the whole lead sentence.
        if current["key_takeaway"] is None:
            bold_text = "".join(run.text for run in para.runs if run.bold)
            if bold_text and len(bold_text.strip()) > 10:
                current["key_takeaway"] = text
                continue

        current["content"] += text + "\n"

    if current is not None:
        current["content"] = current["content"].strip()
        sections.append(current)

    return sections


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--file", required=True, help="Path to the generated .docx")
    parser.add_argument("--output", required=True, help="Path to write extracted sections JSON")
    args = parser.parse_args()

    sections = extract(args.file)

    with open(args.output, "w", encoding="utf-8") as f:
        json.dump({"sections": sections}, f, ensure_ascii=False, indent=2)

    no_takeaway = sum(1 for s in sections if s["key_takeaway"] is None)
    print(f"Extracted {len(sections)} sections -> {args.output}")
    if no_takeaway:
        print(
            f"WARNING: {no_takeaway} section(s) had no detected key take-away "
            f"(no bold lead sentence found). Spot-check these against the document directly "
            f"before trusting the extraction."
        )


if __name__ == "__main__":
    main()
