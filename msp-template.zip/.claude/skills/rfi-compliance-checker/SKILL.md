---
name: rfi-compliance-checker
description: "Checks whether an RFI/RFP response's agreed WIN THEMES actually land across the document — different from the requirement-level 'Compliance Matrix' (Fully Compliant/etc.) rfi-response-drafter puts in the Word doc. Verifies the 2-4 strategic win themes are threaded (explicitly or paraphrased) through at least 30% of requirement responses, and cross-checks each theme against memory.md's win-themes library for a poor track record on past bids. Trigger on: 'check win theme compliance/coverage', 'run the compliance checker', 'audit the win themes', 'does this draft carry our win themes', 'are we hitting the 30% rule'. Trigger proactively at the end of an RFI drafting session, right before the user says 'generate it' — don't wait to be asked once multiple approved requirement responses and agreed win themes exist in the conversation."
---

# RFI Compliance Checker — Win Theme Coverage & Track Record

This skill audits one specific thing in an RFI/RFP response: whether the strategic win themes
agreed for the bid are actually present across enough of the requirement responses, and whether
any of those themes have a documented history of landing poorly on past bids.

**This is not the requirement-compliance matrix.** `rfi-response-drafter` already produces a
"Compliance Matrix" section in the generated Word document, which tracks whether Sopra Steria's
portfolio technically satisfies each individual customer requirement (statuses like "Fully
Compliant" / "Partially Compliant" / "Alternative Proposed"). That's about answering the
questions. This skill is about the persuasion layer on top: is the response actually selling the
agreed strategic story, or did the win themes get agreed in Step 3 and then quietly drop out of
the drafting? Don't confuse the two, and don't reuse this skill's report as a substitute for
the requirement compliance matrix or vice versa.

Why the 30% number matters: a win theme that's stated once in the introduction and never again
is not a strategic narrative — it's a slogan. The evaluator reading requirement-by-requirement
should keep bumping into the same 2-4 messages, reinforced in different technical contexts, for
it to actually shape their impression of Sopra Steria. Checking mechanically for this is cheap;
skipping the check means the first time anyone notices a theme didn't land is when the customer
reads the final document — or doesn't win the bid.

## Step 1: Identify the win themes for this bid

Win themes are agreed conversationally earlier in the RFI drafting session (in
`rfi-response-drafter`'s Step 3) and aren't always stored as a clean top-level field, so recover
them like this, in order of preference:

1. If a live `responses.json` exists in the session (see Step 2) and has an
   `executive_summary.win_themes` array, treat those as the working list — but confirm with the
   user, since the executive summary sometimes rewords themes slightly from how they were
   originally agreed.
2. Otherwise, ask the user directly: "What are the win themes locked in for this bid?" Don't
   guess or infer new ones — this skill checks against themes the user actually chose, not
   themes it thinks would be good.

You need the exact theme list before moving on — everything downstream depends on it.

## Step 2: Load the requirement responses

Two possible sources, in order of preference:

**Path A — live session draft.** If this check is happening in the same conversation where
`rfi-response-drafter` has been drafting, look for `/home/claude/responses.json`. Read it
directly:
- Flat format: iterate `sections[]`, keep only items where `"type": "requirement"`.
- Lot-based format: iterate `lots[]`, and within each lot iterate `sections[]`, again keeping
  only `"type": "requirement"` items. Treat every lot's requirements as one combined pool unless
  the user wants a per-lot breakdown (ask if there are 2+ lots).

Each requirement item gives you `heading`, `key_takeaway`, and `content` — that's everything you
need to judge theme presence.

**Path B — no live draft, checking a finished document.** If there's no `responses.json` in the
session (e.g. the user is checking a doc from an earlier session), locate the generated
response file. This workspace is a single case, so the generated response document sits
directly at the workspace root (check `CLAUDE.md`'s folder structure convention, and use the
actual filename — it won't always follow a fixed naming pattern).
Find the skill directory and run the extraction script:

```bash
SKILL_DIR=$(find /mnt/skills -path "*/rfi-compliance-checker/SKILL.md" -exec dirname {} \; 2>/dev/null | head -1)
python3 "$SKILL_DIR/scripts/extract_docx_sections.py" \
  --file "/mnt/user-data/uploads/[or path to the doc].docx" \
  --output /home/claude/extracted_sections.json
```

If `/mnt/skills` doesn't resolve to anything in the current environment (paths vary between
Claude Code, Cowork, etc.), don't give up on the `find` — search more broadly for a directory
containing `rfi-compliance-checker/SKILL.md`, or ask where skills are mounted in this session.

Read the output and sanity-check it before proceeding: if many sections came back with
`"key_takeaway": null`, the bold-lead-sentence heuristic may have missed the house style in that
particular document — open the docx directly and read a couple of sections to confirm the
extraction isn't silently dropping content. If it looks off, tell the user rather than pressing
ahead with a shaky report.

If neither path produces anything, ask the user to point you at the right file — don't fabricate
a report from nothing.

## Step 3: Judge win-theme presence per response

This is a judgment call, not a keyword search — the whole point of "threading" a win theme (per
`rfi-response-drafter`'s style guide) is that it gets paraphrased into the technical context of
each answer, not repeated verbatim. The style guide's own examples:

- Win theme "Partnership model" → response says "...designed for joint governance and shared
  accountability..." (no literal word "partnership", still counts)
- Win theme "AI-first automation" → response says "...with NowAssist and AgenticAI embedded from
  day one..." (counts)
- Win theme "Nordic delivery footprint" → response says "...delivered from our Nordic centres of
  excellence..." (counts)

For every requirement response, read the `key_takeaway` and `content`, and for every win theme
ask: does the substance of this answer meaningfully reinforce this theme, explicitly or in
paraphrase? A theme that's only tangentially related doesn't count — be honestly critical here,
the same way you'd want an evaluator to be. The hardest calls are usually a response that's
topically adjacent to a theme (e.g. a commercial-model response for a cost-leadership theme, or
a governance response for a partnership theme) but only mentions the topic in passing without
actually carrying the theme's substance — being in the "right" section isn't the same as
reinforcing the theme. When a mention only weakly gestures at a theme rather than substantively
reinforcing it, exclude it and say why in your working notes, rather than counting it because it
was close enough. Record a one-line rationale for every "yes" (quote or paraphrase the exact
sentence that carries the theme) so the user can audit your judgment instead of just trusting a
percentage.

Keep a simple table in your working notes: rows = requirement IDs, columns = win themes,
cells = yes/no + rationale.

## Step 4: Compute coverage and verdict

For each win theme:

```
coverage % = (number of requirement responses marked "yes" for this theme) / (total number of requirement responses)
```

Use the same denominator (total requirement responses, all categories) for every theme — this
matches the 30% rule as written in `CLAUDE.md` and `rfi-response-drafter`'s style guide, which
doesn't carve out commercial/procedural/risk categories separately.

Verdict per theme:
- **✅ On track** — coverage ≥ 30%
- **⚠️ Under the bar** — coverage < 30%

## Step 5: Cross-check against memory.md

Read `memory.md` at the repo root and look at the **Win themes library** table. For each of this bid's win themes,
check if a matching or closely related theme appears in that table:

- Match on meaning, not exact string — themes get reworded between bids. "Cost leadership
  through FinOps" and "All-inclusive pricing with FinOps-driven optimisation" are the same idea.
- If a match exists, read the `Notes` column and surface anything relevant: did it land well or
  poorly, and on which past engagement? This is the whole point of this step — catching "we're
  about to lean on a theme that's already shown to fall flat" before the document ships, not
  after.
- If memory.md doesn't exist yet, or has no Win themes library section, or no theme matches, say
  so plainly in one line rather than treating it as an error or padding the report with "no
  issues found."

This check is advisory, not a pass/fail gate like the 30% rule — a theme with a poor note in
memory.md isn't automatically wrong for this bid, it's a flag worth the user's attention.

## Step 6: Present the report

Report structure, in this order:

1. **One line per theme**: name, coverage %, verdict, and (if relevant) the memory.md note.
2. **Supporting detail per theme**: the requirement IDs where it was found, each with its
   one-line rationale — this is what makes the percentage trustworthy rather than a black box.
3. **Summary line**: "X of Y win themes meet the 30% bar."

If the total number of requirement responses is small (roughly under 10), say so once in the
summary — e.g. "note: only 6 requirement responses total, so these percentages move in coarse
15-17 point steps per response." A single response swinging a theme from 17% to 33% is a
different situation from the same swing in a 40-requirement document, and the user should know
which one they're looking at.

Example:

> **Nordic delivery footprint** — 3/6 responses (50%) ✅
> - R01: "...delivered from our Nordic centres of excellence, including the SOC in Norway..."
> - R04: "...leveraging the same Nordic delivery model proven at Bane NOR..."
> - R05: "...the Kongsberg reference demonstrates this exact Nordic footprint..."
>
> **Cost leadership through FinOps** — 0/6 responses (0%) ⚠️
> - No response currently carries this theme.
> - memory.md note: this theme (or a close variant) was flagged as landing poorly on the
>   [Customer] bid — evaluator feedback said it felt generic without concrete numbers attached.
>   Worth reconsidering, not just inserting harder.
>
> **AI-first automation** — 1/6 responses (17%) ⚠️
> - R02: "...NowAssist and AgenticAI embedded from day one..."
> - No memory.md history for this theme.
>
> **Summary**: 1 of 3 win themes meet the 30% bar.

If any theme is under the bar, offer next steps rather than just leaving the gap:

> "Want me to point out which 2-3 responses are the best candidates to weave [theme] into? I
> can flag the closest topical fits — you'd hand those back to rfi-response-drafter to actually
> redraft."

If you make that offer and the user says yes, scan the requirement responses that currently
carry *no* win theme at all and suggest the ones whose subject matter most naturally supports the
missing theme (e.g. a cost/commercial-adjacent requirement is a better candidate for a cost theme
than a pure security requirement). Name specific requirement IDs, don't just say "some responses."

## What this skill does not do

- It never edits `responses.json` or the generated `.docx` itself. It only reports and advises —
  any redrafting happens back in `rfi-response-drafter`'s refine step (Step 5d).
- It never invents win themes the user didn't agree to, and never silently drops a theme from
  the check because it's hard to find evidence for it — an absence is exactly the finding to
  report.
- It doesn't re-run or duplicate the requirement-compliance matrix, word-limit checks, or any of
  the other checks in `rfi-response-drafter`'s `validate_responses.py` — those stay where they
  are. This skill is scoped to win-theme coverage and win-theme track record only.
