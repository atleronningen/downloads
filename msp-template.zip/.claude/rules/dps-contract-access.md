# DPS-Contract Access & Freshness Check

There is no local mirror of `dps-contract` inside this workspace. Instead, `content/dps-contract/`
is read directly from a **local git clone of the InnerSource `service-catalog` repo**
(`https://innersource.soprasteria.com/go-to-market/service-catalog`) that you keep on your own
machine, **outside any OneDrive/SharePoint-synced folder** — symlinks and machine-specific
absolute paths do not survive OneDrive/SharePoint sync, so this clone cannot live inside the
case workspace itself.

## Convention path

By default, assume the clone lives at:

```
~/AI-teamwork/service-catalog
```

If your clone lives somewhere else on this machine, note the actual path under a "Lokalt
oppsett" section in this workspace's `CLAUDE.md` — the service-catalog skill and this check
should use that path instead.

If the clone doesn't exist yet at all, tell the user and ask them to run (once, outside any
synced folder):

```
git clone https://innersource.soprasteria.com/go-to-market/service-catalog.git ~/AI-teamwork/service-catalog
```

## Check

Before reading or citing anything under `<lokal-sti>/content/dps-contract/`, run:

```
git -C <lokal-sti> fetch origin main --quiet
git -C <lokal-sti> rev-list --count HEAD..origin/main -- content/dps-contract/
```

- **`0`** — the clone is current. Proceed normally.
- **Greater than `0`** — the local clone is behind. Do not read, quote, or rely on
  `content/dps-contract/` content yet.

## If stale

1. Tell the user clearly: how many commits behind, and the subject of the latest one touching
   `content/dps-contract/` (`git -C <lokal-sti> log --oneline -1 origin/main -- content/dps-contract/`).
2. Run `git -C <lokal-sti> pull --ff-only` to fetch it automatically.
3. If the pull succeeds, re-run the check above to confirm the clone is now current, then
   continue.
4. If the pull fails (diverged history, or local changes conflict with upstream), do not force
   or discard anything — stop and ask the user to resolve it manually before continuing (per
   `.claude/rules/safety-rules.md`).

## If the check itself can't run

If `git fetch` fails (no network/VPN access to the InnerSource remote, or the clone doesn't
exist yet), tell the user freshness could not be verified and that you're proceeding with the
possibly-stale (or missing) local clone — let them decide whether that's acceptable.
