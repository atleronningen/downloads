# Writing Style Rules — MSP-repo

Rules to apply automatically when drafting customer-facing content (RFI/RFP responses,
service descriptions, offers) in this repo. Don't wait to be reminded of these.

See `.claude/customer-value/writing-style-core.md` (this project's local copy of the
shared rules) for the shared rules and their examples.
Read that file before drafting and apply every rule in it, including any rule added there
since this file was last touched. That file is the authority; this one only adds the
project-specific example below.

## Project-specific example

Bad (negative contrast): "RightService is not the reactive helpdesk of old, but a proactive
managed service that resolves issues before users notice them."

Good (affirmative): "RightService is a proactive managed service that resolves issues before
users notice them."
