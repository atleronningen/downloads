# Safety & Compliance Rules

## Secrets & Credential Management
* ALDRI skriv passord, API-nøkler, private nøkler eller hemmeligheter inn i markdown-filene.
* Referer til hemmeligheter via navn i teamets passordbehandler / Key Vault.

## Endringsvinduer & Produksjon
* Sjekk alltid `engagement.md` for kundens definerte endringsvindu før produksjonsendringer kjøres eller foreslås.
* Ved usikkerhet, be om eksplisitt godkjenning fra bruker før destruktive kommandoer foreslås eller eksekveres.

## Deling & Tilgang (SharePoint/OneDrive)
* Del dette workspacet kun med personer som faktisk skal jobbe på casen (redigeringstilgang,
  ikke bredere enn nødvendig).
* Se `KOM-I-GANG.md` for forutsetninger og do's/don'ts ved samhandling mellom flere brukere i
  samme workspace, og Del E der for hvordan tilpasse SharePoint-rettigheter mappe for mappe —
  spesielt for strukturfiler og kildemateriell som `Customers request/` og `Meeting notes/`.

## Kommersielle forpliktelser
* Ikke fremstill pris, tidslinje, bemanning eller andre kommersielle detaljer som avklart eller
  bindende før bruker eksplisitt har bekreftet dem. Ved usikkerhet, spør før det skrives inn i
  et kundevendt dokument.
