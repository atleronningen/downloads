# Kom i gang med dette case-workspacet

Dette er et Managed Services case-workspace satt opp fra `msp-template`. Det ligger på et
SharePoint-område, synkes lokalt via OneDrive, og åpnes/jobbes i via Claude Cowork.

Setter du opp casen for aller første gang, og oppretter selv SharePoint-mappen? Gå til
**Del A0** rett under. Kobler du deg på et workspace **noen andre allerede har satt opp** —
typisk fordi du er et medlem av bid-teamet (bid-manager, presale-arkitekt, fagekspert) som
blir koblet på en pågående case? Gå rett til **Del A**.

Se `reference/multi-user-workflow.svg` for et diagram av hvordan de delte filene
(STATUS/ACTIVITY/changelog/memory) flyter mellom flere samtidige økter — nyttig som
supplement til Del C og Del D under.

## Del A0 — Setter du opp en helt ny case?

1. Gå til SharePoint-området, opprett en mappe der delt AI-arbeid skal foregå (f.eks.
   «AI-workspace»), trykk «...» og velg «Sync» for å koble den til din lokale OneDrive.
2. Gå til OneDrive-synkmappen i filsystemet, og pakk ut `msp-template`-malen der.
3. Monter den samme OneDrive-mappen som arbeidsområde i Claude Cowork, og skriv «Ny case satt
   opp for første gang». Claude spør om kundenavn og casenavn, og fyller ut
   `admin/engagement.md`, `admin/rules.md`, `STATUS.md` og `admin/memory.md` selv (se
   `CLAUDE.md` §1).

Gå deretter videre til Del B og Del C under — de gjelder uansett om du satte opp casen selv
eller kobler deg på en som allerede finnes.

## Del A — Tilkobling

1. Gå til SharePoint-området hvor mappen for delt AI-arbeid ligger, trykk «...» og velg
   «Sync» for å koble den til din lokale OneDrive.
2. Gå til OneDrive-synkmappen i filsystemet, og vent til mappen viser en grønn hake før du
   åpner den. Å begynne å jobbe i en mappe som fortsatt synker kan gi ufullstendige filer.
3. Monter den samme OneDrive-mappen som arbeidsområde i Claude Cowork, og skriv «Gi meg status
   og les de siste changelogene.»

## Del B — Forutsetninger for at teamet skal kunne samhandle

- Alle bid-team-medlemmer må ha **redigeringstilgang** (ikke bare visning) på SharePoint-området.
- Alle må ha OneDrive koblet til riktig organisasjonskonto, med aktiv synk av denne mappen.
- Alle må ha Claude Cowork med mulighet til å mounte OneDrive-synkede mapper som workspace.
- Alle bør ha `sopra-steria-korrektur` installert som global skill (fra Sopra Steria sin AI
  Agent Marketplace) for automatisk korrektur av norsk tekst. Er den ikke installert, kan
  drafting fortsatt gjøres i chatten, men den automatiske korrekturen uteblir.

## Del C — Do's

- **Skriv en changelog-oppføring ved slutten av hver sesjon**, selv korte økter. Dette er
  hovedmekanismen for å koordinere når flere jobber parallelt — filnavn med dato+initialer
  unngår kollisjon naturlig. Bruk `.claude/skills/create-changelog.sh <initialer>`.
- **Jobb per-krav/per-seksjon der det er mulig** (matcher `rfi-response-drafter`s
  per-krav-utkast-flyt) — reduserer sjansen for at to personer redigerer samme fil samtidig.
- **Sjekk `STATUS.md` og de siste changeloggene før hver sesjon**, ikke bare når du kobler deg
  på for første gang.
- **Sjekk sist endret-tidspunkt på `STATUS.md` og `admin/ACTIVITY.md` før du starter en økt**, og si
  ifra i teamet dersom dere jobber i casen samtidig — filene låses ikke automatisk, og
  samtidige lagringer kan kollidere (se Del D).
- **La kun én person regenerere selve Word-dokumentet om gangen**, og noter i changelog når det
  gjøres, slik at ingen andre gjør det samtidig.

## Del D — Don'ts

- **Ikke rediger `STATUS.md`, `admin/ACTIVITY.md`, `admin/engagement.md` eller `admin/rules.md`
  samtidig som noen andre.** Disse er delte enkeltfiler uten sanntids-samskriving slik Word
  har — to samtidige Claude-sesjoner som lagrer disse filene kan overskrive hverandres
  endringer. Ved tvil: bid-manager eier disse filene, andre foreslår endringer via changelog
  eller direkte dialog.
- **Ikke rediger `.claude/`-innhold** (agents/skills/rules) midt i et bid uten å varsle teamet
  — det påvirker alles Claude-sesjoner umiddelbart.
- **Ikke rediger Word-malen direkte i Word samtidig som en Claude-sesjon regenererer den.**
  Velg én kanal om gangen, og si ifra i changelog hvilken.
- **Se opp for OneDrive-konfliktfiler**, gjenkjennes på navn som
  `<filnavn> (Konflikterende kopi fra <navn> <dato>).md` — dette betyr at to lagringer kolliderte.
  Noen må manuelt slå sammen innholdet og slette duplikatet; ikke la konfliktfiler ligge.

## Del E — Tilgangsstyring i SharePoint (for den som setter opp casen)

Den som oppretter SharePoint-mappen (Del A0), typisk bid-manager, er som regel eier av
tilgangene der, og bør aktivt tilpasse dem — ikke bare stole på det som arves fra et
overordnet Team-område. Åpne mappen i SharePoint, trykk «...» → «Manage access» for å se
både navngitte personer («People») og grupper som arver tilgang fra et overordnet område
(«Groups»), f.eks. en hel kontoteam-gruppe med «Can view». Dette gjelder for hele
arbeidsområdet, men også for hver undermappe eller fil for seg — bruk samme «Manage
access»-dialog på en enkelt undermappe for å bryte arvingen og sette strengere regler enn
resten av arbeidsområdet, der det trengs.

**Hvorfor det er viktig å begrense tilgangen:**
- `admin/` (`engagement.md`, `rules.md`, `memory.md`, `ACTIVITY.md`) og `.claude/`-mappen
  styrer hvordan Claude oppfører seg og hva som regnes som casens historikk for alle som
  jobber i den. Do's/don'ts i Del C/D over er konvensjon, ikke en sperre — de hindrer ikke at
  noen uten kontekst for casen, f.eks. via en bred arvet gruppe, redigerer disse filene ved et
  uhell og endrer oppførselen stille for hele bid-teamet. Fordi disse fire filene ligger samlet
  i én mappe, holder det å bryte arvingen på `admin/` én gang, i stedet for å gjøre det fil for
  fil.
- `CLAUDE.md` og `STATUS.md` blir stående i roten (Claude Code laster `CLAUDE.md` automatisk
  derfra, og `STATUS.md` er ment som lett tilgjengelig «les dette først»). Vurder likevel om
  hele rotnivået bør ha redigeringstilgang begrenset til kjerneteamet, siden `CLAUDE.md`
  fortsatt styrer Claudes oppførsel direkte.
- `Customers request/` og `Meeting notes/` inneholder kildemateriell: kundens egen
  forespørsel (RFI/RFP/ITT), briefer og møtereferater. Dette er ofte konfidensielt i en
  anbudsprosess, og skal stå som mottatt — ingen bør redigere eller «forbedre» kundens
  originale dokumenter i ettertid, og materialet bør ikke deles bredere enn bid-teamet som
  faktisk jobber i casen.

**Anbefalt tilgang, mappe for mappe:**

| Mappe/fil | Anbefalt tilgang | Begrunnelse |
|---|---|---|
| `admin/` | Redigering kun for de som faktisk jobber i casen — bryt arving på denne ene mappen | Styrer casens historikk (engagement, regler, minne, aktivitetslogg) |
| `.claude/` | Redigering kun for de som faktisk jobber i casen | Styrer Claudes oppførsel for alle |
| `CLAUDE.md`, `STATUS.md` (rot) | Vurder samme innstramming som `admin/` | Styrer Claudes oppførsel / casens status, må ligge i roten |
| `Customers request/`, `Meeting notes/` | Vurder å bryte arving og sette snevrere tilgang enn resten (f.eks. kun kjerneteamet, evt. visning for øvrige) | Kildemateriell / audit-spor, ofte konfidensielt i en anbudsprosess |
| Leveranse (`.docx`), `reference/` | Kan følge samme tilgang som resten av bid-teamet | Ment å redigeres av de som drafter |

- Del aldri arbeidsområdet bredere enn bid-teamet som faktisk jobber i casen trenger, med
  redigeringstilgang — ikke bredere enn nødvendig (se `.claude/rules/safety-rules.md`).
- Sjekk «Groups»-fanen spesielt: en arvet gruppe fra et overordnet Team-område (f.eks.
  «... Visitors» eller «... Members») kan gi tilgang til langt flere enn de som faktisk er i
  casen, uten at det er tydelig ved første øyekast.
