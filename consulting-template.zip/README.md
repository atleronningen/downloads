# Consulting Engagement Workspace (mal)

<!-- MAL-START -->
Dette er `consulting-template`: malen ethvert nytt kundeoppdrag kopieres fra. Mappen
representerer ikke ett oppdrag i seg selv. Den er utgangspunktet du kopierer til et nytt
SharePoint-område per kunde/case. Legg aldri casespesifikt innhold her: kopier mappen til et
nytt SharePoint-område først (`KOM-I-GANG.md`, Del A0).

Zip-fila du deler malen med lages med `python3 .claude/scripts/pakk-mal.py <sti-til-zip>`.
Skriptet utelater macOS- og OneDrive-filer og legger zip-fila utenfor malmappa. Versjon og
endringer i malen står i `.claude/MALENDRINGER.md`.
<!-- MAL-SLUTT -->

Se `KOM-I-GANG.md` for hvordan du kobler deg til oppdraget via SharePoint/OneDrive og Claude
Cowork, og for do's/don'ts ved samhandling med andre i teamet.

## Start her

<!-- MAL-START -->
- **Setter du opp et nytt oppdrag fra denne malen?** Gå til `KOM-I-GANG.md`, Del A0.
<!-- MAL-SLUTT -->
- **Vil du se flyten, hvor du er nå og hva neste steg er?** Åpne `ARBEIDSFLYT.svg`. Den bygges
  av et skript og er alltid à jour med mappa (`CLAUDE.md` §8).
- **Kobler du deg på et oppdrag noen andre allerede har satt opp?** Gå til `KOM-I-GANG.md`, Del A.
- **Jobber du i en case som allerede er i gang?** Les `STATUS.md`, deretter `admin/ACTIVITY.md`.
- **Skal du skrive noe kunden får?** Les `CLAUDE.md` §4, om `our-approach`-skillen, formelle
  RFI/RFP-svar og review-porten.

## Hva som står hvor

`CLAUDE.md` er den normative kilden for arbeidsflaten: mappestruktur og rot-regel, sesjonsrutiner,
kildehierarki, review-port, tidsregler og arbeidsregler. Denne fila gjentar ingen av dem. Hver
regel har en kontroll i `.claude/checks.md`.

| Fil | Hva det er |
|---|---|
| `CLAUDE.md` | Reglene for arbeidsflaten. Leses av Claude ved øktstart, og av deg når du lurer på hvordan mappa er ment å fungere. |
| `KOM-I-GANG.md` | Onboarding for mennesker: SharePoint/OneDrive, Cowork, forutsetninger for samarbeid, do's og don'ts. Eier reglene for samtidig redigering (Del D). |
| `STATUS.md` | Nåsituasjonen i casen. Les denne først. |
| `ARBEIDSFLYT.svg` | Flyten fra oppsett til eksport, hvor du er nå, øktrutinen, strukturen og skillene. Byggeartefakt: rediger aldri for hånd. |

Struktur og formål for alle øvrige filer og mapper står under «Mappestruktur» i `CLAUDE.md`.
