# Consulting Engagement Workspace (mal)

<!-- MAL-START -->
Dette er `consulting-template`: malen ethvert nytt kundeoppdrag kopieres fra. Mappen
representerer ikke ett oppdrag i seg selv. Legg aldri casespesifikt innhold her: kopier mappen
til et nytt SharePoint-område først (`KOM-I-GANG.md`, Del A0).

Zip-fila du deler malen med lages med `python3 .claude/scripts/pakk-mal.py <sti-til-zip>`.
Versjon, endringer og vedlikeholdsrytme for malen står i `.claude/MALENDRINGER.md`.
<!-- MAL-SLUTT -->

## Start her

- **Claude:** les `CLAUDE.md` §1 og følg den.
- **Menneske:** les `STATUS.md`, deretter `KOM-I-GANG.md` hvis du er ny i casen eller setter
  opp et nytt oppdrag.

`CLAUDE.md` er den normative kilden for arbeidsflaten. Struktur og formål for alle filer og
mapper står under «Mappestruktur» der.
