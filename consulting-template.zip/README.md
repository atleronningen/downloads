# Consulting Engagement Workspace — mal

Dette er `consulting-template`: malen ethvert nytt kundeoppdrag kopieres fra. Mappen
representerer ikke ett oppdrag i seg selv — den er utgangspunktet du kopierer til et nytt
SharePoint-område per kunde/case. Se `KOM-I-GANG.md` for hvordan du kobler et nytt eller
eksisterende oppdrag til Claude Cowork, og for do's/don'ts ved samhandling med andre i teamet.

## Start her

- **Setter du opp et nytt oppdrag fra denne malen?** Gå til `KOM-I-GANG.md`, Del A0.
- **Kobler du deg på et oppdrag noen andre allerede har satt opp?** Gå til `KOM-I-GANG.md`, Del A.
- **Jobber du i en case som allerede er i gang?** Les `STATUS.md`, deretter `ACTIVITY.md`, i den
  kopierte case-mappen (malen selv har ingen case-status å lese).
- **Skal du skrive noe kunden får?** Les `CLAUDE.md`, avsnitt 5 — om `our-approach`-skillen,
  formelle RFI/RFP-svar, og review-porten (Customer Value + Writing Style).

## Hvordan filene henger sammen

| Fil/mappe | Hva det er |
|---|---|
| `CLAUDE.md` | Instruksjoner til Claude: oppsett, sesjonsrutiner, hvordan man jobber med oppdrag. Leses av Claude ved øktstart, ikke ment som førstelesning for mennesker. |
| `KOM-I-GANG.md` | Onboarding for mennesker: hvordan koble til SharePoint/OneDrive og Cowork, forutsetninger for samarbeid i team, do's og don'ts. |
| `engagement.md` | Kundetilpasning: fase, leveransemodell, utfordring, mål, scope, frist, kontakter. Fylles ut ved oppsett (`CLAUDE.md` §1). |
| `rules.md` | Kundespesifikke regler og begrensninger, lagt til etter hvert som de oppstår. |
| `STATUS.md` | Nåsituasjonen i casen: oppsummering, scope/beslutninger, åpne spørsmål, hvordan gjenoppta arbeidet. |
| `ACTIVITY.md` | Løpende logg over betydelige endringer (omfang, metode, retning, leveranse). Skrives aldri om eller ryddes opp i. |
| `memory.md` | Case-scoped arbeidsminne: gjenbrukbar kunnskap mens denne casen pågår (posisjonering, leveransemodell-valg, læring) — ikke case-fremdrift. |
| `Sopra Steria template.docx` | Word-mal for leveransen. Får et beskrivende filnavn ved oppsett. |
| `Customers request/` | Dropbox for kundens eget materiale (RFI/RFP/ITT, briefing, synopsis). |
| `Meeting notes/` | Løpende møtenotater, ett filnavn per møte med ISO-datoprefiks, f.eks. `2026-08-06_kickoff.md`. |
| `changelog/` | Én loggfil per økt, opprettet med `.claude/skills/create-changelog.sh <initialer>`. |
| `reference/` | Global kontekst arvet fra malen: beste praksis, posisjoneringsregler, diagram av multi-bruker-flyten. |
| `.claude/` | Reviewere (Customer Value, Writing Style), skriveregler og `our-approach`-skillen. Endres sjelden, og aldri midt i et oppdrag uten å varsle teamet. |

## Regler som gjelder overalt

- Denne mappen er malen, ikke et oppdrag. Legg aldri casespesifikt innhold her — kopier mappen
  til et nytt SharePoint-område først (`KOM-I-GANG.md`, Del A0).
- I en kopiert case-mappe holdes roten til filene i tabellen over pluss de fire mappene under
  den. Ingen ad-hoc-filer i roten.
- `STATUS.md`, `ACTIVITY.md`, `engagement.md` og `rules.md` redigeres av én person om gangen —
  se `KOM-I-GANG.md`, Del D.
- Betydelige endringer logges i `ACTIVITY.md` i det øyeblikket de skjer, ikke bare ved
  øktslutt.
- Kundevendt innhold går gjennom `customer-value-reviewer` og `writing-style-reviewer` før
  brukeren spørres om godkjenning.
