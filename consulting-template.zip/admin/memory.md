# Memory – <kundenavn> / <casenavn>

Working memory for denne casen: gjenbrukbar kunnskap som er relevant mens denne casen pågår.
Case-fremdrift (hva som er sendt, hva som er åpent, hva som gjenstår) hører hjemme i
`STATUS.md`, ikke her.

**Denne filen er case-scoped, ikke delt med andre caser.** Den er arbeidsminne for dette
oppdraget så lenge det pågår.

## Posisjoneringsbeslutninger

Avgjørelser om hvor konkret man har navngitt merkede produkter/tjenester i denne leveransen, og
hvorfor. Se `reference/positioning-rules.md` for beslutningsrammen.

## Leveransemodell-valg

Hvilken leveransemodell (rådgivning/prosjekt/workshop-serie/retainer/kombinert/T&M) som ble
valgt for denne casen, og hva som talte for/mot underveis.

## Vinnertemaer

Budskap og argumenter som har truffet denne kunden, med en kort begrunnelse.
Reviewen av kundeverdi sjekker at hvert tema er tilpasset kundens situasjon når det brukes på
nytt.

## Prosesslæring

Læring om selve tilbudsprosessen, ikke om kunden.

## Kundefakta verdt å huske

Varige fakta om kunden (ikke case-status) som er verdt å vite ved et fremtidig oppdrag.
