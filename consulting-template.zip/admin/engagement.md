# Engagement: <kundenavn> – <casenavn>

## Utfordring
* <Kundens kjerneproblem/situasjon, 2–3 setninger>

## Mål med leveransen
* <Hva suksess ser ut som for kunden>

## Scope
* <Hva er inn / hva er ut av oppdraget>
* **Leveransemodell:** <Rådgivning / Prosjekt / Workshop-serie / Retainer / Kombinert / Tid og Materiell>

## Frist
* <Tilbudsfrist, hvis formell RFI/RFP/ITT – fylles inn når kundens dokument er mottatt>

## Hovedkontakter
| Rolle | Navn | Kontaktinfo |
|---|---|---|
| Teknisk/innkjøpskontakt (kunde) | <Navn> | <e-post> |
| Beslutningstaker (kunde) | <Navn> | <e-post> |
| Ansvarlig konsulent (oss) | <Navn> | <e-post> |
