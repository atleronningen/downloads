# Engagement: <kundenavn> – <casenavn>

## Status
* **Fase:** Discovery / tilbudsarbeid, ingen signert avtale.
* **Leveransemodell:** <Rådgivning / Prosjekt / Workshop-serie / Retainer / Kombinert / Tid og Materiell>

## Utfordring
* <Kundens kjerneproblem/situasjon, 2–3 setninger>

## Mål med leveransen
* <Hva suksess ser ut som for kunden>

## Scope
* <Hva er inn / hva er ut av oppdraget>

## Frist
* <Tilbudsfrist, hvis formell RFI/RFP/ITT – fylles inn når kundens dokument er mottatt>

## Hovedkontakter
| Rolle | Navn | Kontaktinfo |
|---|---|---|
| Teknisk/innkjøpskontakt (kunde) | <Navn> | <e-post> |
| Beslutningstaker (kunde) | <Navn> | <e-post> |
| Ansvarlig konsulent (oss) | <Navn> | <e-post> |
