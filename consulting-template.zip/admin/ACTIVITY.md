# ACTIVITY.md

Regler for hva som logges her og når står i `CLAUDE.md` §4. Denne fila beskriver bare formatet.

Nyeste oppføring øverst. Filen er en løpende logg og skal ikke ryddes opp i eller skrives om.
Klokkeslettet i oppføringen hentes med kommandoen i `CLAUDE.md` §6, aldri anslått.

Format:

```
[YYYY-MM-DD HH:MM | Initialer]
Endring:
Årsak:
Berørte filer:
```

Flere personer involvert i samme beslutning skilles med `+`, f.eks. `AR + MH`.

---

(ingen oppføringer ennå)
