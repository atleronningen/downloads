# STATUS: <casenavn>

_Sist oppdatert: YYYY-MM-DD av <initialer>_

## Oppsummering
<Kort beskrivelse av forespørselen/casen>

## Scope og beslutninger
-

## Åpne spørsmål
-

## Hvordan gjenoppta arbeidet
<Hva neste konsulent/økt bør gjøre først>
