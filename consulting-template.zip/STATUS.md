# STATUS: <casenavn>

_Sist oppdatert: YYYY-MM-DD av <initialer>_

Scope står i `admin/engagement.md`, beslutninger i `admin/ACTIVITY.md`, krav i
Leveranser/kravmatrise.md.

## Oppsummering
<Kort beskrivelse av forespørselen/casen, med kundens frist>

## Siden sist
-

## Åpne spørsmål
-

## Hvordan gjenoppta arbeidet
<Hva neste konsulent/økt bør gjøre først>
