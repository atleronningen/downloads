# CLAUDE.md - Consulting Engagement Workspace

Dette workspacet er malbasert (kopiert fra `consulting-template`) og representerer ÉTT
kundeoppdrag — ikke et delt repo med flere kunder. Se `KOM-I-GANG.md` for hvordan du kobler deg
til dette workspacet via SharePoint/OneDrive og Claude Cowork, og for do's/don'ts ved samhandling
med andre i teamet.

## 1. Førstegangsoppsett

Hvis brukerens første melding i en fersk sesjon uttrykker at oppdraget nettopp er satt opp
(f.eks. "Nytt oppdrag satt opp for første gang", eller lignende — tolk intensjonen, ikke krev en
eksakt frase), gjør følgende før noe annet:

1. Spør om **kundenavn** og **casenavn**.
2. Fyll ut placeholders i `engagement.md` (fase/leveransemodell/utfordring/mål/scope/frist/
   kontakter), `rules.md`, `STATUS.md` og tittelen i `memory.md` med det du får oppgitt — ikke
   gjett på informasjon du ikke har fått.
3. Gi Word-filen (`Sopra Steria template.docx`) et beskrivende filnavn ved å endre selve
   filnavnet (ikke SharePoint sin visningsnavn-metadata), f.eks. `<Kunde> - <Case>.docx`.
4. Opprett mappene `Customers request/`, `Meeting notes/` og `changelog/` dersom de ikke
   finnes fra før. De kan stå tomme; de fylles etter hvert som oppdraget krever det.
5. Gå videre til normal sesjonsstart (punkt 2 under) med de nå utfylte filene.

## 2. Normal sesjonsstart

Når oppdraget allerede er satt opp fra før:

1. Les `reference/best-practices.md` (global kontekst arvet fra malen).
2. Les `engagement.md` (kundetilpasning, scope & frister) og `rules.md` (kundespesifikke
   instrukser/begrensninger).
3. Les `STATUS.md` (nåværende status for casen).
4. Les `ACTIVITY.md` (betydelige beslutninger denne casen: endret omfang, metode, retning
   eller leveranse — se `.claude/rules/memory-protocol.md`).
5. Les de 2 seneste loggene under `changelog/`.
6. Les root-`memory.md` (case-scoped læring samlet så langt).
7. Oppsummer kort status og vent på instrukser.

## 3. Avslutningsrutine

Når økten avsluttes (eller bruker sier "avslutt økt" / "oppdater status"):

1. Følg retningslinjene i `.claude/rules/memory-protocol.md` nøye.
2. Har noe i økten endret omfang, metode, retning eller leveranse: legg det til i
   `ACTIVITY.md` i det øyeblikket det skjer, ikke bare samlet ved avslutning.
3. Opprett ny øktslogg i `changelog/` — bruk `.claude/skills/create-changelog.sh <initialer>`.
4. Oppdater `STATUS.md` dersom fremdrift, åpne spørsmål eller beslutninger er endret.

## 4. Retningslinjer & Sikkerhet

* Se `.claude/rules/safety-rules.md` for regler vedrørende hemmeligheter, kommersielle
  forpliktelser og deling/tilgang.

## 5. Hvordan jobbe med oppdrag

* **our-approach** (i `.claude/skills/`) — samtalebasert arbeidsflyt for å bygge et
  consulting-tilbud: discovery (kunde/utfordring/mål/scope/leveransemodell) → tilnærming
  (fasedeling) → slide-for-slide utkast i chatten, helt frem til eksport. Trigges automatisk når
  bruker ber om et tilbud/en tilnærming, selv uten den eksakte frasen.

* **Formelle RFI/RFP/ITT-svar** — driftes av kundens eget dokument, ikke en skill-ledet samtale.
  Sett opp casemappen (se struktur under), lagre kundens dokument under `Customers request/`,
  logg frist og åpne spørsmål i `STATUS.md`, og utform deretter de konkrete leveransene kundens
  dokument ber om, i det formatet kunden krever. Bruk `our-approach`-flytens prinsipper
  (discovery-oppsummering, slide/seksjon-for-seksjon-arbeid) som arbeidsmåte selv om
  outputformatet er kundens eget skjema, ikke en presentasjon.

* **Posisjonering:** Før du avgjør hvor konkret du navngir spesifikke merkede produkter/
  tjenester i en leveranse, les `reference/positioning-rules.md`.

* **Customer Value review:** Før et kundevendt dokument genereres endelig, kjør
  `customer-value-reviewer`-agenten og vis funnene til brukeren før godkjenning bes om.

* **Writing Style review:** Samtidig med Customer Value review, kjør
  `writing-style-reviewer`-agenten på samme innhold og vis funnene til brukeren før
  godkjenning bes om.

* **Skrivestil:** Les `.claude/rules/writing-style.md` (og `.claude/customer-value/writing-style-core.md`
  den peker til) før kundevendt innhold skrives, og etterlev reglene der uten å bli minnet på det.

* **memory.md:** Les root-`memory.md` før drafting starter på dette oppdraget
  (posisjoneringsbeslutninger, leveransemodell-valg som kan gjenbrukes så langt i casen).
  Oppdater den løpende med kunnskap som har overføringsverdi — ikke case-fremdrift (den hører
  hjemme i `STATUS.md`).

* **STATUS.md:** Holder løpende status for casen — oppsummering, scope/beslutninger, åpne
  spørsmål, og hvordan gjenoppta arbeidet. Oppdater den gjennom hele arbeidet med casen, ikke
  bare ved avslutning.

* **ACTIVITY.md:** Løpende, aldri omskrevet logg over betydelige beslutninger i casen — endret
  omfang, metode, retning eller leveranse. Skiller seg fra `STATUS.md` ved at den aldri
  overskrives eller ryddes; den er casens historikk, ikke dens øyeblikksbilde. Se
  `.claude/rules/memory-protocol.md` for format og skille mot `STATUS.md`.

## Mappestruktur

```
<Kunde> - <Case>/
  CLAUDE.md
  STATUS.md
  ACTIVITY.md
  engagement.md
  memory.md
  rules.md
  Sopra Steria template.docx  (eller <Kunde> - <Case>.docx etter oppsett)
  Customers request/
  Meeting notes/
  changelog/
  reference/
  .claude/
```

`Customers request/` er dropbox for kundens eget materiale (RFI/RFP/ITT, briefing, synopsis).
`Meeting notes/` er løpende møtenotater, ett filnavn per møte med ISO-datoprefiks
(f.eks. `2026-08-06_kickoff.md`), slik at de sorterer kronologisk. Destiller beslutninger og
resonnement som betyr noe inn i `STATUS.md`, i stedet for at de blir liggende begravd i et
møtenotat.
