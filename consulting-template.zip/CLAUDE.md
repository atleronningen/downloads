# CLAUDE.md - Consulting Engagement Workspace

Dette workspacet er malbasert (kopiert fra `consulting-template`) og representerer ÉTT
kundeoppdrag, ikke et delt repo med flere kunder. Se `KOM-I-GANG.md` for hvordan du kobler deg
til dette workspacet via SharePoint/OneDrive og Claude Cowork, for førstegangsoppsett (Del A0),
og for do's/don'ts ved samhandling med andre i teamet.

## 0. Denne filas status

Denne fila er **normativ** for arbeidsflaten. Den eier mappestrukturen og rot-regelen
(«Mappestruktur» nederst), sesjonsrutinene (§1, §2), arbeidsmåten og review-porten (§4),
kildehierarkiet (§5), tidsregelen (§6) og arbeidsreglene (§7). `KOM-I-GANG.md` eier
samhandlingsreglene for flere brukere og førstegangsoppsettet.

Står noe i en annen fil som motsier denne fila, gjelder denne fila, og motsigelsen rettes i den
andre fila samme økt. Kontrollkommandoene står i `.claude/checks.md`, en per C-id.

Malversjon: 1.3. Endringer i selve malen står i `.claude/MALENDRINGER.md`. En case-kopi
beholder versjonsnummeret den ble kopiert fra.

**Tak:** `CLAUDE.md` holdes under 2 000 ord. Instruksjonslaget (alle .md-filer i roten, under
`admin/`, `reference/` og `.claude/`) holdes under 12 000 ord. Skal noe inn over taket, går noe
ut først, og begge deler står i samme oppføring i `.claude/MALENDRINGER.md`. Kontroll: C21.

## 1. Sesjonsstart

1. Inneholder `STATUS.md` fortsatt `<casenavn>`, følg oppsettet i `KOM-I-GANG.md` Del A0 før
   noe annet.
2. Les `STATUS.md`, den nyeste fila under `changelog/`, `admin/engagement.md` og
   `admin/memory.md`. Er noen tomme eller mangler, si det og fortsett.
3. List `Customer requests/` og `Meeting notes/` etter dato, nyeste først, og si hva som ligger
   der. Er en fil der, eller under `Deliverables/`, nyere enn datoen i `STATUS.md`, meld det før
   noe annet og oppdater STATUS først. Et udestillert møtenotat behandles etter §4 før arbeidet
   fortsetter.
4. Ligger et kundedokument i `Customer requests/` uten at Deliverables/kravmatrise.md finnes
   eller dekker det, meld det og tilby å opprette matrisen etter §4.
5. Oppsummer i fem setninger: hvor casen står, kundens frist, hva kunden sist sa eller ba om,
   hva som er neste steg. Vent på instruks.

Ingen kontroller kjøres ved sesjonsstart.

## 2. Avslutning

Når økta avsluttes, eller bruker sier «avslutt økt»: oppdater `STATUS.md` hvis noe har endret
seg, med dato og initialer. Ble en fil endret eller opprettet i økta, opprett øktslogg med
`.claude/scripts/create-changelog.sh <initialer>` og fyll den ut; ble ingenting endret, skrives
ingen logg. Oppdater Deliverables/kravmatrise.md hvis et krav fikk ny status. Oppdater
`admin/memory.md` bare hvis noe med overføringsverdi kom frem. Ble kundevendt innhold skrevet
eller endret, kjør C8 og C20.

## 3. Retningslinjer & Sikkerhet

Se `.claude/rules/safety-rules.md` for regler om hemmeligheter, kundedata, kommersielle
forpliktelser og deling/tilgang.

## 4. Hvordan jobbe med oppdrag

**Aktivt under drafting.** Rett før noe kundevendt skrives eller vurderes, ikke ved
sesjonsstart, leses disse filene: kundens dokument i `Customer requests/` i sin helhet,
`admin/engagement.md`, `admin/rules.md`, `admin/memory.md`,
`.claude/customer-value/writing-style-core.md`, `reference/positioning-rules.md`,
`reference/best-practices.md` og `.claude/skills/our-approach/SKILL.md`. Ingen andre. Er det
gått mer enn 30 meldinger siden de ble lest, leses de på nytt før neste kundevendte tekst.
Summen av disse filene (uten kundens dokument) holdes under 3 000 ord og under 30 konkrete
regler.

**our-approach** (i `.claude/skills/`): samtalebasert arbeidsflyt for å bygge et
consulting-tilbud: discovery (kunde/utfordring/mål/scope/leveransemodell), tilnærming
(fasedeling), slide-for-slide utkast i chatten, helt frem til eksport. Trigges når bruker ber
om et tilbud eller en tilnærming, også uten den eksakte frasen. Skillen skriver den bekreftede
discovery-oppsummeringen til `admin/engagement.md`.

**Formelle RFI/RFP/ITT-svar** driftes av kundens eget dokument, ikke en skill-ledet samtale.
Lagre kundens dokument under `Customer requests/`, opprett kravmatrisen (under), logg frist og
åpne spørsmål i `STATUS.md`, og utform deretter leveransene kundens dokument ber om, i det
formatet kunden krever. Bruk `our-approach`-flytens prinsipper (discovery-oppsummering,
seksjon-for-seksjon-arbeid) som arbeidsmåte selv om outputformatet er kundens eget skjema.

**Kravmatrise:** Når et kundedokument med krav legges i `Customer requests/`, opprettes
Deliverables/kravmatrise.md i samme økt fra `reference/kravmatrise-mal.md`, ett krav per rad,
med kundens ordlyd uendret. Matrisen er sporingen mellom det kunden ba om og det vi svarer, og
oppdateres hver gang et svar skrives eller endres. Antall rader telles med kommando og
sammenlignes med antall krav bruker bekrefter i kundens dokument; stemmer ikke tallene, rettes
matrisen før noe svar skrives.

**Posisjonering:** Før du avgjør hvor konkret du navngir merkede produkter/tjenester i en
leveranse, les `reference/positioning-rules.md`.

**Review-porten:** Før et kundevendt dokument genereres endelig, kjør `customer-value-reviewer`
og `writing-style-reviewer` på samme innhold, og `compliance-reviewer` når
Deliverables/kravmatrise.md finnes. Vis funnene til brukeren før godkjenning bes om eller eksport
tilbys. «Kjør» betyr: les agentfilen under `.claude/agents/` og sjekklisten den peker til, og
følg den nøyaktig, som isolert subagent der verktøyet har det. Sjekk om et Agent- eller
Task-verktøy finnes før du faller tilbake på å gjøre reviewen selv i denne økten. Uten subagent
er reviewen svakere, fordi samme kontekst skrev og vurderer; si det til bruker. Reviewerne
leser bare ferdig tekst, aldri chatten. Dette er den eneste beskrivelsen av review-porten i
arbeidsflaten. Kontroll: C9.

**Skrivestil:** `.claude/customer-value/writing-style-core.md` eier alle skriveregler og
ordlisten. Ingen annen fil har egne stilregler. Tankestrekregelen kontrolleres mekanisk.
Kontroll: C20.

**Møtenotater:** Når et notat legges i `Meeting notes/`, destilleres det i samme økt:
beslutninger til `admin/ACTIVITY.md`, varige kundefakta og kundens egne ord til
`admin/memory.md`, endret frist eller scope til `admin/engagement.md`, neste steg til
`STATUS.md`. Notatet selv står uendret. Et notat som ikke er destillert, fanges av §1 steg 3.

**memory.md:** Gjenbrukbar kunnskap fra casen: posisjoneringsbeslutninger, leveransemodell,
vinnertemaer, kundens begreper. Oppdater den med kunnskap som har overføringsverdi, ikke
case-fremdrift (den hører hjemme i `STATUS.md`).

**STATUS.md:** Nåsituasjonen: oppsummering, siden sist, åpne spørsmål, hvordan gjenoppta.
Oppdater den gjennom hele arbeidet, ikke bare ved avslutning. Den er et øyeblikksbilde og
skrives om fritt. Scope står i `admin/engagement.md`, beslutninger i `admin/ACTIVITY.md`.

**ACTIVITY.md:** Løpende logg over betydelige beslutninger: endret omfang, metode, vinkling,
leveranseformat, droppet eller lagt til krav. Ny oppføring skrives i det øyeblikket beslutningen
tas. Nyeste øverst, fila skrives aldri om. Formatet står øverst i fila. Klokkeslettet hentes
etter §6.

## 5. Kildehierarki

Når to filer sier ulike ting om samme sak, avgjør hva spørsmålet gjelder:

| Spørsmålet gjelder | Autoritativ kilde | Alt annet er |
|---|---|---|
| Hva kunden faktisk har bedt om | `Customer requests/` | vår tolkning |
| Hvilke krav kunden stilte, og status på svar | Deliverables/kravmatrise.md | vår lesning |
| Hva som er besluttet, og når | `admin/ACTIVITY.md` | referat av beslutningen |
| Hvor casen står nå | `STATUS.md` | utdatert |
| Scope, frist, kontakter | `admin/engagement.md` | referat |
| Hva som ble sagt i et møte | `Meeting notes/` | destillat |
| Hvordan vi arbeider i mappa | `CLAUDE.md` | peker hit |

`admin/memory.md` er gjenbrukbar kunnskap og er ikke autoritativ på noe av det over. Er to
kilder innenfor samme rad uenige, gjelder den med nyeste dato i innholdet, og uenigheten logges
i `admin/ACTIVITY.md`.

## 6. Tid

Skallet kjører UTC. Loggene kjører Europe/Oslo. **Tidsstempler hentes, aldri anslås.**
Klokkeslett i `admin/ACTIVITY.md` og dato i `STATUS.md` hentes fra
`TZ=Europe/Oslo date "+%Y-%m-%d %H:%M"`, kjørt i samme kommando som oppføringen skrives.
`.claude/scripts/create-changelog.sh` gjør dette selv.

## 7. Arbeidsregler

**Ingen placeholders.** Ingen malrester i en fil som er tatt i bruk. Mangler innholdet, spør
bruker. Gjelder kopier av malen, ikke malen selv. Kontroll: C8.

**En bryter per innstilling.** En regel står ett sted. Alle andre steder peker dit med en
setning. Kontroll: C9.

**Status står i innhold, ikke i filnavn.** Status settes i frontmatter, i `STATUS.md` eller i
mappas egen README dersom fila må kunne limes inn ordrett.

**Ingen backup-filer.** SharePoint og OneDrive holder versjonshistorikk; lokale kopier før
redigering lages ikke. OneDrive-konfliktfiler fanges av C2 og håndteres etter `KOM-I-GANG.md`
Del D.

**Få prosjektskills.** `.claude/skills/` inneholder bare skills. Skript ligger i
`.claude/scripts/`. Finnes en skill på kontoen, brukes den derfra og kopieres aldri hit.

**Ingen døde referanser.** En fil eller mappe som nevnes med bakflått skal finnes. En fil som
opprettes per case (som Deliverables/kravmatrise.md) skrives uten bakflått. Kontroll: C17.

## Mappestruktur

Dette er den eneste beskrivelsen av strukturen i arbeidsflaten. Roten inneholder nøyaktig
dette og ingenting annet:

```
<Kunde> - <Case>/
  CLAUDE.md                     normativ kilde, denne fila
  README.md                     menneskelig inngang, peker hit
  KOM-I-GANG.md                 onboarding, førstegangsoppsett, samhandling, tilgang
  STATUS.md                     nåsituasjon
  admin/                        engagement, rules, memory, ACTIVITY
    engagement.md
    rules.md
    memory.md
    ACTIVITY.md
  Customer requests/            kundens eget materiale, står som mottatt
  Meeting notes/                møtenotater, filnavn YYYY-MM-DD_kort-tittel.md
  changelog/                    en øktslogg per økt, YYYY-MM-DD_HHMM_<initialer>.md
  Deliverables/                 eksporterte leveranser og kravmatrise.md, status i innholdet
  reference/                    metodegrunnlag og maler
    best-practices.md
    positioning-rules.md
    kravmatrise-mal.md
    multi-user-workflow.svg
  .claude/                      reviewere, regler, skills, scripts, checks
```

**Rot-regelen:** ingen andre filer eller mapper i roten. Trenger arbeidet et nytt sted å legge
noe, legges det i en eksisterende mappe, eller strukturen over endres her først. Kontroll: C2.

`admin/` samler filene som styrer casens historikk og Claudes oppførsel. Egnet til å gi
snevrere SharePoint-redigeringstilgang enn resten, se `KOM-I-GANG.md` Del E.

`Customer requests/` er dropbox for kundens eget materiale (RFI/RFP/ITT, briefing, synopsis).
`Meeting notes/` er løpende møtenotater, ett filnavn per møte med ISO-datoprefiks.
`Deliverables/` holder kravmatrisen og de eksporterte filene kunden får, for eksempel .pptx fra
`our-approach`. Filnavnet beskriver leveransen, status står i innholdet eller i `STATUS.md`.
