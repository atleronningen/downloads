# CLAUDE.md - Consulting Engagement Workspace

Dette workspacet er malbasert (kopiert fra `consulting-template`) og representerer ÉTT
kundeoppdrag — ikke et delt repo med flere kunder. Se `KOM-I-GANG.md` for hvordan du kobler deg
til dette workspacet via SharePoint/OneDrive og Claude Cowork, og for do's/don'ts ved samhandling
med andre i teamet.

## 0. Denne filas status

Denne fila er **normativ** for arbeidsflaten. Den eier mappestrukturen og rot-regelen
(«Mappestruktur» nederst), review-porten og arbeidsmåten (§4), kildehierarkiet (§5), tidsreglene
(§6), arbeidsreglene (§7), arbeidsflytskissen (§8) og sesjonsrutinene (§1, §2).

Hver regel har en kontroll med et forventet svar. Kommandoene står i `.claude/checks.md`,
én per C-id. Regelen står her, kommandoen står der, og ingen av dem gjentas i den andre fila.
Kontroll: C18.

Disse filene peker hit og gjentar ingenting med egne ord: `README.md`,
`.claude/checks.md`, `.claude/rules/memory-protocol.md`, `.claude/rules/safety-rules.md`,
`.claude/rules/writing-style.md`, `reference/best-practices.md` og
`reference/positioning-rules.md`. `KOM-I-GANG.md` eier samhandlingsreglene for flere brukere.

Står noe i en av dem som motsier denne fila, gjelder denne fila, og motsigelsen rettes i den
andre fila samme økt.

## Førstegangsoppsett

Gjelder bare i en fersk kopi av malen. Avsnittet slettes fra denne fila når oppsettet er ferdig
(steg 7).

Hvis brukerens første melding i en fersk sesjon uttrykker at oppdraget nettopp er satt opp
(f.eks. "Nytt oppdrag satt opp for første gang", eller lignende — tolk intensjonen, ikke krev en
eksakt frase), gjør følgende før noe annet:

1. Spør om **kundenavn** og **casenavn**.
2. Fyll ut placeholders i `admin/engagement.md` (fase/leveransemodell/utfordring/mål/scope/frist/
   kontakter), `admin/rules.md`, `STATUS.md` og tittelen i `admin/memory.md` med det du får
   oppgitt — ikke gjett på informasjon du ikke har fått.
3. Opprett mappene `admin/`, `Customers request/`, `Meeting notes/` og `changelog/` dersom de
   ikke finnes fra før. De kan stå tomme; de fylles etter hvert som oppdraget krever det.
4. Fjern mal-blokkene i `README.md`: alt fra og med `<!-- MAL-START -->` til og med
   `<!-- MAL-SLUTT -->`, markørene inkludert. Sett tittelen i `README.md` til kunde og case.
5. Kjør C8. Oppsettet er ikke ferdig før kontrollen gir ingen treff. Mangler innholdet, spør
   bruker i stedet for å la en placeholder stå.
6. Bygg `ARBEIDSFLYT.svg` etter §8, slik at skissen viser den nye casen.
7. Slett avsnittet «Førstegangsoppsett» fra denne fila.
8. Gå videre til normal sesjonsstart (§1) med de nå utfylte filene.

## 1. Normal sesjonsstart

Når oppdraget allerede er satt opp fra før:

1. Les `reference/best-practices.md` (global kontekst arvet fra malen).
2. Les `admin/engagement.md` (kundetilpasning, scope & frister) og `admin/rules.md`
   (kundespesifikke instrukser/begrensninger).
3. Les `STATUS.md` (nåværende status for casen).
4. Les `admin/ACTIVITY.md` (betydelige beslutninger denne casen: endret omfang, metode, retning
   eller leveranse).
5. Les de 2 seneste loggene under `changelog/`.
6. Les `admin/memory.md` (case-scoped læring samlet så langt).
7. Bygg `ARBEIDSFLYT.svg` etter §8. Skriptet skriver bare når noe er endret. Si hvilken fase
   skissen viser og hva den sier er neste steg.
8. Kjør endringssjekken etter §6.
9. Oppsummer kort status og vent på instrukser.

Kontroll: C2, C3, C15, C19.

## 2. Avslutningsrutine

Når økten avsluttes (eller bruker sier "avslutt økt" / "oppdater status"):

1. Verifiser at `admin/ACTIVITY.md` ble oppdatert underveis, se §4.
2. Opprett ny øktslogg i `changelog/` med `.claude/scripts/create-changelog.sh <initialer>`.
   Formatet står i `.claude/rules/memory-protocol.md`.
3. Oppdater `STATUS.md` dersom fremdrift, åpne spørsmål eller beslutninger er endret.
4. Oppdater `admin/memory.md` dersom noe med overføringsverdi kom frem.
5. Bygg `ARBEIDSFLYT.svg` på nytt etter §8.
6. Kjør kontrollene i `.claude/checks.md` som er merket for øktslutt.

Kontroll: C2, C8, C10, C11, C13, C17, C19.

## 3. Retningslinjer & Sikkerhet

* Se `.claude/rules/safety-rules.md` for regler vedrørende hemmeligheter, kommersielle
  forpliktelser og deling/tilgang.

## 4. Hvordan jobbe med oppdrag

* **our-approach** (i `.claude/skills/`) — samtalebasert arbeidsflyt for å bygge et
  consulting-tilbud: discovery (kunde/utfordring/mål/scope/leveransemodell) → tilnærming
  (fasedeling) → slide-for-slide utkast i chatten, helt frem til eksport. Trigges automatisk når
  bruker ber om et tilbud/en tilnærming, selv uten den eksakte frasen.

* **Formelle RFI/RFP/ITT-svar** — driftes av kundens eget dokument, ikke en skill-ledet samtale.
  Sett opp casemappen (se «Mappestruktur»), lagre kundens dokument under `Customers request/`,
  logg frist og åpne spørsmål i `STATUS.md`, og utform deretter de konkrete leveransene kundens
  dokument ber om, i det formatet kunden krever. Bruk `our-approach`-flytens prinsipper
  (discovery-oppsummering, slide/seksjon-for-seksjon-arbeid) som arbeidsmåte selv om
  outputformatet er kundens eget skjema, ikke en presentasjon.

* **Posisjonering:** Før du avgjør hvor konkret du navngir spesifikke merkede produkter/
  tjenester i en leveranse, les `reference/positioning-rules.md`.

* **Customer Value review og Writing Style review (review-porten):** Før et kundevendt
  dokument genereres endelig, kjør både `customer-value-reviewer` og `writing-style-reviewer` på
  samme innhold, og vis funnene til brukeren før godkjenning bes om eller eksport tilbys.
  «Kjør» betyr: les agentfilen under `.claude/agents/` og sjekklisten den peker til, og følg den
  nøyaktig – som isolert subagent der verktøyet støtter det (Claude Code), ellers utført
  direkte i denne økten (f.eks. Claude Cowork). Begge kjøremåtene skal gi samme sjekkliste og
  samme outputformat. Dette er den eneste beskrivelsen av review-porten i arbeidsflaten.
  Kontroll: C9.

* **Skrivestil:** Les `.claude/rules/writing-style.md` (og `.claude/customer-value/writing-style-core.md`
  den peker til) før kundevendt innhold skrives, og etterlev reglene der uten å bli minnet på det.

* **memory.md:** Les `admin/memory.md` før drafting starter på dette oppdraget
  (posisjoneringsbeslutninger, leveransemodell-valg som kan gjenbrukes så langt i casen).
  Oppdater den løpende med kunnskap som har overføringsverdi — ikke case-fremdrift (den hører
  hjemme i `STATUS.md`).

* **STATUS.md:** Holder løpende status for casen — oppsummering, scope/beslutninger, åpne
  spørsmål, og hvordan gjenoppta arbeidet. Oppdater den gjennom hele arbeidet med casen, ikke
  bare ved avslutning. Den er et øyeblikksbilde og skrives om fritt: merk eller fjern fullførte
  punkter, og hold fila spisset og lettlest.

* **ACTIVITY.md:** Løpende logg over betydelige beslutninger i casen — endret omfang, endret
  metode eller vinkling, byttet leveranseformat, droppet eller lagt til krav (`admin/ACTIVITY.md`).
  Ny oppføring skrives i det øyeblikket beslutningen tas, ikke samlet ved øktslutt.
  Rutinemessig fremdrift hører hjemme i `STATUS.md`. Nyeste oppføring øverst, og fila overskrives
  eller ryddes aldri: den er casens historikk, ikke dens øyeblikksbilde. Formatet står øverst i
  fila selv. Klokkeslettet hentes etter §6.

## 5. Kildehierarki

Når to filer sier ulike ting om samme sak, avgjør hva spørsmålet gjelder:

| Spørsmålet gjelder | Autoritativ kilde | Alt annet er |
|---|---|---|
| Hva kunden faktisk har bedt om | `Customers request/` | vår tolkning |
| Hva som er besluttet, og når | `admin/ACTIVITY.md` | referat av beslutningen |
| Hvor casen står nå | `STATUS.md` | utdatert |
| Scope, frist, kontakter | `admin/engagement.md` | referat |
| Hva som ble sagt i et møte | `Meeting notes/` | destillat |
| Hvordan vi arbeider i mappa | `CLAUDE.md` | peker hit |

`admin/memory.md` er gjenbrukbar kunnskap fra casen og er ikke autoritativ på noe av det over.
Er to kilder innenfor samme rad uenige, gjelder den nyeste, og uenigheten logges i
`admin/ACTIVITY.md`.

Kontroll: C3.

## 6. Tid og endringssjekk

Skallet kjører UTC. Loggene kjører Europe/Oslo. Differansen er reell: mellom kl. 00 og 02 norsk
tid er datoen i UTC gårsdagens.

**Tidsstempler hentes, aldri anslås.** Klokkeslett i `admin/ACTIVITY.md` og dato i
`STATUS.md` hentes fra `TZ=Europe/Oslo date "+%Y-%m-%d %H:%M"`, kjørt i samme kommando som
oppføringen skrives. Et klokkeslett uten tidssone skrives aldri i denne mappa.
`.claude/scripts/create-changelog.sh` gjør dette selv.

**Endringssjekk bruker alltid relativt tidsrom**, aldri et klokkeslett:
`find . -type f -mtime -1` lister filer endret siste døgn. Er lista tom, kjøres samme
kommando med `-mtime -30` for å skille «ingenting endret» fra «kommandoen virker ikke».

**Ingen kontroll kjøres med `2>/dev/null`.** Filer som ligger som OneDrive-plassholdere og ikke er
lastet ned lokalt, feiler på lesing med «Resource deadlock avoided». En slik fil rapporteres som
ulest. En ulest fil telles aldri som en fil uten treff.

Kontroll: C15.

## 7. Arbeidsregler

**Ingen placeholders.** Ingen malrester får bli stående i en fil som er tatt i bruk. Mangler
innholdet, spør bruker. Gjelder kopier av malen, ikke malen selv. Kontroll: C8.

**Én bryter per innstilling.** En regel står ett sted. Review-porten står i §4, strukturen
under «Mappestruktur», og skrivereglene i `.claude/customer-value/writing-style-core.md`. Ingen
av dem gjentas med egne ord i en annen fil. Kontroll: C9.

**Status står i innhold, ikke i filnavn.** Status settes i frontmatter, eller i mappas egen
README dersom fila må kunne limes inn ordrett. Kontroll: C10.

**Ingen backup-filer.** SharePoint og OneDrive holder versjonshistorikk. En lokal kopi før
redigering bryter både rot-regelen og filnavnregelen, og blir stående. En OneDrive-konfliktfil
(«Konflikterende kopi fra ...») fanges av samme kontroll og slås sammen manuelt, se
`KOM-I-GANG.md` Del D. Kontroll: C11.

**Få prosjektskills.** `.claude/skills/` inneholder bare skills. Skript ligger i
`.claude/scripts/`. Finnes en skill på kontoen, brukes den derfra og kopieres aldri hit.
Kontroll: C12.

**Maler beskriver bare steg som faktisk utføres.** Droppes et steg, fjernes raden i stedet for
at den står igjen tom. Kontroll: C13.

**Ingen døde referanser.** En fil eller mappe som nevnes med bakflått skal finnes. Et eksempel
som ikke peker på en faktisk fil skrives uten bakflått. Kontroll: C17.

**Hver ny kontroll kjøres mot fila som definerer den, i samme økt som den skrives.** En kontroll
som aldri er prøvd på seg selv, er den som viser seg å ikke virke et halvt år senere.
Kontroll: C18.

## 8. Arbeidsflytskissen

`ARBEIDSFLYT.svg` i roten viser flyten fra oppsett til eksport, hvor arbeidet står nå og hva
neste steg er, øktrutinen, mappestrukturen og skillene. Den gir brukerne løpende veiledning i
bruken av arbeidsområdet, og følger med når arbeidsområdet bygges ut.

Den er et **byggeartefakt, ikke et dokument.** `.claude/scripts/bygg-arbeidsflyt.py` skriver den
fra `.claude/scripts/arbeidsflyt-mal.svg` og filene i mappa: mappestrukturen fra treet under
«Mappestruktur», skills og agenter fra `.claude/`, og status fra filene. Kommandoen kjøres fra
roten: `python3 .claude/scripts/bygg-arbeidsflyt.py`. Skriptet skriver bare når kildene er endret.

**Rediger aldri `ARBEIDSFLYT.svg` direkte.** Endringen blir borte ved neste bygg.

**Regelen:** endres mappestrukturen, flyten, øktrutinen, skillene eller review-porten, endres
treet her eller malen i samme endring, og skissen bygges på nytt før økta avsluttes. Det gjelder
uansett hvem som gjør endringen, og uten at noen ber om det. Tall, status og «Du er her» fylles
av skriptet og skrives aldri i malen.

Skissen bygges ved sesjonsstart, i førstegangsoppsettet og ved øktslutt. En OneDrive-konfliktfil
på den løses ved å bygge på nytt.

Kontroll: C19.

## Mappestruktur

Dette er den eneste beskrivelsen av strukturen i arbeidsflaten. Roten inneholder nøyaktig
dette og ingenting annet:

```
<Kunde> - <Case>/
  CLAUDE.md                     normativ kilde, denne fila
  README.md                     menneskelig inngang, peker hit
  KOM-I-GANG.md                 onboarding: SharePoint, OneDrive, Cowork, samhandling
  STATUS.md                     nåsituasjon, les denne først
  ARBEIDSFLYT.svg               byggeartefakt: flyt, hvor du er nå, struktur og skills
  Sopra Steria template.docx    Word-mal for leveransen
  admin/                        engagement, rules, memory, ACTIVITY
    engagement.md
    rules.md
    memory.md
    ACTIVITY.md
  Customers request/            kundens eget materiale, står som mottatt
  Meeting notes/                møtenotater, filnavn YYYY-MM-DD_kort-tittel.md
  changelog/                    én øktslogg per økt, YYYY-MM-DD_<initialer>.md
  reference/                    metodegrunnlag: best-practices, posisjoneringsregler, diagram
  .claude/                      reviewere, regler, skills, scripts, checks
```

**Rot-regelen:** ingen andre filer eller mapper i roten. Trenger arbeidet et nytt sted å legge
noe, legges det i en eksisterende mappe, eller strukturen over endres her først. Midlertidige
filer, utkast og eksporter hører hjemme i mappa de tilhører. Kontroll: C2.

`admin/` samler strukturfilene som styrer casens historikk og Claudes oppførsel, men som
sjelden trengs som førstelesning for noen som kobler seg på casen. Egnet til å gi snevrere
SharePoint-redigeringstilgang enn resten av arbeidsområdet, se `KOM-I-GANG.md` Del E.
`STATUS.md` blir stående i roten, siden den er casens "les dette først"-fil.

`Customers request/` er dropbox for kundens eget materiale (RFI/RFP/ITT, briefing, synopsis).
`Meeting notes/` er løpende møtenotater, ett filnavn per møte med ISO-datoprefiks, slik at de
sorterer kronologisk. Destiller beslutninger og resonnement som betyr noe inn i `STATUS.md`, i
stedet for at de blir liggende begravd i et møtenotat.
