# Memory — <kundenavn> / <casenavn>

Working memory for denne casen: gjenbrukbar kunnskap som er relevant mens denne casen pågår.
Case-fremdrift (hva som er sendt, hva som er åpent, hva som gjenstår) hører hjemme i
`STATUS.md`, ikke her.

**Denne filen er case-scoped, ikke delt med andre caser.** Ved avslutning av casen: gå gjennom
innholdet under og vurder om noe har overføringsverdi til *fremtidige* caser. Hvis ja, fold det
manuelt inn i `consulting-template/memory.md` (malen) slik at nye caser arver det ved kopiering
— se `.claude/rules/memory-protocol.md`.

## Posisjoneringsbeslutninger

Avgjørelser om hvor konkret man har navngitt merkede produkter/tjenester i denne leveransen, og
hvorfor — se `reference/positioning-rules.md` for beslutningsrammen.

## Leveransemodell-valg

Hvilken leveransemodell (rådgivning/prosjekt/workshop-serie/retainer/kombinert/T&M) som ble
valgt for denne casen, og hva som talte for/mot underveis.

## Process lessons

Læring om selve tilbudsprosessen, ikke om kunden.

## Customer facts worth remembering

Varige fakta om kunden (ikke case-status) som er verdt å vite ved et fremtidig oppdrag.
