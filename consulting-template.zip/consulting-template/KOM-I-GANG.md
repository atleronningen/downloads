# Kom i gang med dette case-workspacet

Dette er et Consulting case-workspace satt opp fra `consulting-template`. Det ligger på et
SharePoint-område, synkes lokalt via OneDrive, og åpnes/jobbes i via Claude Cowork. Denne filen
er for deg som skal begynne å jobbe i et workspace som **noen andre allerede har satt opp** —
typisk en kollega som blir koblet på et pågående oppdrag.

Se `reference/multi-user-workflow.svg` for et diagram av hvordan de delte filene
(STATUS/ACTIVITY/changelog/memory) flyter mellom flere samtidige økter — nyttig som
supplement til Del C og Del D under.

## Del A — Tilkobling

1. **Få tilgang.** Be den som opprettet workspacet om å dele SharePoint-området med deg, med
   **redigeringstilgang** — ikke bare visningstilgang.
2. **Synkroniser via OneDrive.** Åpne det delte SharePoint-området i nettleseren og trykk
   "Synkroniser" — dette kobler mappen til din lokale OneDrive-klient.
3. **Vent på at synk er fullført.** Sjekk at mappen viser en grønn hake (synkronisert), ikke en
   blå synk-skyikon eller spinner, før du åpner den. Å begynne å jobbe i en mappe som fortsatt
   synker kan gi ufullstendige filer.
4. **Mount mappen i Claude Cowork.** Åpne den lokalt synkede mappen som workspace i Claude
   Cowork.
5. **Start sesjonen.** Les `STATUS.md` og de siste changelog-oppføringene i `changelog/` først
   — spesielt viktig når flere i teamet har jobbet i mellomtiden siden du sist var inne.

## Del B — Forutsetninger for at teamet skal kunne samhandle

- Alle teammedlemmer må ha **redigeringstilgang** (ikke bare visning) på SharePoint-området.
- Alle må ha OneDrive koblet til riktig organisasjonskonto, med aktiv synk av denne mappen.
- Alle må ha Claude Cowork med mulighet til å mounte OneDrive-synkede mapper som workspace.

## Del C — Do's

- **Skriv en changelog-oppføring ved slutten av hver sesjon**, selv korte økter. Dette er
  hovedmekanismen for å koordinere når flere jobber parallelt — filnavn med dato+initialer
  unngår kollisjon naturlig. Bruk `.claude/skills/create-changelog.sh <initialer>`.
- **Jobb per-slide/per-seksjon der det er mulig** (matcher `our-approach`-skillens
  slide-for-slide-flyt) — reduserer sjansen for at to personer redigerer samme fil samtidig.
- **Sjekk `STATUS.md` og de siste changeloggene før hver sesjon**, ikke bare når du kobler deg
  på for første gang.
- **Sjekk sist endret-tidspunkt på `STATUS.md` og `ACTIVITY.md` før du starter en økt**, og si
  ifra i teamet dersom dere jobber i casen samtidig — filene låses ikke automatisk, og
  samtidige lagringer kan kollidere (se Del D).
- **La kun én person regenerere selve dokumentet/presentasjonen om gangen**, og noter i
  changelog når det gjøres, slik at ingen andre gjør det samtidig.

## Del D — Don'ts

- **Ikke rediger `STATUS.md`, `ACTIVITY.md`, `engagement.md` eller `rules.md` samtidig som noen
  andre.** Disse er delte enkeltfiler uten sanntids-samskriving slik Word/PowerPoint har — to
  samtidige Claude-sesjoner som lagrer disse filene kan overskrive hverandres endringer. Ved
  tvil: den som eier oppdraget eier disse filene, andre foreslår endringer via changelog eller
  direkte dialog.
- **Ikke rediger `.claude/`-innhold** (agents/skills/rules) midt i et oppdrag uten å varsle
  teamet — det påvirker alles Claude-sesjoner umiddelbart.
- **Ikke rediger presentasjonen/dokumentet direkte samtidig som en Claude-sesjon regenererer
  det.** Velg én kanal om gangen, og si ifra i changelog hvilken.
- **Se opp for OneDrive-konfliktfiler**, gjenkjennes på navn som
  `<filnavn> (Konflikterende kopi fra <navn> <dato>).md` — dette betyr at to lagringer kolliderte.
  Noen må manuelt slå sammen innholdet og slette duplikatet; ikke la konfliktfiler ligge.
