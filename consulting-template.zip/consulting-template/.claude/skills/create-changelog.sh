#!/usr/bin/env bash
# Hjelpeskript for å opprette tom datostemplet changelog i denne casens changelog/-mappe
INITIALER=$1
DATO=$(date +%Y-%m-%d)

if [ -z "$INITIALER" ]; then
  echo "Bruk: ./create-changelog.sh <initialer>"
  exit 1
fi

TARGET_DIR="changelog"
TARGET_FILE="$TARGET_DIR/${DATO}_${INITIALER}.md"

mkdir -p "$TARGET_DIR"

cat <<EOF > "$TARGET_FILE"
# Øktslogg: $DATO ($INITIALER)

## Hva ble utført
-

## Utfordringer / Feil oppdaget
-

## Neste steg
-
EOF

echo "Opprettet changelog: $TARGET_FILE"
