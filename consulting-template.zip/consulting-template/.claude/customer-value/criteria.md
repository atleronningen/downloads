# Customer Value - Review Criteria

Shared criteria used by the `customer-value-reviewer` agent across projects. This file holds
*what* to check. Project-specific framing (RFI-compliance lens vs. service-positioning lens)
comes from that project's own `CLAUDE.md` and `memory.md`, not from here.

> **This is the canonical version.** Local copies exist in each project so the review works
> without `AI-work` mounted: `Consulting-offers/.claude/customer-value/criteria.md`,
> `MSP-offers/.claude/customer-value/criteria.md`,
> `References/.claude/customer-value/criteria.md`,
> `Service-Dev/.claude/customer-value/criteria.md`,
> `My-Slides/.claude/customer-value/criteria.md`,
> `transition-hub/.claude/customer-value/criteria.md`,
> `service-catalog/.claude/customer-value/criteria.md`,
> `architecture-hub/.claude/customer-value/criteria.md`. When you edit this file, copy the
> change into every local copy listed above too, they don't update automatically. (Decided
> 2026-08-07, so Consulting-offers and MSP-offers could each be mounted alone and still run
> the review; My-Slides added 2026-08-17; transition-repo added 2026-08-29, renamed
> transition-hub 2026-09-03; service-catalog added 2026-09-03; architecture-hub added
> 2026-09-07.)

## What this agent is for

Challenge whether a deliverable (RFI response, service description, consulting deck,
one-pager) actually creates value for the customer, not whether it is complete, compliant,
or well-written. Completeness and polish are the drafting skill's job. This agent's job is to
ask: would the customer's decision-maker read this and see something built for them, or
something generic that could go to anyone?

## Checks to run

For each deliverable under review:

1. **Traced to a specific pain point.** Every value claim ties to something concrete about
   this customer – a stated problem, a scale figure, an industry pattern – not a generic
   capability statement that could apply to any customer.
2. **Win themes are adapted, not reused verbatim.** Cross-check against the project's
   `memory.md` win-themes library. A theme can be reused, but its framing must be adapted to
   this customer's specific situation, not copy-pasted.
3. **Claims are grounded in real sources.** Every product/service/customer claim traces to a
   source that's authoritative for *this* project: the service catalogue (Right* catalogue,
   service-catalog) for RFI and consulting-offer work, the customer's own interview
   answers for case studies, verified web/annual-report research for activation
   kartlegginger, not invented or asserted generically. Flag anything that sounds plausible
   but isn't traceable to its project's actual source material.
4. **Answers "so what."** Every section states what the claim means for the customer's
   business outcome, not just what Sopra Steria offers.
5. **Scope and commercial claims are realistic.** No commitments beyond what's actually known
   about the customer or explicitly provided by the user (pricing, timelines, staffing).
6. **Advisory, not just reactive.** The deliverable recommends a path, not only answers the
   literal question asked.
7. **Differentiated.** Could a competent competitor submit this exact text with their own logo
   on it? If yes, it hasn't cleared the bar.

## How to review

- Read the project's own `CLAUDE.md` and `memory.md` first: they define the lens and the
  reference material to check claims against.
- Go section by section through the deliverable. For each section that fails a check, name
  the check, quote the weak line, and state what's missing. Don't rewrite it, that's the
  drafting skill's job.
- End with a short verdict. Be honest, a rubber-stamp review defeats the purpose of having
  this agent at all.

## Output format

```
## Customer Value Review - <deliverable name>

### Verdict: [ship as-is / ship with fixes / not ready]

### Findings
- [Section/line] - [check failed] - [what's missing]
- ...

### What's working
- [one or two things genuinely strong, so this isn't just criticism]
```
