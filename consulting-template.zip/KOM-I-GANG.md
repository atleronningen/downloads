# Kom i gang med dette case-workspacet

Dette er et Consulting case-workspace satt opp fra `consulting-template`. Det ligger på et
SharePoint-område, synkes lokalt via OneDrive, og åpnes/jobbes i via Claude Cowork.

<!-- MAL-START -->
Setter du opp oppdraget for aller første gang, og oppretter selv SharePoint-mappen? Gå til
**Del A0** rett under.
<!-- MAL-SLUTT -->
Kobler du deg på et workspace **noen andre allerede har satt opp**, typisk fordi du blir
koblet på et pågående oppdrag? Gå rett til **Del A**.

Se `reference/multi-user-workflow.svg` for et diagram av hvordan de delte filene
(STATUS/ACTIVITY/changelog/memory) flyter mellom flere samtidige økter, som supplement til
Del C og Del D under.

<!-- MAL-START -->
## Del A0 – Setter du opp et helt nytt oppdrag?

1. Gå til SharePoint-området, opprett en mappe der delt AI-arbeid skal foregå (f.eks.
   «AI-workspace»), trykk «...» og velg «Sync» for å koble den til din lokale OneDrive.
2. Gå til OneDrive-synkmappen i filsystemet, og pakk ut zip-fila med malen der. Zip-fila lages
   fra malen med `.claude/scripts/pakk-mal.py`.
3. Monter den samme OneDrive-mappen som arbeidsområde i Claude Cowork, og skriv «Start økt».
   Claude ser at `STATUS.md` fortsatt har placeholders, og gjør oppsettet under.

**Oppsettet Claude gjør, i denne rekkefølgen:**

1. Spør om **kundenavn** og **casenavn**.
2. Fyll ut placeholders i `admin/engagement.md`, `admin/rules.md`, `STATUS.md` og tittelen i
   `admin/memory.md` med det som blir oppgitt. Ikke gjett på informasjon du ikke har fått;
   mangler innholdet, spør bruker i stedet for å la en placeholder stå.
3. Fjern mal-blokkene i `README.md` og `KOM-I-GANG.md`: alt fra og med `<!-- MAL-START -->` til
   og med `<!-- MAL-SLUTT -->`, markørene inkludert. Sett tittelen i `README.md` til kunde og
   case.
4. Kjør C8. Oppsettet er ikke ferdig før kontrollen gir ingen treff.
5. Gå videre til normal sesjonsstart (`CLAUDE.md` §1).

Gå deretter videre til Del B og Del C under, de gjelder uansett om du satte opp oppdraget
selv eller kobler deg på et som allerede finnes.
<!-- MAL-SLUTT -->

## Del A – Tilkobling

1. Gå til SharePoint-området hvor mappen for delt AI-arbeid ligger, trykk «...» og velg
   «Sync» for å koble den til din lokale OneDrive.
2. Gå til OneDrive-synkmappen i filsystemet, og vent til mappen viser en grønn hake før du
   åpner den. Å begynne å jobbe i en mappe som fortsatt synker kan gi ufullstendige filer.
3. Monter den samme OneDrive-mappen som arbeidsområde i Claude Cowork, og skriv «Start økt».
   Claude følger `CLAUDE.md` §1.

## Del B – Forutsetninger for at teamet skal kunne samhandle

- Alle teammedlemmer må ha **redigeringstilgang** (ikke bare visning) på SharePoint-området.
- Alle må ha OneDrive koblet til riktig organisasjonskonto, med aktiv synk av denne mappen.
- Alle må ha Claude Cowork med mulighet til å mounte OneDrive-synkede mapper som workspace.
- Alle må ha skillene `pptx`, `sopra-steria-brand` og `sopra-steria-korrektur` tilgjengelige
  (fra Sopra Steria sin AI Agent Marketplace). Mangler en av dem, stopper eksport eller
  korrektur, og Claude sier fra i stedet for å improvisere.

## Del C – Do's

- **Skriv en changelog-oppføring ved slutten av hver sesjon der noe ble endret.** Dette er
  hovedmekanismen for å koordinere når flere jobber parallelt; filnavn med dato, klokkeslett
  og initialer unngår kollisjon. Bruk `.claude/scripts/create-changelog.sh <initialer>`.
- **Jobb per slide/seksjon der det er mulig** (matcher `our-approach`-skillens
  slide-for-slide-flyt), det reduserer sjansen for at to personer redigerer samme fil samtidig.
- **La Claude gjøre statussjekken ved øktstart** (`CLAUDE.md` §1): den leser STATUS og siste
  logg, lister kundens filer og møtenotater, og sier fra hvis noe er nyere enn STATUS. Si ifra i
  teamet dersom dere jobber i casen samtidig; filene låses ikke automatisk.
- **La kun en person regenerere selve dokumentet/presentasjonen om gangen**, og noter i
  changelog når det gjøres.

## Del D – Don'ts

- **Ikke rediger `STATUS.md`, `admin/ACTIVITY.md`, `admin/engagement.md` eller `admin/rules.md`
  samtidig som noen andre.** Disse er delte enkeltfiler uten sanntids-samskriving. To
  samtidige Claude-sesjoner som lagrer disse filene kan overskrive hverandres endringer. Ved
  tvil: den som eier oppdraget eier disse filene, andre foreslår endringer via changelog eller
  direkte dialog.
- **Ikke rediger `.claude/`-innhold** (agents/skills/rules) midt i et oppdrag uten å varsle
  teamet, det påvirker alles Claude-sesjoner umiddelbart.
- **Ikke rediger presentasjonen/dokumentet direkte samtidig som en Claude-sesjon regenererer
  det.** Velg en kanal om gangen, og si ifra i changelog hvilken.
- **Se opp for OneDrive-konfliktfiler.** Når to lagringer kolliderer, beholder OneDrive begge
  og henger maskinnavnet på den ene, for eksempel «STATUS-Atles-MacBook-Air.md». Kontroll C2
  melder dem som `EKSTRA`. Noen må manuelt slå sammen innholdet og slette duplikatet; ikke la
  konfliktfiler ligge. Dette er det eneste stedet konfliktfiler er beskrevet.

## Del E – Tilgangsstyring i SharePoint (for den som setter opp oppdraget)

Den som oppretter SharePoint-mappen (Del A0) er som regel eier av tilgangene der, og bør
aktivt tilpasse dem, ikke bare stole på det som arves fra et overordnet Team-område. Åpne
mappen i SharePoint, trykk «...» → «Manage access» for å se både navngitte personer
(«People») og grupper som arver tilgang fra et overordnet område («Groups»), f.eks. en hel
kontoteam-gruppe med «Can view». Dette gjelder for hele arbeidsområdet, men også for hver
undermappe eller fil for seg. Bruk samme «Manage access»-dialog på en enkelt undermappe for
å bryte arvingen og sette strengere regler enn resten av arbeidsområdet, der det trengs.

**Hvorfor det er viktig å begrense tilgangen:**
- `admin/` (`engagement.md`, `rules.md`, `memory.md`, `ACTIVITY.md`) og `.claude/`-mappen
  styrer hvordan Claude oppfører seg og hva som regnes som casens historikk for alle som
  jobber i den. Do's/don'ts i Del C/D over er konvensjon, ikke en sperre, de hindrer ikke at
  noen uten kontekst for casen, f.eks. via en bred arvet gruppe, redigerer disse filene ved et
  uhell og endrer oppførselen stille for hele teamet. Fordi disse fire filene ligger samlet i
  en mappe, holder det å bryte arvingen på `admin/` en gang, i stedet for å gjøre det fil for
  fil.
- `CLAUDE.md` og `STATUS.md` blir stående i roten (Claude Code laster `CLAUDE.md` automatisk
  derfra, og `STATUS.md` er ment som lett tilgjengelig). Vurder likevel om hele rotnivået bør
  ha redigeringstilgang begrenset til kjerneteamet, siden `CLAUDE.md` fortsatt styrer Claudes
  oppførsel direkte.
- `Customer requests/` og `Meeting notes/` inneholder kildemateriell: kundens egen
  forespørsel (RFI/RFP/ITT), briefer og møtereferater. Dette er ofte sensitivt, og skal stå
  som mottatt, ingen bør redigere eller «forbedre» kundens originale dokumenter i ettertid,
  og materialet bør ikke deles bredere enn det teamet som faktisk jobber i casen.

**Anbefalt tilgang, mappe for mappe:**

| Mappe/fil | Anbefalt tilgang | Begrunnelse |
|---|---|---|
| `admin/` | Redigering kun for de som faktisk jobber i casen, bryt arving på denne ene mappen | Styrer casens historikk (engagement, regler, minne, aktivitetslogg) |
| `.claude/` | Redigering kun for de som faktisk jobber i casen | Styrer Claudes oppførsel for alle |
| `CLAUDE.md`, `STATUS.md` (rot) | Vurder samme innstramming som `admin/` | Styrer Claudes oppførsel / casens status, må ligge i roten |
| `Customer requests/`, `Meeting notes/` | Vurder å bryte arving og sette snevrere tilgang enn resten (f.eks. kun kjerneteamet, evt. visning for øvrige) | Kildemateriell / audit-spor, ofte sensitivt |
| `Deliverables/`, `reference/` | Kan følge samme tilgang som resten av teamet | Ment å redigeres av de som drafter |

- Del aldri arbeidsområdet bredere enn det teamet som faktisk jobber i casen trenger, med
  redigeringstilgang, ikke bredere enn nødvendig (se `.claude/rules/safety-rules.md`).
- Sjekk «Groups»-fanen spesielt: en arvet gruppe fra et overordnet Team-område (f.eks.
  «... Visitors» eller «... Members») kan gi tilgang til langt flere enn de som faktisk er i
  casen, uten at det er tydelig ved første øyekast.
