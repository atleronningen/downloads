# Kom i gang med dette case-workspacet

Dette er et Consulting case-workspace satt opp fra `consulting-template`. Det ligger på et
SharePoint-område, synkes lokalt via OneDrive, og åpnes/jobbes i via Claude Cowork.

Setter du opp oppdraget for aller første gang, og oppretter selv SharePoint-mappen? Gå til
**Del A0** rett under. Kobler du deg på et workspace **noen andre allerede har satt opp** —
typisk fordi du blir koblet på et pågående oppdrag? Gå rett til **Del A**.

Se `reference/multi-user-workflow.svg` for et diagram av hvordan de delte filene
(STATUS/ACTIVITY/changelog/memory) flyter mellom flere samtidige økter — nyttig som
supplement til Del C og Del D under.

## Del A0 — Setter du opp et helt nytt oppdrag?

1. Gå til SharePoint-området, opprett en mappe der delt AI-arbeid skal foregå (f.eks.
   «AI-workspace»), trykk «...» og velg «Sync» for å koble den til din lokale OneDrive.
2. Gå til OneDrive-synkmappen i filsystemet, og pakk ut `consulting-template`-zip-filen der.
3. Monter den samme OneDrive-mappen som arbeidsområde i Claude Cowork, og skriv «Nytt oppdrag
   satt opp for første gang». Claude spør om kundenavn og casenavn, og fyller ut
   `engagement.md`, `rules.md`, `STATUS.md` og `memory.md` selv (se `CLAUDE.md` §1).

Gå deretter videre til Del B og Del C under — de gjelder uansett om du satte opp oppdraget
selv eller kobler deg på et som allerede finnes.

## Del A — Tilkobling

1. Gå til SharePoint-området hvor mappen for delt AI-arbeid ligger, trykk «...» og velg
   «Sync» for å koble den til din lokale OneDrive.
2. Gå til OneDrive-synkmappen i filsystemet, og vent til mappen viser en grønn hake før du
   åpner den. Å begynne å jobbe i en mappe som fortsatt synker kan gi ufullstendige filer.
3. Monter den samme OneDrive-mappen som arbeidsområde i Claude Cowork, og skriv «Gi meg status
   og les de siste changelogene.»

## Del B — Forutsetninger for at teamet skal kunne samhandle

- Alle teammedlemmer må ha **redigeringstilgang** (ikke bare visning) på SharePoint-området.
- Alle må ha OneDrive koblet til riktig organisasjonskonto, med aktiv synk av denne mappen.
- Alle må ha Claude Cowork med mulighet til å mounte OneDrive-synkede mapper som workspace.
- Alle bør ha `sopra-steria-korrektur` installert som global skill (fra Sopra Steria sin AI
  Agent Marketplace) for automatisk korrektur av norsk tekst. Er den ikke installert, kan
  drafting fortsatt gjøres i chatten, men den automatiske korrekturen uteblir.

## Del C — Do's

- **Skriv en changelog-oppføring ved slutten av hver sesjon**, selv korte økter. Dette er
  hovedmekanismen for å koordinere når flere jobber parallelt — filnavn med dato+initialer
  unngår kollisjon naturlig. Bruk `.claude/skills/create-changelog.sh <initialer>`.
- **Jobb per-slide/per-seksjon der det er mulig** (matcher `our-approach`-skillens
  slide-for-slide-flyt) — reduserer sjansen for at to personer redigerer samme fil samtidig.
- **Sjekk `STATUS.md` og de siste changeloggene før hver sesjon**, ikke bare når du kobler deg
  på for første gang.
- **Sjekk sist endret-tidspunkt på `STATUS.md` og `ACTIVITY.md` før du starter en økt**, og si
  ifra i teamet dersom dere jobber i casen samtidig — filene låses ikke automatisk, og
  samtidige lagringer kan kollidere (se Del D).
- **La kun én person regenerere selve dokumentet/presentasjonen om gangen**, og noter i
  changelog når det gjøres, slik at ingen andre gjør det samtidig.

## Del D — Don'ts

- **Ikke rediger `STATUS.md`, `ACTIVITY.md`, `engagement.md` eller `rules.md` samtidig som noen
  andre.** Disse er delte enkeltfiler uten sanntids-samskriving slik Word/PowerPoint har — to
  samtidige Claude-sesjoner som lagrer disse filene kan overskrive hverandres endringer. Ved
  tvil: den som eier oppdraget eier disse filene, andre foreslår endringer via changelog eller
  direkte dialog.
- **Ikke rediger `.claude/`-innhold** (agents/skills/rules) midt i et oppdrag uten å varsle
  teamet — det påvirker alles Claude-sesjoner umiddelbart.
- **Ikke rediger presentasjonen/dokumentet direkte samtidig som en Claude-sesjon regenererer
  det.** Velg én kanal om gangen, og si ifra i changelog hvilken.
- **Se opp for OneDrive-konfliktfiler**, gjenkjennes på navn som
  `<filnavn> (Konflikterende kopi fra <navn> <dato>).md` — dette betyr at to lagringer kolliderte.
  Noen må manuelt slå sammen innholdet og slette duplikatet; ikke la konfliktfiler ligge.
