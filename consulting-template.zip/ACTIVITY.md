# ACTIVITY.md

Logg over betydelige endringer i denne casen: endret omfang, metode, retning eller leveranse,
og beslutninger noen vil lete etter i ettertid. Rutinemessig fremdrift og status hører hjemme i
`STATUS.md` — se `.claude/rules/memory-protocol.md` for skillet.

Nyeste oppføring øverst. Filen er en løpende logg og skal ikke ryddes opp i eller skrives om.

Format:

```
[YYYY-MM-DD HH:MM | Initialer]
Endring:
Årsak:
Berørte filer:
```

Flere personer involvert i samme beslutning skilles med `+`, f.eks. `AR + MH`.

---

(ingen oppføringer ennå)
