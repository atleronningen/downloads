# Global Best Practices – Consulting

Standard arbeidsvaner for rådgivningsoppdrag, samlet på tvers av caser.

## Discovery før tilnærming
* Ikke gå videre til å strukturere en tilnærming/fasedeling før discovery-oppsummeringen
  (kunde, utfordring, mål, scope, leveransemodell) er bekreftet av bruker, se `our-approach`-
  skillen for det nøyaktige formatet.
* Fyll `admin/engagement.md` fortløpende etter hvert som discovery-elementene blir avklart, ikke
  bare ved førstegangsoppsett.

## Slide-for-slide-arbeid
* Ett slide er iterasjonsenheten: utkast → vis → tilbakemelding → bekreft, så neste slide.
  Ikke eksporter til PowerPoint/HTML før alle slides er bekreftet.
* Hvis en økt avsluttes med dekket delvis ferdig, noter i `STATUS.md` hvilke slides som er låst
  og hva som gjenstår, slik at neste økt kan gjenoppta loopen i stedet for å starte discovery på
  nytt.

## Illustrasjon fremfor punktlister
* For prosess-/metodikk-slides som lett blir en punktvegg (f.eks. "slik fungerer workshoppen",
  "slik er personas strukturert"): bygg en enkel merkevaremessig illustrasjon/modell i stedet
  for ren tekst. Gjør dette som standard for prosess-/metodikk-slides, ikke bare når det blir
  eksplisitt bedt om.

## «Why us» – blueprints først
* Rangér beviste referanse-blueprints/-arkitekturer (rask, lav-risiko måldesign) øverst i
  "Why Sopra Steria"-argumentasjonen, med navngitte referansecaser og verktøy som støttende
  bevis under, ikke omvendt.

## Kvalitetskontroll før eksport
* Kjør review-porten på bekreftet innhold før eksportspørsmålet stilles til bruker. Porten er
  beskrevet i `CLAUDE.md` §4, og gjentas ikke her.
