# Global Best Practices – Consulting

Standard arbeidsvaner for rådgivningsoppdrag, samlet på tvers av caser.

## Discovery før tilnærming
* Ikke gå videre til å strukturere en tilnærming/fasedeling før discovery-oppsummeringen
  (kunde, utfordring, mål, scope, leveransemodell) er bekreftet av bruker, se `our-approach`-
  skillen for det nøyaktige formatet. Skillen skriver den bekreftede oppsummeringen til
  `admin/engagement.md`.

## Slide-for-slide-arbeid
* Ett slide er iterasjonsenheten: utkast, vis, tilbakemelding, bekreft, så neste slide.
  Ikke eksporter til PowerPoint før alle slides er bekreftet.
* Hvis en økt avsluttes med dekket delvis ferdig, noter i `STATUS.md` hvilke slides som er låst
  og hva som gjenstår, slik at neste økt kan gjenoppta loopen i stedet for å starte discovery på
  nytt.

## Illustrasjon fremfor punktlister
* For prosess-/metodikk-slides som lett blir en punktvegg (f.eks. "slik fungerer workshoppen",
  "slik er personas strukturert"): bygg en enkel merkevaremessig illustrasjon/modell i stedet
  for ren tekst. Gjør dette som standard for prosess-/metodikk-slides.

## «Why us» – blueprints først
* Ranger beviste referanse-blueprints/-arkitekturer (rask, lav-risiko måldesign) øverst i
  "Why Sopra Steria"-argumentasjonen, med navngitte referansecaser og verktøy som støttende
  bevis under.
