# Posisjonering: Når skal spesifikke merkede produkter/tjenester navngis?

Beslutningsramme for hvor konkret man navngir Sopra Sterias merkede produkter/tjenester
(f.eks. Right*-porteføljen) i en kundevendt leveranse. Testen er **hva kunden faktisk kjøper**,
ikke hvilken mappe leveransen ligger i, og ikke om det formelt er en RFI/RFP eller ikke.

## Beslutningstre

1. **Formell RFI/RFP for en konkret produktifisert/driftet tjeneste** – kunden forventer
   konkrete, ansvarlige svar om hva de vil drifte. Navngi det spesifikke produktet direkte.

2. **Rådgivnings-/analyseleveranse** (mulighetsstudie, kartlegging, utredning) – selv når det
   er en formell RFI. Hold deg på referansearkitektur-/metodikk-nivå. Ikke navngi spesifikke
   produkter. Leveransen som selges er studien/analysen i seg selv, ikke et produkt, å navngi
   et spesifikt produkt kan direkte motsi et løfte om teknologi-/leverandøragnostisk tilnærming.

3. **Team-/bemanningsoppdrag** (navngitte roller/FTE-er) – samme som punkt 2, selv når
   oppdraget formelt er pakket som en «managed service»-kontrakt. Testen er om kunden kjøper et
   team med navngitte roller og kompetanse, eller en pakketert/merket tjeneste. Et team-krav er
   ikke automatisk et produktnavngivings-case bare fordi kontraktsformen ligner en driftsavtale.

4. **Advise & Build-tilbud uten formell RFI** – hold deg på referansearkitektur-nivå. Forankre
   alle påstander internt mot produktporteføljen, men bruk kundevendt språk som «referanse-
   blueprints» / «referansedesign» / «referansearkitektur». Reintroduser konkret produktnavn
   først når oppdraget beveger seg inn i en faktisk bygge-/drifts-/kontraktsfase, eller hvis
   bruker eksplisitt ber om det.

## Praktisk sjekk

Spør: **kjøper kunden en studie, et team, eller et produkt?**
- Studie eller team → referansearkitektur-nivå, ingen produktnavngiving.
- Produkt/pakketert tjeneste → navngi produktet direkte.

Logg avgjørelsen og begrunnelsen i casens `admin/memory.md` under «Posisjoneringsbeslutninger»,
slik at neste lignende case slipper å ta stilling til det fra scratch.
