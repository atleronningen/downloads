# Kravmatrise: <kunde> / <case>

Kopieres til Leveranser/kravmatrise.md i samme økt som kundens dokument legges i
`Customers request/`. Regelen står i `CLAUDE.md` §4.

Kilde: <filnavn i Customers request/>, mottatt <dato>. Frist: <dato og klokkeslett>.

Antall krav i kundens dokument, bekreftet av bruker: <tall>. Antall rader under telles med
`grep -c "^| K[0-9]" Leveranser/kravmatrise.md` og skal være likt.

| Id | Kundens ordlyd (uendret) | Type (skal/bør/info) | Besvares i | Status (ikke påbegynt/utkast/bekreftet) | Ansvarlig |
|---|---|---|---|---|---|
| K1 | | | | | |
