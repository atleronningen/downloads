# Safety & Compliance Rules

## Secrets & Credential Management
* ALDRI skriv passord, API-nøkler, private nøkler eller hemmeligheter inn i markdown-filene.
* Referer til hemmeligheter via navn i teamets passordbehandler / Key Vault.

## Deling & Tilgang (SharePoint/OneDrive)
* Del dette workspacet kun med personer som faktisk skal jobbe på casen (redigeringstilgang,
  ikke bredere enn nødvendig).
* Se `KOM-I-GANG.md` for forutsetninger og do's/don'ts ved samhandling mellom flere brukere i
  samme workspace, og Del E der for hvordan tilpasse SharePoint-rettigheter mappe for mappe,
  spesielt for strukturfiler og kildemateriell som `Customers request/` og `Meeting notes/`.

## Kundedata
* Legg bare kundemateriale i arbeidsflaten når kontrakt, NDA og kundens klassifisering tillater
  at det behandles av Claude. Ved tvil avklares det med ansvarlig konsulent før fila legges i
  `Customers request/`.
* Personopplysninger utover navn og kontaktinfo til kundens kontaktpersoner fjernes eller
  anonymiseres før materialet legges inn.
* Kundeinformasjon lagres bare i denne mappa. Den skrives aldri til Claude-minnet på kontonivå,
  til globale skills eller til prosjekter som deles på tvers av caser. Ber bruker Claude huske
  noe om kunden, legges det i `admin/memory.md`.

## Kommersielle forpliktelser
* Ikke fremstill pris, tidslinje, bemanning eller andre kommersielle detaljer som avklart eller
  bindende før bruker eksplisitt har bekreftet dem. Ved usikkerhet, spør før det skrives inn i
  et kundevendt dokument.
