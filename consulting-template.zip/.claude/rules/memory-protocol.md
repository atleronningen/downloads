# Memory Protocol & Changelog Rules

## Format for Øktslogger (`changelog/YYYY-MM-DD_<initialer>.md`)
Hver logg skal struktureres slik:
1. **Header:** Dato, Konsulent (initialer/navn), Surface (Claude Code / Cowork), Formål med
   økten.
2. **Hva ble utført:** Punktliste over faktiske endringer eller undersøkelser.
3. **Utfordringer / Feil oppdaget:** Hva gikk galt og hvordan ble det løst.
4. **Neste steg:** Hva står igjen for neste konsulent som overtar saken.

## ACTIVITY.md — betydelige endringer
* `ACTIVITY.md` er en enkelt, løpende og aldri omskrevet logg over beslutninger noen vil lete
  etter i ettertid: endret omfang, endret metode eller vinkling, byttet leveranseformat, droppet
  eller lagt til krav. Rutinemessig fremdrift hører hjemme i `STATUS.md`, ikke her.
* Ny oppføring skrives **i det øyeblikket** en slik beslutning tas, ikke samlet ved øktens
  slutt — samme prinsipp som `STATUS.md` under.
* Formatet står øverst i `ACTIVITY.md` selv. Nyeste oppføring øverst, og filen ryddes aldri opp
  i eller skrives om.
* `ACTIVITY.md` er casens historikk, ikke overførbar kunnskap. Gjentar samme type hendelse seg
  over flere caser, er det signal om at *lærdommen* er verdt å fange opp separat, mens selve
  hendelsen blir stående i `ACTIVITY.md`.

## Oppdatering av `STATUS.md`
* `STATUS.md` skal holdes løpende oppdatert gjennom arbeidet med casen, ikke bare ved
  avslutning — oppsummering, scope/beslutninger, åpne spørsmål, og hvordan gjenoppta arbeidet.
* Merk eller fjern fullførte punkter ved øktens slutt. Hold filen spisset og lettlest.
