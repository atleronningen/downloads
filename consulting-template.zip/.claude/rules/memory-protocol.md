# Loggformat

Formatet for øktslogger i `changelog/`. Reglene for når logger, `STATUS.md` og
`admin/ACTIVITY.md` skrives står i `CLAUDE.md` §2 og §4, og gjentas ikke her.

## Filnavn

`changelog/YYYY-MM-DD_HHMM_<initialer>.md`. Dato, klokkeslett og initialer i filnavnet gjør at
flere økter samme dag ikke kolliderer, heller ikke to økter hos samme person.

## Innhold

Opprettes med `.claude/scripts/create-changelog.sh <initialer>`, som henter dato og tidspunkt i
Europe/Oslo og avviser en logg som allerede finnes. Feltene står i skriptet og bare der; fila
skal ikke ha andre felt enn de skriptet lager.

* **Formål med økten:** fylles ut i starten av økta.
* **Hva ble utført:** punktliste over faktiske endringer eller undersøkelser.
* **Utfordringer og feil oppdaget:** hva gikk galt og hvordan ble det løst.

Neste steg står i `STATUS.md` under «Hvordan gjenoppta arbeidet», ikke i loggen.

## Skillet mot ACTIVITY.md

Øktsloggen forteller hva som ble gjort i en økt. `admin/ACTIVITY.md` forteller hva som ble
besluttet, på tvers av økter, og skrives aldri om. Rutinemessig fremdrift hører hjemme i
`STATUS.md`, ikke i ACTIVITY. Gjentar samme type hendelse seg over flere caser, hører lærdommen
i `admin/memory.md`, mens hendelsen blir stående i `ACTIVITY.md`.
