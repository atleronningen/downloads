# Writing Style Rules – Consulting-repo

Rules to apply automatically when drafting customer-facing content (consulting-tilbud,
tilnærmingspresentasjoner, RFI/RFP/ITT-svar) in this repo. Don't wait to be reminded of these.

See `.claude/customer-value/writing-style-core.md` (this project's local copy of the
shared rules) for the shared rules and their examples.
Read that file before drafting and apply every rule in it, including any rule added there
since this file was last touched. That file is the authority; this one only adds the
project-specific example below.

## Project-specific example

Bad (consulting cliché, vague on outcome): "We leverage our synergies to unlock transformative
outcomes and drive a paradigm shift in how you work."

Good (specific, affirmative): "We combine our AI and workplace teams to cut rollout time from
six months to eight weeks."
