# Kontroller

Kontrollkommandoene for reglene i `CLAUDE.md`. Denne fila inneholder ingen regler. Hver regel
står ett sted, i `CLAUDE.md`, og peker hit med en C-id. Endrer du en regel, endrer du
kontrollen her i samme økt. Fila inneholder heller ingen tilstand: hva en kontroll ga en gitt
dag hører hjemme i `STATUS.md` eller øktsloggen.

Alle kommandoer kjøres fra roten av arbeidsflaten. De gir samme svar på macOS og Linux.

**Feilmeldinger undertrykkes aldri.** Filer som ligger som OneDrive-plassholdere og ikke er
lastet ned lokalt, feiler på lesing med «Resource deadlock avoided». En kontroll som kjøres med
`2>/dev/null` teller da en ulest fil som en fil uten treff, og svarer grønt på feil grunnlag.
Ingen kontroll i denne fila kjøres med `2>/dev/null`, og enhver fil som feiler slik rapporteres
som **ulest**, aldri som ren.

**Når kontrollene kjøres:**

- Ved øktslutt, bare når kundevendt innhold ble skrevet eller endret: C8 og C20.
- Ved malvedlikehold (se `.claude/MALENDRINGER.md`), og når en fil flyttes eller får nytt navn:
  C2, C9, C17, C21.
- Ved sesjonsstart: ingen.

Kontrollene er skrevet for en kopi av malen som er tatt i bruk. I selve malen gir C8 treff
(malplassholderne).

---

### C2 · Rot-regelen («Mappestruktur» i CLAUDE.md)

```
python3 - <<'PY'
import os,re,unicodedata
def nfc(t): return unicodedata.normalize('NFC',t)
def ignorert(n): return n=='.DS_Store' or re.fullmatch(r'\.[0-9A-Fa-f-]{36}',n)
tekst=open('CLAUDE.md',encoding='utf-8').read()
blokk=tekst.split('## Mappestruktur',1)[1].split('```')[1]
def navn(l): return nfc(re.split(r'\s{2,}',l.strip())[0].rstrip('/'))
forventet=set(); under={}; sist=None
for l in blokk.splitlines():
    if re.match(r'^  \S',l):
        sist=navn(l); forventet.add(sist)
    elif re.match(r'^    \S',l) and sist:
        under.setdefault(sist,set()).add(navn(l))
avvik=0
def sammenlign(forv,mappe,prefiks):
    global avvik
    fakt={nfc(n) for n in os.listdir(mappe) if not ignorert(n)}
    for n in sorted(forv-fakt): print("MANGLER: "+prefiks+n)
    for n in sorted(fakt-forv): print("EKSTRA: "+prefiks+n)
    avvik+=len((forv-fakt)|(fakt-forv))
sammenlign(forventet,'.','')
for d,filer in sorted(under.items()):
    if os.path.isdir(d): sammenlign(filer,d,d+'/')
print("AVVIK: %d" % avvik)
PY
```
Forventet svar: `AVVIK: 0`. Kontrollen leser mappetreet i `CLAUDE.md` og sammenligner med det
som faktisk ligger i roten. Mapper der treet lister filene (`admin/` og `reference/`)
sammenlignes også fil for fil. En OneDrive-konfliktfil gir for eksempel
«EKSTRA: admin/ACTIVITY-Atles-MacBook-Air.md», se `KOM-I-GANG.md` Del D. `.DS_Store` og
OneDrives markørfil regnes ikke med. Trenger du en ny fil i roten, endres treet i `CLAUDE.md`
først.

### C8 · Ingen placeholders (CLAUDE.md §7)

```
grep -rn --include="*.md" --include="*.sh" --exclude=CLAUDE.md --exclude=checks.md --exclude=kravmatrise-mal.md -e "FYLL INN" -e "<Navn>" -e "<e-post>" -e "<kundenavn>" -e "<casenavn>" -e "<kunde>" -e "<case>" -e "<filnavn" -e "<Legg til" -e "<kort formål" -e "<Rådgivning" -e "<Kundens" -e "<Hva " -e "<Tilbudsfrist" -e "<Kort beskrivelse" -e "Sist oppdatert: YYYY" -e "av <initialer>_" -e "MAL-START" -e "Workspace (mal)" .
```
Forventet svar: ingen treff. `CLAUDE.md`, `checks.md` og `reference/kravmatrise-mal.md`
navngir mønstrene for å definere regelen, kontrollen og malen, og er utelatt. `MAL-START` og
`Workspace (mal)` fanger mal-tekst som er blitt stående i `README.md` og `KOM-I-GANG.md`. I
selve malen er treffene forventet.

### C9 · En bryter per innstilling (CLAUDE.md §4 og §7)

```
grep -rl -e "customer-value-reviewer" -e "compliance-reviewer" -e "review-port" -e "review gate" --include="*.md" --exclude-dir=.claude .
```
Forventet svar: bare `CLAUDE.md` (med eller uten `./` foran). §4 er den eneste som beskriver
review-porten. Filene under `.claude/` er utelatt fordi de beskriver reviewernes egen adferd og
skillen peker til §4. Treffer kommandoen en annen fil, beskriver den porten på nytt, og det er
et avvik.

### C17 · Ingen døde referanser (CLAUDE.md §7)

```
python3 - <<'PY'
import re,io,os,glob,unicodedata
def nfc(t): return unicodedata.normalize('NFC',t)
filer=['CLAUDE.md','README.md','STATUS.md','KOM-I-GANG.md']+glob.glob('admin/*.md')+glob.glob('reference/*.md')+glob.glob('.claude/rules/*.md')+glob.glob('.claude/agents/*.md')+glob.glob('.claude/customer-value/*.md')+glob.glob('.claude/skills/*/SKILL.md')+glob.glob('.claude/checks.md')+glob.glob('.claude/MALENDRINGER.md')
navn=set()
for rot,_,fs in os.walk('.'):
    for f in fs: navn.add(nfc(f))
    navn.add(nfc(os.path.basename(rot)))
doede=[]
for f in filer:
    try: s=io.open(f,encoding='utf-8').read()
    except Exception as e: print("ULEST: %s: %s" % (f,e)); continue
    for m in re.findall(r'`([^`\n]+)`',s):
        if '/' not in m and not m.endswith('.md'): continue
        if m.startswith(('~','http','..','./','grep','find','ls ','for ','wc','TZ=','python','sed','cat','rm','git','npm','mkdir')): continue
        if any(c in m for c in '*"$|<>()') or '...' in m: continue
        sti=m.rstrip('/')
        if os.path.exists(sti) or os.path.exists(os.path.join(os.path.dirname(f),sti)): continue
        if nfc(os.path.basename(sti)) in navn: continue
        doede.append((f,m))
for f,m in doede: print("%s: %s" % (f,m))
print("ANTALL: %d" % len(doede))
PY
```
Forventet svar: `ANTALL: 0`, og ingen `ULEST`-linjer. Kontrollen løser hver referanse mot
roten, mot mappa fila selv står i, og mot filnavn i treet. Filnavn normaliseres til NFC, siden
macOS lagrer æ, ø og å i NFD. En fil som opprettes per case (Leveranser/kravmatrise.md) skrives
uten bakflått, slik at den ikke telles som en referanse i malen.

### C20 · Ingen lang tankestrek (CLAUDE.md §4)

```
python3 - <<'PY'
import io,os
REGEL={'.claude/customer-value/writing-style-core.md','.claude/agents/writing-style-reviewer.md'}
HOPP={'.docx','.pptx','.xlsx','.pdf','.png','.jpg','.jpeg','.zip'}
treff=[]
for rot,mapper,filer in os.walk('.'):
    mapper[:]=[m for m in mapper if m not in ('.git','node_modules')]
    for f in filer:
        if f=='.DS_Store' or os.path.splitext(f)[1].lower() in HOPP: continue
        sti=os.path.relpath(os.path.join(rot,f),'.')
        if sti in REGEL: continue
        try: s=io.open(sti,encoding='utf-8').read()
        except Exception as e: print("ULEST: %s: %s" % (sti,e)); continue
        for n,l in enumerate(s.splitlines(),1):
            if '\u2014' in l: treff.append("%s:%d: %s" % (sti,n,l.strip()[:90]))
for t in treff: print(t)
print("ANTALL: %d" % len(treff))
PY
```
Forventet svar: `ANTALL: 0`, og ingen `ULEST`-linjer. Regelen står i
`.claude/customer-value/writing-style-core.md` og gjelder hele arbeidsflaten. Tegnet søkes som
`\u2014`, så denne fila treffer ikke sin egen kontroll. De to filene som navngir tegnet for å
definere regelen og revieweren, står i `REGEL` og telles ikke. Kontrollen leser hver fil som
tekst i stedet for `grep`, så en OneDrive-plassholder rapporteres som `ULEST` og binære filer
hoppes over på filtype.

### C21 · Taket holder (CLAUDE.md §0)

```
echo "CLAUDE.md: $(wc -w < CLAUDE.md) ord (tak 2000)"
echo "Instruksjonslag: $(find . -name '*.md' -not -path './Customers request/*' -not -path './Meeting notes/*' -not -path './changelog/*' -not -path './Leveranser/*' -print0 | xargs -0 cat | wc -w) ord (tak 12000)"
echo "Aktivt under drafting: $(cat admin/engagement.md admin/rules.md admin/memory.md .claude/customer-value/writing-style-core.md reference/positioning-rules.md reference/best-practices.md .claude/skills/our-approach/SKILL.md | wc -w) ord (tak 3000)"
```
Forventet svar: alle tre tall under taket. Den tredje linjen teller filene i «Aktivt under
drafting» i §4; i en case-kopi kommer kundens dokument i tillegg, og det telles ikke.
