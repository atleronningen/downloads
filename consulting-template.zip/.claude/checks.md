# Kontroller

Kontrollkommandoene for reglene i `CLAUDE.md`. Denne fila inneholder ingen regler. Hver regel
står ett sted, i `CLAUDE.md`, og peker hit med en C-id. Endrer du en regel, endrer du
kontrollen her i samme økt. Fila inneholder heller ingen tilstand: hva en kontroll ga en gitt
dag hører hjemme i `STATUS.md` eller øktsloggen.

Alle kommandoer kjøres fra roten av arbeidsflaten. De er skrevet til å gi samme svar på macOS og
Linux: ingen er avhengige av at `grep` skriver stier med `./`-prefiks, og endringssjekken bruker
`-mtime`, ikke `-newermt`.

**Feilmeldinger undertrykkes aldri.** Filer som ligger som OneDrive-plassholdere og ikke er
lastet ned lokalt, feiler på lesing med «Resource deadlock avoided». En kontroll som kjøres med
`2>/dev/null` teller da en ulest fil som en fil uten treff, og svarer grønt på feil grunnlag.
Ingen kontroll i denne fila kjøres med `2>/dev/null`, og enhver fil som feiler slik rapporteres
som **ulest**, aldri som ren.

Kontrollene er i utgangspunktet skrevet for en kopi av malen som er tatt i bruk. I selve malen
gir C8 treff (malplassholderne), og C13 har ingen logg å lese.

---

### C2 · Rot-regelen («Mappestruktur» i CLAUDE.md)

```
python3 - <<'PY'
import os,re,unicodedata
def nfc(t): return unicodedata.normalize('NFC',t)
def ignorert(n): return n=='.DS_Store' or re.fullmatch(r'\.[0-9A-Fa-f-]{36}',n)
tekst=open('CLAUDE.md',encoding='utf-8').read()
blokk=tekst.split('## Mappestruktur',1)[1].split('```')[1]
forventet=set()
for l in blokk.splitlines():
    if re.match(r'^  \S',l):
        forventet.add(nfc(re.split(r'\s{2,}',l.strip())[0].rstrip('/')))
faktisk={nfc(n) for n in os.listdir('.') if not ignorert(n)}
for n in sorted(forventet-faktisk): print("MANGLER: "+n)
for n in sorted(faktisk-forventet): print("EKSTRA: "+n)
print("AVVIK: %d" % len((forventet-faktisk)|(faktisk-forventet)))
PY
```
Når: ved sesjonsstart og før øktslutt.
Forventet svar: `AVVIK: 0`. Kontrollen leser mappetreet i `CLAUDE.md` og sammenligner med det som
faktisk ligger i roten, punktfiler inkludert. `.DS_Store` og OneDrives markørfil (`.` etterfulgt
av en GUID) regnes ikke med. Trenger du en ny fil i roten, endres treet i `CLAUDE.md` først.

### C3 · Kildehierarkiet peker på noe som finnes (CLAUDE.md §5)

```
for p in "Customers request" admin/ACTIVITY.md STATUS.md admin/engagement.md "Meeting notes" CLAUDE.md; do [ -e "$p" ] || echo "MANGLER: $p"; done
```
Når: ved sesjonsstart.
Forventet svar: ingen utskrift.

### C8 · Ingen placeholders (CLAUDE.md §7)

```
grep -rn --include="*.md" --include="*.sh" --exclude=CLAUDE.md --exclude=checks.md -e "FYLL INN" -e "<Navn>" -e "<e-post>" -e "<kundenavn>" -e "<casenavn>" -e "<Legg til" -e "<kort formål" -e "<Rådgivning" -e "<Kundens" -e "<Hva " -e "<Tilbudsfrist" -e "<Kort beskrivelse" -e "Sist oppdatert: YYYY" -e "MAL-START" -e "Workspace (mal)" .
```
Når: som siste steg i førstegangsoppsettet, og før øktslutt.
Forventet svar: ingen treff. De to filene som navngir mønstrene for å definere regelen og
kontrollen, er utelatt med `--exclude`, slik at kontrollen ikke avhenger av hvordan `grep`
skriver stier. `MAL-START` og `Workspace (mal)` fanger mal-tekst som er blitt stående i
`README.md`. I selve malen er treffene forventet.

### C9 · Én bryter per innstilling (CLAUDE.md §4 og §7)

```
grep -rl "customer-value-reviewer" --include="*.md" --exclude-dir=.claude .
```
Når: når en regel skrives eller endres.
Forventet svar: bare `CLAUDE.md` (med eller uten `./` foran). CLAUDE.md §4 er den eneste som
beskriver review-porten, og filene under `.claude/` er utelatt fordi de beskriver reviewernes
egen adferd. Treffer kommandoen en annen fil, beskriver den porten på nytt med egne ord, og det
er et avvik.

### C10 · Status står i innhold, ikke i filnavn (CLAUDE.md §7)

```
find . \( -iname "*do_not_use*" -o -iname "*_gammel*" -o -iname "*utdatert*" -o -iname "*_old*" \) -print
```
Når: før øktslutt.
Forventet svar: ingen treff.

### C11 · Ingen backup-filer (CLAUDE.md §7)

```
find . \( -iname "*.bak" -o -iname "*backup*" -o -iname "*~" -o -iname "*.orig" -o -iname "*kopi*" \) -print
```
Når: før øktslutt.
Forventet svar: ingen treff. SharePoint og OneDrive holder versjonshistorikk, og en lokal
sikkerhetskopi bryter både rot-regelen og filnavnregelen. Et treff på «Konflikterende kopi fra
...» er en OneDrive-konfliktfil: slå sammen innholdet manuelt og slett duplikatet, se
`KOM-I-GANG.md` Del D. På en konto med engelsk språk heter den «conflicted copy», og fanges ikke
av mønsteret.

### C12 · Få prosjektskills (CLAUDE.md §7)

```
ls -1 .claude/skills/
```
Når: når en skill legges til.
Forventet svar: bare skills som er spesifikke for dette oppdraget, i malen `our-approach`. Et
skript er ikke en skill og ligger i `.claude/scripts/`. En skill som finnes på kontoen brukes
derfra og kopieres aldri hit.

### C13 · Maler har ingen tomme obligatoriske felt (CLAUDE.md §7)

```
f=$(ls -1t changelog/ | head -1); if [ -n "$f" ]; then cat "changelog/$f"; else echo "INGEN LOGG"; fi
```
Når: ved øktslutt.
Forventet svar: ingen feltnavn uten verdi, og ingen rad som beskriver et steg som ikke utføres.
`INGEN LOGG` er riktig svar i en kopi der ingen økt er avsluttet ennå.

### C15 · Tid og endringssjekk (CLAUDE.md §6)

```
TZ=Europe/Oslo date "+%Y-%m-%d %H:%M"
find . -type f -mtime -1
```
Når: ved sesjonsstart, og ved hver skriving av et tidsstempel.
Forventet svar: tidspunktet er Oslo-tid, ikke skallets UTC. Endringssjekken lister filer endret
siste døgn. Er lista tom, kjør samme `find` med `-mtime -30`: gir den treff, er ingenting endret
siste døgn; gir også den tomt, virker ikke kommandoen og det undersøkes før noe konkluderes.

### C17 · Ingen døde referanser (CLAUDE.md §7)

```
python3 - <<'PY'
import re,io,os,glob,unicodedata
def nfc(t): return unicodedata.normalize('NFC',t)
filer=['CLAUDE.md','README.md','STATUS.md','KOM-I-GANG.md']+glob.glob('admin/*.md')+glob.glob('reference/*.md')+glob.glob('.claude/rules/*.md')+glob.glob('.claude/checks.md')
navn=set()
for rot,_,fs in os.walk('.'):
    for f in fs: navn.add(nfc(f))
    navn.add(nfc(os.path.basename(rot)))
doede=[]
for f in filer:
    try: s=io.open(f,encoding='utf-8').read()
    except Exception as e: print("ULEST: %s: %s" % (f,e)); continue
    for m in re.findall(r'`([^`\n]+)`',s):
        if '/' not in m and not m.endswith('.md'): continue
        if m.startswith(('~','http','..','./','grep','find','ls ','for ','wc','TZ=','python','sed','cat','rm','git','npm','mkdir')): continue
        if any(c in m for c in '*"$|<>()') or '...' in m: continue
        sti=m.rstrip('/')
        if os.path.exists(sti) or os.path.exists(os.path.join(os.path.dirname(f),sti)): continue
        if nfc(os.path.basename(sti)) in navn: continue
        doede.append((f,m))
for f,m in doede: print("%s: %s" % (f,m))
print("ANTALL: %d" % len(doede))
PY
```
Når: før øktslutt, og når en fil flyttes eller får nytt navn.
Forventet svar: `ANTALL: 0`, og ingen `ULEST`-linjer. Kontrollen løser hver referanse mot roten,
mot mappa fila selv står i, og mot filnavn i treet. Filnavn normaliseres til NFC før
sammenligning, siden macOS lagrer navn med æ, ø og å i NFD. Et eksempel som ikke peker på en
faktisk fil skrives uten bakflått, slik at det ikke telles som en referanse.

### C18 · Katalogen er komplett (CLAUDE.md §0)

```
echo "i CLAUDE.md:"; grep -oE "\bC[0-9]+\b" CLAUDE.md | sort -u -V | tr '\n' ' '; echo
echo "i checks.md:"; grep -oE "^### (C[0-9]+)" .claude/checks.md | grep -oE "C[0-9]+" | sort -u -V | tr '\n' ' '; echo
```
Når: når en regel eller en kontroll legges til eller fjernes.
Forventet svar: de to listene er identiske. En regel uten C-id skal ikke stå i `CLAUDE.md`, og en
C-id uten regel skal ikke stå her. C-idene er ikke løpende nummerert, og hull er tillatt.

### C19 · Arbeidsflytskissen er fersk (CLAUDE.md §8)

```
python3 .claude/scripts/bygg-arbeidsflyt.py --sjekk
```
Når: ved sesjonsstart, og etter bygget ved øktslutt.
Forventet svar: en linje som begynner med `ferskt` og eksitkode 0. `utdatert` eller `mangler`
(kode 1) betyr at skissen er eldre enn kildene eller ikke finnes: kjør
`python3 .claude/scripts/bygg-arbeidsflyt.py` og deretter kontrollen på nytt. `ULEST` (kode 2)
betyr at en kilde ikke kunne leses, typisk en OneDrive-plassholder som ikke er lastet ned, og
kontrollen svarer ikke før filen er lastet ned. Signaturen dekker mappetreet, skills, agenter,
skript, statusfeltene og malen, ikke tidspunktet.

### C20 · Ingen lang tankestrek (CLAUDE.md §4)

```
python3 - <<'PY'
import io,os
REGEL={'.claude/customer-value/writing-style-core.md','.claude/agents/writing-style-reviewer.md'}
HOPP={'.docx','.pptx','.xlsx','.pdf','.png','.jpg','.jpeg','.zip'}
treff=[]
for rot,mapper,filer in os.walk('.'):
    mapper[:]=[m for m in mapper if m not in ('.git','node_modules')]
    for f in filer:
        if f=='.DS_Store' or os.path.splitext(f)[1].lower() in HOPP: continue
        sti=os.path.relpath(os.path.join(rot,f),'.')
        if sti in REGEL: continue
        try: s=io.open(sti,encoding='utf-8').read()
        except Exception as e: print("ULEST: %s: %s" % (sti,e)); continue
        for n,l in enumerate(s.splitlines(),1):
            if '\u2014' in l: treff.append("%s:%d: %s" % (sti,n,l.strip()[:90]))
for t in treff: print(t)
print("ANTALL: %d" % len(treff))
PY
```
Når: før øktslutt, og når kundevendt innhold er skrevet eller endret.
Forventet svar: `ANTALL: 0`, og ingen `ULEST`-linjer. Regelen står i
`.claude/customer-value/writing-style-core.md` og gjelder hele arbeidsflaten, også `CLAUDE.md`,
alt under `.claude/` og byggeartefaktet `ARBEIDSFLYT.svg`.

Tegnet søkes som `\u2014`, ikke som seg selv, slik at denne fila ikke treffer sin egen kontroll.
Derfor trengs ingen `--exclude` på `checks.md`, slik C8 må ha. De to filene som navngir tegnet
for å definere regelen og for å beskrive reviewerens grep, står i `REGEL` og telles ikke.
Treffer kontrollen en av dem likevel, er det fordi fila har fått en lang tankestrek i vanlig
prosa, og den rettes.

Kontrollen leser hver fil som tekst i stedet for å bruke `grep`, av tre grunner: den gir samme
svar på macOS og Linux uten at skallet må kunne skrive tegnet, den rapporterer en OneDrive-
plassholder som `ULEST` i stedet for å hoppe over den stille, og den hopper over binære
leveransefiler på filtype i stedet for å melde «binary file matches».

Kontrollen er kjørt mot denne fila i samme økt som den ble skrevet, etter regelen i `CLAUDE.md`
§7, både med `REGEL` satt og med `REGEL` tom. Den tomme kjøringen ga fire treff, altså de to
regelfilene, som bekrefter at deteksjonen virker og ikke bare svarer grønt.
