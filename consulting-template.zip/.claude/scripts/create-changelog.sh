#!/usr/bin/env bash
# Oppretter en datostemplet øktslogg i changelog/.
# Tid hentes i Europe/Oslo, aldri fra skallets UTC. Se CLAUDE.md §6.
set -euo pipefail

INITIALER="${1:-}"
if [ -z "$INITIALER" ]; then
  echo "Bruk: .claude/scripts/create-changelog.sh <initialer>"
  exit 1
fi

DATO=$(TZ=Europe/Oslo date "+%Y-%m-%d")
TIDSPUNKT=$(TZ=Europe/Oslo date "+%Y-%m-%d %H:%M")
MAPPE="changelog"
FIL="$MAPPE/${DATO}_${INITIALER}.md"

mkdir -p "$MAPPE"
if [ -e "$FIL" ]; then
  echo "Finnes allerede: $FIL"
  exit 1
fi

cat <<INNHOLD > "$FIL"
# Øktslogg: $DATO ($INITIALER)

- Opprettet: $TIDSPUNKT (Europe/Oslo)
- Konsulent: $INITIALER
- Formål med økten:

## Hva ble utført
-

## Utfordringer og feil oppdaget
-

## Neste steg
-
INNHOLD

echo "Opprettet: $FIL"
