#!/usr/bin/env python3
"""Skriver ARBEIDSFLYT.svg i roten fra arbeidsflyt-mal.svg og filene i arbeidsmappa.

Skissen er et byggeartefakt: den leses og skrives av dette skriptet, aldri for hånd.
Struktur hentes fra mappetreet i CLAUDE.md, skills og agenter fra .claude/, og status fra
filene. Flyten og øktrutinen står i malen. Se CLAUDE.md §8.

  python3 .claude/scripts/bygg-arbeidsflyt.py           bygg, skriver bare når kildene er endret
  python3 .claude/scripts/bygg-arbeidsflyt.py --sjekk   kontroll C19: er skissen fersk?
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import subprocess
import sys
import textwrap
from pathlib import Path
from xml.sax.saxutils import escape

ROT = Path(__file__).resolve().parents[2]
MAL = ROT / ".claude" / "scripts" / "arbeidsflyt-mal.svg"
UT = ROT / "ARBEIDSFLYT.svg"
KOMMANDO = "python3 .claude/scripts/bygg-arbeidsflyt.py"

LILLA = "#4d1d82"
LYSLILLA = "#ede9f2"
GRA = "#a8a8a7"
MORKGRA = "#5b5b5a"
ORANSJE = "#f07d00"
ORANSJE_TEKST = "#b35900"

ULESTE: list[str] = []


# --- lesing ----------------------------------------------------------------

def les(sti: Path) -> str:
    """Leser en tekstfil. En fil som ikke lar seg lese meldes, aldri tolkes som tom."""
    try:
        return sti.read_text(encoding="utf-8")
    except OSError as e:
        melding = "ULEST: %s: %s" % (sti.relative_to(ROT) if sti.is_absolute() else sti, e.strerror)
        if melding not in ULESTE:
            ULESTE.append(melding)
            print(melding, file=sys.stderr)
        return ""


def filer_i(mappe: Path) -> list[Path]:
    """Alle filer under mappa, uten punktfiler som .DS_Store."""
    if not mappe.is_dir():
        return []

    def feil(e: OSError) -> None:
        melding = "ULEST: %s: %s" % (e.filename, e.strerror)
        if melding not in ULESTE:
            ULESTE.append(melding)
            print(melding, file=sys.stderr)

    ut = []
    for rot, mapper, filer in os.walk(mappe, onerror=feil):
        mapper[:] = [m for m in mapper if not m.startswith(".")]
        ut += [Path(rot) / f for f in filer if not f.startswith(".")]
    return sorted(ut)


def frontmatter(tekst: str) -> dict:
    """Enkel lesing av name og description (også foldet med `>`) fra YAML-frontmatter."""
    m = re.match(r"^---\n(.*?)\n---\n", tekst, re.S)
    if not m:
        return {}
    ut: dict = {}
    nokkel = None
    for linje in m.group(1).splitlines():
        kv = re.match(r"^([A-Za-z_-]+):\s*(.*)$", linje)
        if kv and not linje.startswith(" "):
            nokkel = kv.group(1)
            verdi = kv.group(2).strip()
            ut[nokkel] = "" if verdi in (">", "|") else verdi
        elif nokkel:
            ut[nokkel] = (ut[nokkel] + " " + linje.strip()).strip()
    return ut


def forste_setning(tekst: str) -> str:
    tekst = " ".join(tekst.split())
    m = re.match(r"^(.+?[.!?])(\s|$)", tekst)
    return m.group(1) if m else tekst


def kort_ned(tekst: str, n: int) -> str:
    tekst = " ".join(tekst.split())
    if len(tekst) <= n:
        return tekst
    return tekst[: n - 1].rsplit(" ", 1)[0].rstrip(",;:") + "…"


# --- kilder -----------------------------------------------------------------

def les_tre(claude_md: str) -> list[dict]:
    """Mappetreet under «## Mappestruktur», samme lesing som kontroll C2."""
    deler = claude_md.split("## Mappestruktur", 1)
    if len(deler) < 2 or "```" not in deler[1]:
        return []
    blokk = deler[1].split("```")[1]
    ut: list[dict] = []
    for linje in blokk.splitlines():
        if re.match(r"^  \S", linje):
            deler_l = re.split(r"\s{2,}", linje.strip(), maxsplit=1)
            ut.append({"navn": deler_l[0], "tekst": deler_l[1] if len(deler_l) > 1 else "", "under": []})
        elif re.match(r"^    \S", linje) and ut:
            ut[-1]["under"].append(re.split(r"\s{2,}", linje.strip())[0])
    for e in ut:
        e["finnes"] = (ROT / e["navn"].rstrip("/")).exists()
    return ut


def les_skills() -> list[tuple[str, str]]:
    ut = []
    for fil in sorted((ROT / ".claude" / "skills").glob("*/SKILL.md")):
        tekst = les(fil)
        navn = frontmatter(tekst).get("name") or fil.parent.name
        h1 = re.search(r"^# (.+)$", tekst, re.M)
        if h1 and " — " in h1.group(1):
            beskr = h1.group(1).split(" — ", 1)[1]
        elif h1:
            beskr = h1.group(1)
        else:
            beskr = forste_setning(frontmatter(tekst).get("description", ""))
        ut.append((navn, kort_ned(beskr, 110)))
    return ut


def les_agenter() -> list[tuple[str, str]]:
    ut = []
    for fil in sorted((ROT / ".claude" / "agents").glob("*.md")):
        fm = frontmatter(les(fil))
        ut.append((fm.get("name") or fil.stem, kort_ned(forste_setning(fm.get("description", "")), 110)))
    return ut


def les_skript() -> list[tuple[str, str]]:
    ut = []
    for fil in sorted((ROT / ".claude" / "scripts").glob("*")):
        if fil.suffix not in (".py", ".sh"):
            continue
        tekst = les(fil)
        if fil.suffix == ".py":
            m = re.search(r'"""(.+?)(?:\n|""")', tekst)
            beskr = m.group(1) if m else ""
        else:
            kommentarer = [l.lstrip("# ").strip() for l in tekst.splitlines()[1:] if l.startswith("#")]
            beskr = kommentarer[0] if kommentarer else ""
        ut.append((fil.name, kort_ned(beskr.rstrip("."), 110)))
    return ut


def c8_monstre() -> list[str]:
    """Plassholdermønstrene hentes fra kontroll C8, slik at de bare står ett sted."""
    tekst = les(ROT / ".claude" / "checks.md")
    blokk = re.search(r"### C8 ·.*?(?=\n### |\Z)", tekst, re.S)
    monstre = re.findall(r'-e "([^"]+)"', blokk.group(0)) if blokk else []
    if not monstre:
        print("ADVARSEL: fant ingen mønstre i C8 i .claude/checks.md, bruker reservelisten.", file=sys.stderr)
        return ["FYLL INN", "MAL-START"]
    return monstre


def tell_plassholdere(monstre: list[str]) -> dict[str, int]:
    """Samme søk som kontroll C8: .md og .sh, uten CLAUDE.md og checks.md."""
    treff: dict[str, int] = {}
    for rot, mapper, filer in os.walk(ROT):
        mapper[:] = [m for m in mapper if m != ".git"]
        for f in sorted(filer):
            if not f.endswith((".md", ".sh")) or f in ("CLAUDE.md", "checks.md"):
                continue
            sti = Path(rot) / f
            n = sum(1 for l in les(sti).splitlines() if any(m in l for m in monstre))
            if n:
                treff[str(sti.relative_to(ROT))] = n
    return treff


def dato_no(iso: str) -> str:
    return "%s.%s.%s" % (iso[8:10], iso[5:7], iso[0:4])


def samle() -> dict:
    claude_md = les(ROT / "CLAUDE.md")
    monstre = c8_monstre()
    plass = tell_plassholdere(monstre)
    kunde = filer_i(ROT / "Customers request")
    moter = filer_i(ROT / "Meeting notes")
    logger = [f.name for f in filer_i(ROT / "changelog") if f.suffix == ".md"]
    aktivitet = len(re.findall(r"^\[20\d\d-", les(ROT / "admin" / "ACTIVITY.md"), re.M))

    status = les(ROT / "STATUS.md")
    m = re.search(r"Sist oppdatert:\s*(\d{4}-\d{2}-\d{2})", status)
    gjenoppta = re.search(r"^## Hvordan gjenoppta arbeidet\s*\n(.*?)(?=^## |\Z)", status, re.S | re.M)
    gjenoppta_tekst = " ".join(gjenoppta.group(1).split()) if gjenoppta else ""
    if "<" in gjenoppta_tekst:
        gjenoppta_tekst = ""

    eng = les(ROT / "admin" / "engagement.md").splitlines()
    tittel = "Arbeidsflyt: oppdraget er ikke satt opp ennå"
    if eng:
        t = re.match(r"#\s*Engagement:\s*(.+)", eng[0])
        if t and "<" not in t.group(1):
            tittel = "Arbeidsflyt: " + t.group(1).strip().replace(" — ", " – ")

    sist_logg = None
    datoer = sorted(re.match(r"(\d{4}-\d{2}-\d{2})_", n).group(1) for n in logger if re.match(r"\d{4}-\d{2}-\d{2}_", n))
    if datoer:
        sist_logg = datoer[-1]

    if plass:
        fase = 1
    elif not kunde and not moter:
        fase = 2
    else:
        fase = 3

    return {
        "tittel": tittel,
        "tre": les_tre(claude_md),
        "skills": les_skills(),
        "agenter": les_agenter(),
        "skript": les_skript(),
        "plassholdere": plass,
        "antall_plassholdere": sum(plass.values()),
        "kundemateriale": len(kunde),
        "motenotater": len(moter),
        "beslutninger": aktivitet,
        "logger": len(logger),
        "sist_logg": sist_logg,
        "status_dato": m.group(1) if m else None,
        "gjenoppta": gjenoppta_tekst,
        "fase": fase,
    }


def signatur(fakta: dict, mal: str) -> str:
    """Signatur over kildene: fakta fra mappa, malen og dette skriptet selv."""
    skript = Path(__file__).read_text(encoding="utf-8")
    grunnlag = json.dumps(fakta, sort_keys=True, ensure_ascii=False) + "\n" + mal + "\n" + skript
    return hashlib.sha256(grunnlag.encode("utf-8")).hexdigest()[:12]


def oslo_tid() -> tuple[str, str]:
    """Norsk tid, hentet med date og TZ slik CLAUDE.md §6 krever. Returnerer (dd.mm.åååå tt:mm, åååå-mm-dd tt:mm)."""
    env = dict(os.environ, TZ="Europe/Oslo")
    ut = subprocess.run(["date", "+%Y-%m-%d %H:%M"], env=env, check=True, capture_output=True, text=True).stdout.strip()
    return "%s %s" % (dato_no(ut[:10]), ut[11:]), ut


# --- tegning ----------------------------------------------------------------

def esc(t: str) -> str:
    return escape(t, {'"': "&quot;"})


def bryt(tekst: str, bredde: int, maks: int | None = None) -> list[str]:
    linjer = textwrap.wrap(" ".join(tekst.split()), width=bredde, break_long_words=True) or [""]
    if maks and len(linjer) > maks:
        linjer = linjer[:maks]
        linjer[-1] = kort_ned(linjer[-1] + " …", bredde)
    return linjer


def tekst_svg(x: float, y: float, linjer: list[str], klasse: str, lh: int, stil: str = "", anker: str = "") -> str:
    s = ' style="%s"' % stil if stil else ""
    a = ' text-anchor="%s"' % anker if anker else ""
    return "".join(
        '<text x="%s" y="%s" class="%s"%s%s>%s</text>\n' % (x, y + i * lh, klasse, a, s, esc(l))
        for i, l in enumerate(linjer)
    )


def hero(fakta: dict) -> dict:
    fase = fakta["fase"]
    if fase == 1:
        filer = sorted(fakta["plassholdere"].items(), key=lambda kv: -kv[1])[:3]
        liste = ", ".join("%s (%d)" % (f, n) for f, n in filer)
        return {
            "etikett": "DU ER HER · FASE 1 AV 7",
            "navn": "Oppsett",
            "tekst": "%d plassholdere gjenstår i mappa: %s. Oppsettet er ferdig når kontroll C8 gir ingen treff."
            % (fakta["antall_plassholdere"], liste),
            "neste": "Åpne mappa i Cowork og skriv «Nytt oppdrag satt opp for første gang». Claude spør om kundenavn og "
            "casenavn, fyller ut filene og fjerner mal-teksten i README.md.",
        }
    if fase == 2:
        return {
            "etikett": "DU ER HER · FASE 2 AV 7",
            "navn": "Grunnlag",
            "tekst": "Oppsettet er ferdig. Verken Customers request/ eller Meeting notes/ har innhold ennå.",
            "neste": "Legg kundens dokument i Customers request/ og notater fra møter i Meeting notes/ "
            "(filnavn YYYY-MM-DD_kort-tittel.md). Logg frist og åpne spørsmål i STATUS.md.",
        }
    neste = fakta["gjenoppta"] or "STATUS.md sier ikke hva neste steg er ennå. Fyll ut «Hvordan gjenoppta arbeidet»."
    return {
        "etikett": "DU ER HER · FASE 3 TIL 7 AV 7",
        "navn": "Arbeid med tilbudet",
        "tekst": "Oppsett og grunnlag er på plass. Filene kan ikke si om dere er i discovery, tilnærming, utkast, "
        "review eller eksport. Det gjør STATUS.md.",
        "neste": neste,
    }


def fase_stil(i: int, fase: int) -> dict:
    """Utseendet til fase i når filene sier at vi er i fase `fase`."""
    if i < fase and i <= 2:
        tilstand = "ferdig"
    elif i == fase and i <= 2:
        tilstand = "na"
    elif fase >= 3 and i >= 3:
        tilstand = "samtale"
    else:
        tilstand = "senere"
    stiler = {
        "ferdig": dict(KORT_FILL="#ffffff", KORT_STROKE=GRA, KORT_SW="1", SIRKEL_FILL=LILLA, SIRKEL_STROKE=LILLA,
                       TEGN="✓", TEGN_FARGE="#ffffff", TAGG="FERDIG", TAGG_FARGE=LILLA),
        "na": dict(KORT_FILL=LYSLILLA, KORT_STROKE=LILLA, KORT_SW="2", SIRKEL_FILL=LILLA, SIRKEL_STROKE=LILLA,
                   TEGN=str(i), TEGN_FARGE="#ffffff", TAGG="DU ER HER", TAGG_FARGE=ORANSJE_TEKST),
        "samtale": dict(KORT_FILL="#ffffff", KORT_STROKE=GRA, KORT_SW="1", SIRKEL_FILL="#ffffff", SIRKEL_STROKE=LILLA,
                        TEGN=str(i), TEGN_FARGE=LILLA, TAGG="STYRES AV SAMTALEN", TAGG_FARGE=MORKGRA),
        "senere": dict(KORT_FILL="#ffffff", KORT_STROKE=GRA, KORT_SW="1", SIRKEL_FILL="#ffffff", SIRKEL_STROKE=GRA,
                       TEGN=str(i), TEGN_FARGE=MORKGRA, TAGG="", TAGG_FARGE=MORKGRA),
    }
    return stiler[tilstand]


def filer_tekst(n: int) -> str:
    return "Ingen ennå" if not n else ("1 fil" if n == 1 else "%d filer" % n)


def brikker(fakta: dict) -> str:
    ok, obs = LILLA, ORANSJE_TEKST
    plass = fakta["antall_plassholdere"]
    sist = fakta["sist_logg"]
    innhold = [
        ("OPPSETT", "Ferdig" if not plass else "%d plassholdere" % plass, ok if not plass else obs),
        ("KUNDEMATERIALE", filer_tekst(fakta["kundemateriale"]),
         ok if fakta["kundemateriale"] else obs),
        ("MØTENOTATER", filer_tekst(fakta["motenotater"]),
         ok if fakta["motenotater"] else obs),
        ("BESLUTNINGER LOGGET", str(fakta["beslutninger"]), ok),
        ("ØKTSLOGGER", ("%d, sist %s" % (fakta["logger"], dato_no(sist)[:5])) if sist else "Ingen ennå",
         ok if sist else obs),
        ("STATUS SIST OPPDATERT", dato_no(fakta["status_dato"]) if fakta["status_dato"] else "Ikke satt",
         ok if fakta["status_dato"] else obs),
    ]
    ut = ""
    for i, (etikett, verdi, farge) in enumerate(innhold):
        x = 84 + i * 187
        ut += '<rect x="%d" y="316" width="175" height="48" rx="6" fill="#ffffff" stroke="%s" stroke-width="1"/>\n' % (x, GRA)
        ut += '<text x="%d" y="334" class="xs">%s</text>\n' % (x + 12, esc(etikett))
        ut += '<text x="%d" y="354" class="t3" style="fill:%s">%s</text>\n' % (x + 12, farge, esc(verdi))
    return ut


def mappekort(tre: list[dict], y0: int) -> tuple[str, int]:
    """To kolonner med ett kort per element i mappetreet. Returnerer (svg, ny y)."""
    kolonne_x = (60, 650)
    bredde = 570
    ut = ""
    y = y0
    for start in range(0, len(tre), 2):
        par = tre[start : start + 2]
        oppsett = []
        for e in par:
            beskr = bryt(e["tekst"], 78) if e["tekst"] else []
            under = bryt(" · ".join(e["under"]), 74) if e["under"] else []
            h = 26 + (14 + 17 * len(beskr) if beskr else 0) + (10 + 16 * len(under) if under else 0) + 16
            oppsett.append((e, beskr, under, max(h, 60)))
        rad_h = max(o[3] for o in oppsett)
        for k, (e, beskr, under, _) in enumerate(oppsett):
            x = kolonne_x[k]
            mangler = not e["finnes"]
            ut += '<rect x="%d" y="%d" width="%d" height="%d" rx="8" fill="#ffffff" stroke="%s" stroke-width="%s"%s/>\n' % (
                x, y, bredde, rad_h, ORANSJE if mangler else GRA, "1.5" if mangler else "1",
                ' stroke-dasharray="6 4"' if mangler else "")
            ut += tekst_svg(x + 16, y + 26, [e["navn"]], "mb", 0)
            if mangler:
                ut += tekst_svg(x + bredde - 16, y + 26, ["FINNES IKKE ENNÅ"], "xs", 0, "fill:%s" % ORANSJE_TEKST, "end")
            yy = y + 26 + 20
            if beskr:
                ut += tekst_svg(x + 16, yy, beskr, "g", 17)
                yy += 17 * len(beskr) - 3
            if under:
                ut += tekst_svg(x + 16, yy + 14, under, "m", 16, "fill:%s" % MORKGRA)
        y += rad_h + 12
    return ut, y


def skillsliste(fakta: dict, y0: int) -> tuple[str, int]:
    grupper = [("SKILLS", fakta["skills"]), ("AGENTER", fakta["agenter"]), ("SKRIPT", fakta["skript"])]
    grupper = [(n, l) for n, l in grupper if l]
    h = 16 + sum(30 + 24 * len(l) for _, l in grupper) + 8
    ut = '<rect x="60" y="%d" width="1160" height="%d" rx="8" fill="#ffffff" stroke="%s" stroke-width="1"/>\n' % (y0, h, GRA)
    y = y0 + 32
    for navn, liste in grupper:
        ut += tekst_svg(80, y, [navn], "xs", 0)
        y += 24
        for n, beskr in liste:
            ut += tekst_svg(80, y, [n], "mb", 0)
            ut += tekst_svg(350, y, [beskr], "g", 0)
            y += 24
        y += 6
    return ut, y0 + h


def dynamisk(fakta: dict) -> tuple[str, int]:
    y = 1314
    ut = tekst_svg(60, y, ["MAPPESTRUKTUR"], "lbl", 0)
    ut += tekst_svg(60, y + 20, ["Hentet fra treet i CLAUDE.md. Rot-regelen: ingen andre filer eller mapper i roten. Stiplet kort finnes i treet, men ikke på disk."], "sm", 0)
    kort, y = mappekort(fakta["tre"], y + 36)
    y += 22
    ut += kort
    ut += tekst_svg(60, y, ["SKILLS, AGENTER OG SKRIPT"], "lbl", 0)
    ut += tekst_svg(60, y + 20, ["Hentet fra .claude/. En ny skill, agent eller et nytt skript vises her ved neste bygg."], "sm", 0)
    liste, y = skillsliste(fakta, y + 36)
    ut += liste
    y += 40
    ut += '<line x1="60" y1="%d" x2="1220" y2="%d" stroke="%s" stroke-width="1"/>\n' % (y - 16, y - 16, GRA)
    fot = [
        "Denne skissen er et byggeartefakt. Den skrives av .claude/scripts/bygg-arbeidsflyt.py fra arbeidsflyt-mal.svg og filene i mappa. Rediger den aldri for hånd.",
        "Mappestrukturen hentes fra CLAUDE.md, og endres der først. Endres flyten, øktrutinen eller review-porten, endres malen i samme omgang.",
        "Tall, status og «Du er her» fylles av skriptet. Kontroll C19 feiler når skissen er eldre enn kildene.",
    ]
    ut += tekst_svg(60, y, fot, "sm", 18)
    return ut, y + 18 * len(fot) + 22


def bygg_svg(fakta: dict, mal: str, sig: str) -> str:
    h = hero(fakta)
    dyn, hoyde = dynamisk(fakta)
    visning, stempel = oslo_tid()
    felt = {
        "HOYDE": str(hoyde),
        "ARIA": esc("%s. %s: %s. Neste steg: %s" % (fakta["tittel"], h["etikett"], h["navn"], h["neste"])),
        "SIGNATUR": sig,
        "TIDSPUNKT": stempel + " Europe/Oslo",
        "TITTEL": esc(fakta["tittel"]),
        "UNDERTITTEL": esc("Bygget %s (Oslo) · kildesignatur %s · byggeartefakt, rediger aldri for hånd" % (visning, sig)),
        "FASE_ETIKETT": esc(h["etikett"]),
        "FASE_NAVN": esc(h["navn"]),
        "FASE_TEKST_SVG": tekst_svg(84, 250, bryt(h["tekst"], 68, 3), "g", 19),
        "NESTE_STEG_SVG": tekst_svg(664, 220, bryt(h["neste"], 62, 4), "t3", 21, "font-size:14px;font-weight:400"),
        "BRIKKER_SVG": brikker(fakta),
        "DYNAMISK_SVG": dyn,
    }
    for i in range(1, 8):
        for k, v in fase_stil(i, fakta["fase"]).items():
            felt["F%d_%s" % (i, k)] = esc(v)
    svg = mal
    for k, v in felt.items():
        svg = svg.replace("__%s__" % k, v)
    igjen = sorted(set(re.findall(r"__[A-Z0-9_]+__", svg)))
    if igjen:
        raise SystemExit("FEIL: ufylte plassholdere i malen: %s" % ", ".join(igjen))
    return svg


# --- kommandoer --------------------------------------------------------------

def gjeldende_signatur(svg: str) -> str | None:
    m = re.search(r"BYGGESTEMPEL ([0-9a-f]{12})", svg)
    return m.group(1) if m else None


def main(argv: list[str]) -> int:
    if not MAL.exists():
        print("FEIL: fant ikke %s" % MAL.relative_to(ROT), file=sys.stderr)
        return 3
    mal = les(MAL)
    fakta = samle()
    sig = signatur(fakta, mal)
    eksisterende = les(UT) if UT.exists() else ""
    gjeldende = gjeldende_signatur(eksisterende)

    if "--sjekk" in argv:
        if ULESTE:
            print("ULEST: %d filer kunne ikke leses. Kontrollen kan ikke svare." % len(ULESTE))
            return 2
        if not UT.exists():
            print("mangler: ARBEIDSFLYT.svg finnes ikke. Kjør: %s" % KOMMANDO)
            return 1
        if gjeldende != sig:
            print("utdatert: ARBEIDSFLYT.svg er bygget på eldre kilder (%s, nå %s). Kjør: %s" % (gjeldende, sig, KOMMANDO))
            return 1
        print("ferskt: ARBEIDSFLYT.svg stemmer med kildene (signatur %s)" % sig)
        return 0

    if ULESTE:
        print("Avbrutt: %d filer kunne ikke leses, så skissen er ikke skrevet." % len(ULESTE), file=sys.stderr)
        return 2
    if gjeldende == sig:
        print("Uendret: ARBEIDSFLYT.svg er fersk (signatur %s). Ingenting skrevet." % sig)
        return 0
    svg = bygg_svg(fakta, mal, sig)
    tmp = ROT / ".ARBEIDSFLYT.svg.tmp"
    tmp.write_text(svg, encoding="utf-8")
    os.replace(tmp, UT)
    print("Skrev ARBEIDSFLYT.svg (fase %d, signatur %s)" % (fakta["fase"], sig))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
