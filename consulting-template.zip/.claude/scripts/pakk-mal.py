#!/usr/bin/env python3
"""Pakker malen til en zip-fil for deling, uten macOS- og OneDrive-filer.

Brukes i selve malen, ikke i en case-kopi. Kjøres fra roten:
    python3 .claude/scripts/pakk-mal.py <sti-til-zip>
Zip-fila må ligge utenfor malmappa (rot-regelen i CLAUDE.md). Innholdet legges rett i roten
av zip-fila, tomme mapper inkludert, slik at utpakking gir én mappe både på macOS og Windows.
"""
import os
import re
import sys
import zipfile

ROT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))


def utelatt(navn: str) -> bool:
    return (navn == ".DS_Store" or navn.startswith("._") or navn == "Icon\r"
            or re.fullmatch(r"\.[0-9A-Fa-f-]{36}", navn) is not None)


def main() -> int:
    if len(sys.argv) != 2:
        print("Bruk: python3 .claude/scripts/pakk-mal.py <sti-til-zip>")
        return 1
    ut = os.path.abspath(sys.argv[1])
    if ut == ROT or ut.startswith(ROT + os.sep):
        print("Zip-fila må ligge utenfor malmappa: %s" % ROT)
        return 1
    if os.path.exists(ut):
        print("Finnes allerede: %s" % ut)
        return 1
    antall = 0
    with zipfile.ZipFile(ut, "w", zipfile.ZIP_DEFLATED) as z:
        for rot, mapper, filer in os.walk(ROT):
            mapper[:] = sorted(m for m in mapper if not utelatt(m) and m != ".git")
            rel = os.path.relpath(rot, ROT)
            arkiv = "" if rel == "." else rel
            if arkiv:
                z.writestr(arkiv + "/", "")
            for f in sorted(filer):
                if utelatt(f):
                    continue
                z.write(os.path.join(rot, f), os.path.join(arkiv, f))
                antall += 1
    print("Opprettet: %s (%d filer)" % (ut, antall))
    return 0


if __name__ == "__main__":
    sys.exit(main())
