# Writing Style Core - Shared Rules

Shared rules used by every project's own `.claude/rules/writing-style.md`. This file holds
the rules themselves; each project's own file adds only its own project-specific example.

> **Selvstendig kopi.** Dette er malens egen versjon av de delte skrivereglene. Malen er
> bygget for å fungere frittstående når den deles videre, uten noen annen mappe montert.
> Vedlikeholder du en sentral samling av slike regler et annet sted, synker du endringer inn
> hit manuelt etter eget behov.

## No negative-contrast framing (via negativa)

Avoid defining goals, positioning, or the target state by what we aren't doing or by
contrasting against the old/current state. Reframe all negative contrast into positive,
assertive statements.

- Eliminate "not X, but Y" framing entirely.
- Don't position a new service, capability, or target state against outdated tools, legacy
  platforms, or "the old way." Describe it entirely on its own terms.
- Focus entirely on affirmative positioning: tell the reader what the thing *is* and
  *offers*, rather than what it replaces or moves away from.
- Tone should be purely visionary and forward-looking, not comparative or corrective.
- This applies even when the underlying substance involves a technology or operating-model
  transition, so describe the destination, not the departure.

### Shared example

Bad (via negativa): "A chance to launch the new site on a workplace built for how people
want to work today, not a copy of the old one."

Good (visionary, affirmative): "A chance to launch the new site on a workplace designed
around how people want to work today: mobile, collaborative, and simple to support."

## No AI-cliché vocabulary

Avoid vocabulary that reads as generated rather than written by someone with something
specific to say. When a plain, direct word says the same thing, use it instead of a word that
has become a marker of AI-written text, even where it is technically accurate.

Flagged words, growing as new instances come up:

- **shape** used as a verb, for example "two contexts shape the assessment". Replace it with a
  direct verb ("changes", "sets", "decides"), rebuild the sentence around the noun, or cut it
  and let the heading stand alone ("Two service contexts").
- **dive into**, **unleash**, **game-changing**. Generic AI-marketing language. State what the
  thing actually does instead.

## Dashes

Norwegian text follows Språkrådet's rules for tankestrek:
https://sprakradet.no/godt-og-korrekt-sprak/rettskriving-og-grammatikk/tegn/tankestrek/

- Always the short dash (–), never the long dash (—).
- Spaced dash for a parenthetical addition or insertion: "Pettersen – som var førti år –
  hadde arbeidet i firmaet siden 1992."
- Unspaced dash for "fra … til" or "mellom … og": "08–16", "1. mai–10. september",
  "Oslo–Bergen".
- Dash before direct speech (replikkstrek).
- Never as a stand-in for a comma, a colon, or a parenthesis.

English text follows British English convention:

- Use the en dash (–), not the em dash (—).
- Spaced en dash for a parenthetical aside: "DIO – the Norwegian body responsible for the
  shared IT platform – has opened a market dialogue."
- Unspaced en dash for ranges: "9–5", "2020–2024", "pages 12–18".

Hyphens (-) are unaffected in both languages: use them for compound words as normal
("Microsoft 365-tjenester", "it-konsulent", "well-known").

**Where this applies:** everywhere in this workspace, including customer-facing
deliverables, engagement documentation, and workspace instruction and configuration files
(`CLAUDE.md`, anything under `.claude/`, skill and agent definitions). No file type is
exempt.

Material quoted verbatim from a customer or another source keeps its original punctuation,
dashes included, even where the original doesn't follow this rule.

### Shared examples

Norwegian, parenthetical: "DIO – den norske etaten med ansvar for den felles
IT-plattformen – har åpnet en markedsdialog."

Norwegian, range: "Fristen løper 1. mai–10. september."

English, parenthetical: "DIO – the Norwegian body responsible for the shared IT
platform – has opened a market dialogue."

English, range: "The pilot runs Q1–Q3 2027."

### Relationship to the sopra-steria-korrektur skill

The `sopra-steria-korrektur` skill's dash rule (long dash banned, short dash allowed for
tankestrek) now matches this rule for Norwegian text. This rule additionally covers English
text (British English convention) and applies workspace-wide rather than only to
customer-facing output.

## Norwegian text: run sopra-steria-korrektur automatically

When drafting or revising Norwegian text in this workspace, apply the
`sopra-steria-korrektur` skill automatically, without waiting to be asked. This matters most
for customer-facing deliverables whenever the customer's own material is Norwegian.
