# Writing Style Core - Shared Rules

The single home for every writing rule in this workspace. No other file (skill, agent,
`CLAUDE.md`) restates a writing rule; they point here. The `writing-style-reviewer` agent
checks deliverables against this file.

> **Selvstendig kopi.** Dette er malens egen versjon av de delte skrivereglene. Malen er
> bygget for å fungere frittstående når den deles videre, uten noen annen mappe montert.
> Vedlikeholder du en sentral samling av slike regler et annet sted, synker du endringer inn
> hit manuelt etter eget behov.

## Affirmative framing

Define goals, positioning and the target state by what they are and offer. Describe the
destination on its own terms, also when the substance is a transition away from something.
Write the statement as a direct claim; drop the half of the sentence that names what it is
not, what it replaces, or what came before.

### Shared example

Weak: "A chance to launch the new site on a workplace built for how people want to work today,
not a copy of the old one."

Strong: "A chance to launch the new site on a workplace designed around how people want to
work today: mobile, collaborative, and simple to support."

## Plain vocabulary

Use the direct word. The list below holds words that mark text as generated or as consulting
boilerplate; when one appears, state what the thing actually does instead. The list grows as
new instances come up, and this is the only list in the workspace.

- **shape** used as a verb ("two contexts shape the assessment"). Use "changes", "sets",
  "decides", or rebuild the sentence around the noun.
- **dive into**, **unleash**, **game-changing**, **transformative**, **unlock**.
- **synergies**, **leverage** / **leveraging**, **paradigm shift**, **drive** (as in "drive
  outcomes").

### Shared example

Weak: "We leverage our synergies to unlock transformative outcomes and drive a paradigm shift in
how you work."

Strong: "We combine our AI and workplace teams to cut rollout time from six months to eight
weeks."

## Voice

Confident and specific. Write "We deliver", "We transformed X". Lead with the business and
human impact, then the technology. Use numbers, outcomes and the customer's own sector
language.

## Dashes

Norwegian text follows Språkrådet's rules for tankestrek:
https://sprakradet.no/godt-og-korrekt-sprak/rettskriving-og-grammatikk/tegn/tankestrek/

- Always the short dash (–), never the long dash (—).
- Spaced dash for a parenthetical addition or insertion: "Pettersen – som var førti år –
  hadde arbeidet i firmaet siden 1992."
- Unspaced dash for "fra … til" or "mellom … og": "08–16", "1. mai–10. september",
  "Oslo–Bergen".
- Dash before direct speech (replikkstrek).
- A comma, a colon or a parenthesis is written as itself; the dash does not stand in for them.

English text follows British English convention:

- Use the en dash (–), not the em dash (—).
- Spaced en dash for a parenthetical aside: "DIO – the Norwegian body responsible for the
  shared IT platform – has opened a market dialogue."
- Unspaced en dash for ranges: "9–5", "2020–2024", "pages 12–18".

Hyphens (-) are unaffected in both languages: use them for compound words as normal
("Microsoft 365-tjenester", "it-konsulent", "well-known").

**Where this applies:** everywhere in this workspace, including customer-facing
deliverables, engagement documentation, and workspace instruction and configuration files
(`CLAUDE.md`, anything under `.claude/`, skill and agent definitions). No file type is
exempt. Control C20 in `.claude/checks.md` finds the long dash mechanically.

Material quoted verbatim from a customer or another source keeps its original punctuation,
dashes included.

### Shared examples

Norwegian, parenthetical: "DIO – den norske etaten med ansvar for den felles
IT-plattformen – har åpnet en markedsdialog."

Norwegian, range: "Fristen løper 1. mai–10. september."

English, parenthetical: "DIO – the Norwegian body responsible for the shared IT
platform – has opened a market dialogue."

English, range: "The pilot runs Q1–Q3 2027."

## Norwegian terminology

- Use "Leveranser:" as the label for phase outputs in slides and documents.

## Norwegian text: run sopra-steria-korrektur automatically

When drafting or revising Norwegian text in this workspace, apply the
`sopra-steria-korrektur` skill automatically, without waiting to be asked. This matters most
for customer-facing deliverables whenever the customer's own material is Norwegian. Its dash
rule matches the rule above for Norwegian text.
