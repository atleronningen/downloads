# Customer Value - Review Criteria

Shared criteria used by the `customer-value-reviewer` agent. This file holds *what* to check.
The lens (RFI-compliance vs. service-positioning) comes from `admin/engagement.md` and
`admin/memory.md`, not from here.

> **Selvstendig kopi.** Dette er malens egen versjon av sjekklisten. Malen er bygget for å
> fungere frittstående når den deles videre, uten noen annen mappe montert. Vedlikeholder du
> en sentral samling av slike regler et annet sted, synker du endringer inn hit manuelt etter
> eget behov.

## What this agent is for

Challenge whether a deliverable (RFI response, service description, consulting deck,
one-pager) actually creates value for the customer. Completeness against the customer's
requirements is the `compliance-reviewer`'s job; polish is the `writing-style-reviewer`'s job.
This agent asks: would the customer's decision-maker read this and see something built for
them, or something generic that could go to anyone?

## Checks to run

For each deliverable under review:

1. **Traced to a specific pain point.** Every value claim ties to something concrete about
   this customer: a stated problem, a scale figure, an industry pattern. A capability
   statement that could apply to any customer fails this check.
2. **Win themes are adapted.** Cross-check against «Vinnertemaer» in `admin/memory.md`. A
   theme can be reused when its framing is adapted to this customer's specific situation.
3. **Claims are grounded in real sources.** Every product/service/customer claim traces to a
   source that's authoritative in this workspace: the customer's own material in
   `Customers request/`, what was said in `Meeting notes/`, scope and contacts in
   `admin/engagement.md`, or verified web or annual-report research the user has seen. Flag
   anything that sounds plausible and has no traceable source.
4. **Answers "so what."** Every section states what the claim means for the customer's
   business outcome, in addition to what Sopra Steria offers.
5. **Scope and commercial claims are realistic.** No commitments beyond what's actually known
   about the customer or explicitly provided by the user (pricing, timelines, staffing).
6. **Advisory.** The deliverable recommends a path, beyond answering the literal question
   asked.
7. **Differentiated.** Could a competent competitor submit this exact text with their own logo
   on it? If yes, it hasn't cleared the bar.

## How to review

- Read `admin/engagement.md`, `admin/memory.md` and, if present, Leveranser/kravmatrise.md
  first: they define the lens and the reference material to check claims against.
- Review the exported or final text only. The drafting conversation is never evidence.
- Go section by section. For each section that fails a check, name the check, quote the exact
  line, and state what's missing. Leave the rewriting to the drafting skill.
- End with a short verdict. A rubber-stamp review defeats the purpose of having this agent.

## Output format

```
## Customer Value Review - <deliverable name>

### Verdict: [ship as-is / ship with fixes / not ready]

### Findings
- [Section/line] - [check failed] - [quote] - [what's missing]
- ...

### What's working
- [one or two things genuinely strong]
```
