# Compliance - Review Criteria

Shared criteria used by the `compliance-reviewer` agent. This file holds *what* to check:
whether the deliverable answers what the customer actually asked for, where and how the
customer asked for it. Value is the `customer-value-reviewer`'s job; style is the
`writing-style-reviewer`'s job.

> **Selvstendig kopi.** Dette er malens egen versjon av sjekklisten. Malen er bygget for å
> fungere frittstående når den deles videre, uten noen annen mappe montert. Vedlikeholder du
> en sentral samling av slike regler et annet sted, synker du endringer inn hit manuelt etter
> eget behov.

## Inputs

- The customer's own document in `Customers request/`.
- Leveranser/kravmatrise.md (the requirements matrix). If it does not exist, stop and report
  that: this review cannot run without it.
- `admin/engagement.md` (deadline, scope, contacts) and «Kundens begreper» in
  `admin/memory.md`.
- The exported or final deliverable text. The drafting conversation is never evidence.

## Checks to run

1. **Every requirement answered.** Every row in the matrix typed skal or bør has an answer in
   the deliverable. Count matrix rows with a command
   (`grep -c "^| K[0-9]" Leveranser/kravmatrise.md`), never by reading. Quote every unanswered
   id.
2. **Answered where the customer asked for it.** The answer sits in the section, form or
   field the customer's document specifies. An answer placed elsewhere is a finding.
3. **The customer's terms.** Where «Kundens begreper» lists the customer's word, the
   deliverable uses it. Our internal term in a customer-facing line is a finding.
4. **Format and limits.** Page limits, file formats, language, mandatory attachments and
   submission channel match the customer's document.
5. **Deadline stated correctly.** The deadline in `admin/engagement.md`, in the matrix and in
   the deliverable are the same.
6. **Nothing promised beyond the matrix.** Commercial or scope statements that trace neither
   to a requirement nor to `admin/engagement.md` are flagged. This overlaps check 5 in
   `criteria.md` on purpose: two reviewers, two angles.

## How to review

- Read the inputs above first. Then go requirement by requirement through the matrix, and
  section by section through the deliverable.
- For each finding, name the check, quote the exact line (or the unanswered requirement id),
  and state what is missing. Leave the rewriting to the drafting skill.
- End with a short verdict.

## Output format

```
## Compliance Review - <deliverable name>

### Verdict: [ship as-is / ship with fixes / not ready]

### Requirements: <answered> of <total> (counted by command)

### Findings
- [Requirement id or section] - [check failed] - [quote] - [what's missing]
- ...

### What's working
- [what is fully covered]
```
