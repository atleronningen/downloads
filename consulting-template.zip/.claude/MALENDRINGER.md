# Malendringer

Versjonslogg for selve malen `consulting-template`. Gjeldende versjon står i `CLAUDE.md` §0.
Nyeste versjon øverst. Arbeid i en case-kopi logges i casens egne filer.

## 1.1 · 2026-09-23 (AR)

- Word-malen er fjernet. Ny mappe `Leveranser/` for eksporterte filer.
- Eksporten i `our-approach` går til PowerPoint med skillene `pptx` og `sopra-steria-brand`.
- Øktslogger har klokkeslett i filnavnet, så flere økter samme dag fungerer.
- C2 sjekker også `admin/` fil for fil, og fanger OneDrive-konfliktfiler der. C11 hopper over
  `Customers request/`. C8 fanger en dato i `STATUS.md` som står uten initialer.
- `writing-style-reviewer` sjekker også AI-klisjeer.
- Reviewkriteriene viser bare til kilder som finnes i arbeidsflaten. Ny seksjon «Vinnertemaer»
  i `admin/memory.md`, og norske overskrifter der.
- Ny seksjon om kundedata i `.claude/rules/safety-rules.md`.
- Del A0 i `KOM-I-GANG.md` er mal-tekst og fjernes i case-kopier. Startfrasen nevner `CLAUDE.md`.
- Nytt skript `.claude/scripts/pakk-mal.py` lager zip-fila uten macOS- og OneDrive-filer.

## 1.0

- Første versjon, utviklet av AR og MH.
