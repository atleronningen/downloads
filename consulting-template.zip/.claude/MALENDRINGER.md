# Malendringer

Versjonslogg for selve malen `consulting-template`. Gjeldende versjon står i `CLAUDE.md` §0.
Nyeste versjon øverst. Arbeid i en case-kopi logges i casens egne filer.

## Vedlikehold

Hvert kvartal, av maleieren, i selve malen:

1. Kjør C2, C9, C17 og C21 fra `.claude/checks.md`. Alle skal gi forventet svar.
2. Gå gjennom pågående caser og noter hvilke lokale endringer i `CLAUDE.md`, agenter eller
   memory som bør inn i malen.
3. Skal noe legges til over taket i `CLAUDE.md` §0, fjernes noe først, og begge deler står i
   samme oppføring under.

Hver oppføring i versjonsloggen avsluttes med «Gjelder pågående caser: ja/nei», siden
case-kopier er selvstendige og ikke synker fra malen.

## 1.2 · 2026-09-25 (MH)

Formål: malen skal holde over tid med skiftende brukere, og kundens materiale skal inn i
arbeidsrutinen. Instruksjonslaget aktivt under drafting gikk fra 5 176 til under 3 000 ord.

Fjernet:
- Arbeidsflytskissen `ARBEIDSFLYT.svg` med skript, mal, §8 og C19. Den beregnet fase fra
  mappeinnhold i strid med `STATUS.md`, og måtte endres hver gang `CLAUDE.md` eller `.claude/`
  endret form.
- Kontrollene C3, C10, C11, C12, C13, C15, C18, og reglene «hver regel har en kontroll» og
  «hver kontroll testes mot seg selv». Ingen kontroller ved sesjonsstart; C8 og C20 ved
  øktslutt når kundevendt innhold ble skrevet.
- Gjenfortellinger: loggformatet står bare i skriptet, review-porten bare i §4, kjøremåte bare
  i §4, tankestrekregelen bare i `writing-style-core.md`, konfliktfiler bare i
  `KOM-I-GANG.md` Del D, leserekkefølge bare i §1.
- Fila .claude/rules/writing-style.md. Eksempelet er flyttet inn i `writing-style-core.md`.
- Statusseksjonen i `admin/engagement.md`, «Scope og beslutninger» i `STATUS.md`, feltet
  «Neste steg» i øktsloggen. Hvert lag har en jobb.
- Førstegangsoppsettet er flyttet fra `CLAUDE.md` til `KOM-I-GANG.md` Del A0, og trigges av
  placeholders i `STATUS.md`, ikke av en frase.
- Fra `SKILL.md`: brand-voice-regler skrevet som «X, not Y», egen ordliste, verktøyspesifikke
  forbud.

Lagt til:
- §1 lister `Customers request/` og `Meeting notes/` ved hver start og varsler når noe er nyere
  enn `STATUS.md` eller et kundedokument mangler kravmatrise.
- Kravmatrise (`reference/kravmatrise-mal.md`, opprettes som Leveranser/kravmatrise.md) med
  mekanisk radtelling.
- Tredje reviewer `compliance-reviewer` med sjekkliste i `.claude/customer-value/compliance.md`.
- Destillering av møtenotater samme økt (§4).
- Seksjonen «Kundens begreper» i `admin/memory.md`.
- Skillen skriver bekreftet discovery til `admin/engagement.md`, og stopper hvis `pptx` eller
  `sopra-steria-brand` mangler.
- Reviewerne leser engagement, memory og kravmatrise, ikke `CLAUDE.md`, og bare ferdig tekst.
- Liste «Aktivt under drafting» i §4, tak på 3 000 ord og 30 regler.
- Tak på `CLAUDE.md` (2 000 ord) og instruksjonslaget (12 000 ord), kontroll C21.
- Denne vedlikeholdsseksjonen.

Gjelder pågående caser: ja. §1, §2, §4, reviewerne og `SKILL.md` anbefales portert; resten
valgfritt.

## 1.1 · 2026-09-23 (AR)

- Word-malen er fjernet. Ny mappe `Leveranser/` for eksporterte filer.
- Eksporten i `our-approach` går til PowerPoint med skillene `pptx` og `sopra-steria-brand`.
- Øktslogger har klokkeslett i filnavnet, så flere økter samme dag fungerer.
- C2 sjekker også `admin/` fil for fil, og fanger OneDrive-konfliktfiler der. C11 hopper over
  `Customers request/`. C8 fanger en dato i `STATUS.md` som står uten initialer.
- `writing-style-reviewer` sjekker også AI-klisjeer.
- Reviewkriteriene viser bare til kilder som finnes i arbeidsflaten. Ny seksjon «Vinnertemaer»
  i `admin/memory.md`, og norske overskrifter der.
- Ny seksjon om kundedata i `.claude/rules/safety-rules.md`.
- Del A0 i `KOM-I-GANG.md` er mal-tekst og fjernes i case-kopier.
- Nytt skript `.claude/scripts/pakk-mal.py` lager zip-fila uten macOS- og OneDrive-filer.

## 1.0

- Første versjon, utviklet av AR og MH.
