# <FYLL INN: mappens navn>

Instruksjonsfil for denne mappen. Claude leser den automatisk ved starten av hver økt, både i
Claude Cowork og i Claude Code. De fire `<FYLL INN>`-feltene fylles ut første gang mappen tas i
bruk, enten av brukeren direkte eller av Claude i et kort intervju. Se under.

## Oppstart uten utfylte felt

Har dette dokumentet fortsatt uutfylte `<FYLL INN>`-felt når økten starter: ikke gå videre til
resten av denne filen ennå, og ikke be brukeren åpne og redigere `CLAUDE.md` selv. Intervju dem
i stedet, ett spørsmål av gangen, og vent på svar før du går videre til neste:

1. Hva skal mappen hete? Blir overskriften øverst i denne filen.
2. Hva slags leveranse produseres her? Be om én til tre setninger.
3. Hvilke kilder er autoritative for faktapåstander her? Dette er det viktigste spørsmålet:
   `customer-value-reviewer` bruker svaret aktivt, og melder fra når en påstand ikke kan
   spores til noe som er listet her.
4. Norsk eller engelsk som standard språk?

Skriv hvert svar rett inn i feltet det hører til mens du går, ikke som en samlet oppsummering
til slutt. Spør også om `.claude/skills/utkast-og-review/SKILL.md` skal tilpasses til
brukerens leveransetype nå, eller om det kan vente til senere.

Når alle fire felt er fylt ut: bekreft kort hva som er satt, nevn forutsetningen om
`sopra-steria-korrektur` under, og fortell at neste steg er å opprette den første saken (se
`KOM-I-GANG.md`).

Er feltene allerede utfylt, hopp over dette intervjuet og gå rett til neste avsnitt.

## Hva denne mappen produserer

<FYLL INN: hvilken type leveranse som lages her, for eksempel tilbudssvar på RFI, tjenestebeskrivelser,
kundepresentasjoner, referansesaker. Én til tre setninger.>

**Kilder som er autoritative her:** <FYLL INN: hvor faktapåstander skal hentes fra, for eksempel en
tjenestekatalog, en kontraktsmal, kundens egne intervjusvar, verifisert nettresearch. Dette
punktet leses av `customer-value-reviewer`, som melder fra hvis en påstand ikke kan spores til
en av kildene du lister her.>

**Språk:** <FYLL INN: norsk eller engelsk som standard.>

## Forutsetninger

`sopra-steria-korrektur` skal være installert som global skill. Er den ikke det, lastes den
ned fra Sopra Steria sin AI Agent Marketplace. Se `KOM-I-GANG.md`.

All norsk tekst som skrives i denne mappen kjøres gjennom `sopra-steria-korrektur` automatisk,
mens teksten skrives, uten at brukeren ber om det. Dette gjelder også arbeidsnotater,
møtereferater og `STATUS.md`, ikke bare det kundevendte.

## Les dette først

Før du skriver noe som helst i denne mappen, les disse to filene:

1. `.claude/skills/utkast-og-review/SKILL.md`, som beskriver arbeidsflyten.
2. `.claude/rules/writing-style.md`, som peker videre til
   `.claude/customer-value/writing-style-core.md`.

Dette er et bevisst grep. Prosjekt-lokale skills utløses ikke automatisk på sin egen
beskrivelse i Cowork, så lesingen må tvinges herfra. Hopp aldri over den fordi oppgaven ser
liten ut.

## Loopen

Arbeidet kjører som en loop. Iterasjonsenheten er definert i
`.claude/skills/utkast-og-review/SKILL.md`, for eksempel én seksjon, én slide eller ett felt.

Utkast, vis frem, ta imot tilbakemelding, bekreft, videre til neste enhet. Den indre loopen ber
aldri om lov til å fortsette til neste enhet, bare om bekreftelse på selve innholdet.

**Godkjenningsporten ligger utenfor loopen.** Den indre loopen når aldri frem til ferdig
dokument eller eksport på egen hånd. Porten er beskrevet under.

En økt er sjelden hele loopen. Skriv hvor arbeidet står i sakens `STATUS.md` i det øyeblikket
noe endrer seg, og som siste handling før økten avsluttes.

## Review-porten

Rett før du lager den endelige leveransen, og før du spør brukeren om godkjenning, skal begge
reviewerne kjøre på det ferdige utkastet. Funnene vises alltid til brukeren før det spørres om
signoff.

`customer-value-reviewer` utfordrer om leveransen skaper reell verdi for kunden.
`writing-style-reviewer` sjekker skrivereglene. De to overlapper ikke, og begge skal kjøre.

Kall dem slik, i denne rekkefølgen. Gå videre til neste trinn bare hvis trinnet over feiler:

**Trinn 1.** Bruk `Agent` med `subagent_type: customer-value-reviewer`, deretter
`subagent_type: writing-style-reviewer`. Gi hver av dem stien til utkastet. Dette virker i
Claude Code.

**Trinn 2.** Får du en feil om at agenttypen ikke finnes, som er det forventede utfallet i
Cowork: start en `general-purpose`-agent i stedet, og lim inn hele teksten under frontmatteren
i `.claude/agents/customer-value-reviewer.md` ordrett i prompten, sammen med stien til
utkastet. Gjenta for `.claude/agents/writing-style-reviewer.md`. Svaret får samme format som i
trinn 1, fordi agenten leser sjekklisten sin selv.

**Trinn 3.** Finnes ikke Agent-verktøyet i det hele tatt: kjør vurderingen selv, som et eget
og tydelig merket pass etter at utkastet er ferdig. Les
`.claude/customer-value/criteria.md` og `.claude/customer-value/writing-style-core.md`, bruk
hver sjekk i dem, og svar i formatet filene beskriver. Si til brukeren at vurderingen ble kjørt
inline fordi sub-agenter ikke var tilgjengelige.

Ingen av trinnene hopper over porten. En leveranse går aldri til endelig generering uten at
begge vurderingene er kjørt og vist.

Merk at `writing-style-reviewer` bevisst ikke sjekker om `sopra-steria-korrektur` ble kjørt.
Det er en prosessregel som gjelder mens teksten skrives, og den ligger hos den som skriver.

## STATUS.md

Hver sak har sin egen `STATUS.md` i sin egen mappe. Den holder sakens løpende tilstand:
sammendrag, gjeldende omfang og beslutninger, åpne spørsmål, og hvordan arbeidet gjenopptas.

Opprett `STATUS.md` med én gang en ny saksmappe lages, som skjelett, ikke etterpå når saken
allerede er blitt komplisert. `STATUS-mal.md` i roten er malen. Oppdater den på to tidspunkt: i
det øyeblikket noe endrer seg, og som avsluttende steg hver gang en økt på saken slutter.

`STATUS.md` er loopens hukommelse mellom økter. Uten den starter neste økt forfra.

## memory.md

`memory.md` i roten holder det som skal overleve til en *annen* sak: vinnertemaer,
korreksjoner på produktnavn og fakta, prosesslærdom, varige kundefakta. Les den før du skriver,
og oppdater den når en sak avsluttes.

Skillet mot `STATUS.md` er omfang, ikke tid. Saksspesifikk historikk, hva som er sendt, hva som
gjenstår, hører hjemme i `STATUS.md`. `memory.md` har bare en pekerlinje til den.

## Mappestruktur

Legg aldri saksinnhold rett i roten av denne mappen. Hver sak får sin egen undermappe, navngitt
etter saken selv, ikke etter kunden og ikke etter en dato:

```
<denne mappen>/
  CLAUDE.md
  memory.md
  STATUS-mal.md
  <Sak A>/
    STATUS.md
    Kundens forespørsel/
    Møtenotater/
    <leveransene>
  <Sak B>/
    ...
```

Samme kunde kan få flere saker over tid. Da opprettes en ny søstermappe, ikke nye filer i den
gamle.
