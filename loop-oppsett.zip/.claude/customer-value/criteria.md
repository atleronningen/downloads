# Customer Value - Review Criteria

Shared criteria used by the `customer-value-reviewer` agent across projects. This file holds
*what* to check. Project-specific framing (RFI-compliance lens vs. service-positioning lens)
comes from that project's own `CLAUDE.md` and `memory.md`, not from here.

> **Delt kopi.** Denne filen følger med loop-oppsettet og leses av
> `customer-value-reviewer` fra `.claude/customer-value/criteria.md` i din egen mappe.
> Kanonisk versjon vedlikeholdes av teamet som delte pakken. Endrer du noe her, gjelder
> endringen bare din mappe, og den forsvinner hvis du legger inn en nyere versjon av pakken.
> Legg gjerne til egne sjekker nederst i stedet for å endre de eksisterende.

## What this agent is for

Challenge whether a deliverable (RFI response, service description, consulting deck,
one-pager) actually creates value for the customer, not whether it is complete, compliant,
or well-written. Completeness and polish are the drafting skill's job. This agent's job is to
ask: would the customer's decision-maker read this and see something built for them, or
something generic that could go to anyone?

## Checks to run

For each deliverable under review:

1. **Traced to a specific pain point.** Every value claim ties to something concrete about
   this customer – a stated problem, a scale figure, an industry pattern – not a generic
   capability statement that could apply to any customer.
2. **Win themes are adapted, not reused verbatim.** Cross-check against the project's
   `memory.md` win-themes library. A theme can be reused, but its framing must be adapted to
   this customer's specific situation, not copy-pasted.
3. **Claims are grounded in real sources.** Every product/service/customer claim traces to a
   source this project has declared as authoritative in its own `CLAUDE.md`. Typical sources:
   a service or product catalogue, a contract template, the customer's own interview answers,
   verified web or annual-report research. Flag anything that sounds plausible but isn't
   traceable to that declared source material. If the project hasn't named its sources, say so
   as a finding in its own right.
4. **Answers "so what."** Every section states what the claim means for the customer's
   business outcome, not just what Sopra Steria offers.
5. **Scope and commercial claims are realistic.** No commitments beyond what's actually known
   about the customer or explicitly provided by the user (pricing, timelines, staffing).
6. **Advisory, not just reactive.** The deliverable recommends a path, not only answers the
   literal question asked.
7. **Differentiated.** Could a competent competitor submit this exact text with their own logo
   on it? If yes, it hasn't cleared the bar.

## How to review

- Read the project's own `CLAUDE.md` and `memory.md` first: they define the lens and the
  reference material to check claims against.
- Go section by section through the deliverable. For each section that fails a check, name
  the check, quote the weak line, and state what's missing. Don't rewrite it, that's the
  drafting skill's job.
- End with a short verdict. Be honest, a rubber-stamp review defeats the purpose of having
  this agent at all.

## Output format

```
## Customer Value Review - <deliverable name>

### Verdict: [ship as-is / ship with fixes / not ready]

### Findings
- [Section/line] - [check failed] - [what's missing]
- ...

### What's working
- [one or two things genuinely strong, so this isn't just criticism]
```
