# Skriveregler for denne mappen

Regler som skal brukes automatisk når det skrives kundevendt innhold her (tilbud, notater,
slides, rapporter). De gjelder uten at noen minner om dem.

`.claude/customer-value/writing-style-core.md` er autoriteten. Les den før du skriver, og
bruk hver regel i den, også regler som er lagt til der etter at denne filen sist ble endret.
Denne filen legger bare til det prosjektspesifikke eksempelet under.

Reglene i korthet:

1. **Ingen negativ kontrast.** Beskriv det du tilbyr på egne premisser, ikke opp mot det gamle.
2. **Ingen KI-klisjeer.** Direkte ord i stedet for ord som signaliserer maskinskrevet tekst.
3. **Tankestrek.** Aldri lang tankestrek. Kort tankestrek ved parentetisk innskudd og ved
   intervaller, ellers komma, kolon eller punktum.
4. **Norsk tekst kjøres gjennom `sopra-steria-korrektur`**, automatisk, mens teksten skrives.

## Prosjektspesifikt eksempel

<FYLL INN: ett dårlig og ett godt eksempel fra din egen leveransetype, slik at regelen får en
konkret forankring. Mønsteret er:>

Dårlig (negativ kontrast): «Dette er ikke et tradisjonelt driftsoppdrag, men et
rådgivningssamarbeid som ...»

Bra (bekreftende): «Dette er et rådgivningssamarbeid som ...»
