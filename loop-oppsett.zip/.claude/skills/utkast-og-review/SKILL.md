---
name: utkast-og-review
description: >
  Arbeidsflyt for å lage en kundevendt leveranse i denne mappen: research, utkast seksjon for
  seksjon, review av customer-value-reviewer og writing-style-reviewer, og til slutt
  godkjenning og generering. Bruk denne når brukeren ber om et tilbud, en tjenestebeskrivelse,
  en presentasjon, et notat eller annen kundevendt tekst her.
---

# Utkast og review

Mal for arbeidsflyten i denne mappen. Bytt ut det som står i `<FYLL INN>` til din egen
leveransetype, og slett resten av denne setningen når du har gjort det.

Arbeidsflyten har fire faser:

1. **Forankring** til kunden og kildene.
2. **Utkast**, som kjører som en loop.
3. **Review**, som er godkjenningsporten.
4. **Generering** av den ferdige leveransen.

### Loopen

Fase 2 kjører som en loop. **Iterasjonsenheten er <FYLL INN: én seksjon, én slide, ett felt i et
skjema, ett kapittel>.**

Utkast, vis frem, tilbakemelding, bekreftelse, videre til neste enhet. Den indre loopen går
enhet for enhet uten å be om lov til å fortsette. Bare innholdet trenger bekreftelse.

**Godkjenningsporten ligger utenfor loopen**, i fase 3. Review-passet og den samlede
godkjenningen skjer først når alle enhetene er bekreftet, og leveransen genereres aldri uten
brukerens uttrykkelige ja i fase 4. Den indre loopen når aldri frem til generering på egen
hånd.

Avsluttes en økt midt i loopen, noter i sakens `STATUS.md` hvilke enheter som er låst og hva
som gjenstår, slik at neste økt fortsetter loopen i stedet for å starte på nytt.

---

## Fase 1: Forankring

Før første utkast:

1. Les `../../../CLAUDE.md` i mappens rot, særlig avsnittet om hvilke kilder som er
   autoritative her, og `memory.md` for det som er lært på tidligere saker.
2. Les sakens `STATUS.md`. Fortsetter du en påbegynt sak, start der loopen slapp.
3. Les `.claude/rules/writing-style.md`.
4. Avklar med brukeren, ett spørsmål om gangen: <FYLL INN: hvilke tre til fem ting du må vite
   før du kan skrive, for eksempel hvem mottakeren er, hva kunden faktisk har bedt om, hvilken
   frist som gjelder, hvilket format leveransen skal ha.>

Vent på svar før du går videre. Ikke still alle spørsmålene i én melding.

## Fase 2: Utkast, enhet for enhet

Struktur på leveransen:

<FYLL INN: listen over enheter i din leveransetype, i rekkefølge. For eksempel:
1. Sammendrag
2. Forståelse av kundens situasjon
3. Foreslått tilnærming
4. Leveransemodell og team
5. Hvorfor Sopra Steria>

For hver enhet: skriv utkastet, vis det i chatten som ren tekst, be om tilbakemelding, juster,
og gå videre når brukeren bekrefter. Ikke generer filer eller eksport underveis. Alt vises i
chatten til alle enhetene er bekreftet.

## Fase 3: Review, godkjenningsporten

Når alle enhetene er bekreftet, og før du spør om godkjenning:

Kjør `customer-value-reviewer` og `writing-style-reviewer` på det samlede utkastet, etter
fallback-stigen i `../../../CLAUDE.md` under "Review-porten". Den beskriver de tre måtene å
kalle dem på, avhengig av hva som er tilgjengelig i økten. Logikken står bare der, slik at den
vedlikeholdes ett sted.

Vis funnene til brukeren, kort og konkret. Gjør de endringene brukeren er enig i. Gå videre til
fase 4 først når funnene er håndtert, eller brukeren uttrykkelig sier at leveransen sendes som
den er.

Er teksten norsk, kjør `sopra-steria-korrektur` på den her, hvis den ikke allerede er kjørt
underveis.

## Fase 4: Generering

Spør brukeren hvilket format leveransen skal ha, og generer den først etter et uttrykkelig ja.

<FYLL INN: hvordan leveransen lages, for eksempel hvilken mal som brukes, hvilket
skript som kjøres, hvor filen legges.>

Til slutt: oppdater sakens `STATUS.md` med hva som ble levert og hva som eventuelt gjenstår, og
`memory.md` med det som er verdt å ta med til neste sak.
