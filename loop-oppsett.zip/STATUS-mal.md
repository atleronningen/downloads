# STATUS: <saksnavn>

Mal. Kopier denne filen til `<Saksmappe>/STATUS.md` med én gang en ny sak opprettes, som
skjelett, og fyll den ut etter hvert. Slett dette avsnittet i kopien.

Oppdateres på to tidspunkt: i det øyeblikket noe endrer seg, og som siste handling hver gang en
økt på saken avsluttes.

## Sammendrag

<Hva saken gjelder, hvem kunden er, hva de har bedt om, og hvilken frist som gjelder.>

## Gjeldende omfang

<Hva leveransen skal inneholde slik det står nå.>

## Beslutninger

| Dato | Beslutning | Begrunnelse |
|------|------------|-------------|
|      |            |             |

## Hvor loopen står

<Hvilke enheter er bekreftet, hvilke gjenstår, hva som er neste steg. Dette avsnittet er det
viktigste for å kunne gjenoppta arbeidet i en ny økt.>

## Åpne spørsmål

- <Spørsmål som venter på svar, og hvem som skal svare.>

## Review-status

- customer-value-reviewer: <ikke kjørt / kjørt dato, hovedfunn / funn håndtert>
- writing-style-reviewer: <ikke kjørt / kjørt dato, hovedfunn / funn håndtert>
- sopra-steria-korrektur: <ikke aktuelt / kjørt dato>

## Leveranser

| Dato | Fil | Sendt til kunde |
|------|-----|-----------------|
|      |     |                 |
