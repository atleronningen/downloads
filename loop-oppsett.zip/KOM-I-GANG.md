# Kom i gang

Dette oppsettet gir deg en arbeidsmappe der Claude skriver kundevendt innhold i en fast loop,
med to uavhengige reviewere som godkjenningsport før noe blir ferdigstilt.

Du trenger cirka ti minutter. Det eneste du må gjøre selv, er å pakke ut zip-filen og svare på
fire korte spørsmål når Claude spør.

## 1. Forutsetning

`sopra-steria-korrektur` skal være installert som **global skill** hos deg. Er den ikke det,
laster du den ned fra Sopra Steria sin AI Agent Marketplace og installerer den før du går
videre.

Oppsettet forutsetter at den er tilgjengelig i enhver samtale, uavhengig av hvilken mappe som
er montert. All norsk tekst som skrives i mappen skal gå gjennom den automatisk.

## 2. Legg pakken i en tom mappe

Opprett en ny, tom mappe der du vil ha arbeidet ditt, og pakk ut `loop-oppsett.zip` i den, slik
at filene havner rett i mappens rot. Du skal ende opp med dette:

```
Din mappe/
  KOM-I-GANG.md          denne filen
  CLAUDE.md              instruksjonsfilen Claude leser automatisk
  memory.md              det som skal huskes på tvers av saker
  STATUS-mal.md          mal du kopierer inn i hver ny sak
  .claude/
    agents/              de to reviewerne
    customer-value/      sjekklistene de bruker
    rules/               skrivereglene
    skills/              arbeidsflyten
```

`.claude`-mappen er skjult i Finder. Trykk `Cmd + Shift + .` for å se den. Den skal være der,
og den skal ligge i roten av mappen din.

## 3. Monter mappen i Claude Cowork

Åpne Claude Desktop, start en Cowork-økt, og monter mappen du nettopp pakket ut i. Claude leser
`CLAUDE.md` automatisk ved starten av økten.

Skriv **«Hjelp meg med å komme i gang»** som din første melding. `CLAUDE.md` har fortsatt
uutfylte `<FYLL INN>`-felt på dette tidspunktet, så Claude gjenkjenner det og intervjuer deg
gjennom feltene i stedet for at du må åpne og redigere filen selv:

1. Mappens navn.
2. Hva mappen produserer. Én til tre setninger om leveransetypen.
3. Kilder som er autoritative her. Det viktigste feltet. Her lister du hvor faktapåstander
   skal hentes fra: en tjenestekatalog, en kontraktsmal, kundens egne intervjusvar, verifisert
   nettresearch. `customer-value-reviewer` bruker denne listen aktivt og melder fra når en
   påstand ikke kan spores til noe du har listet her.
4. Språk, norsk eller engelsk som standard.

Claude spør ett spørsmål av gangen og skriver svarene rett inn i `CLAUDE.md` selv. Du kan også
be Claude tilpasse `.claude/skills/utkast-og-review/SKILL.md` i samme runde, ved å bytte ut
iterasjonsenheten og listen over seksjoner til din egen leveransetype. Oppsettet virker også
uten det, men loopen blir tydeligere når enheten er navngitt.

Foretrekker du å fylle ut feltene selv i stedet for å bli intervjuet: åpne `CLAUDE.md` direkte
og rediger de fire `<FYLL INN>`-feltene før du monterer mappen. Claude ser da at feltene
allerede er utfylt og hopper over intervjuet.

## 4. Test at porten virker

Be Claude om noe kort, for eksempel:

> «Lag et utkast til et kort sammendrag for en tenkt kunde, så jeg får se hvordan flyten
> fungerer.»

Slik ser du at oppsettet virker:

- Claude leser `CLAUDE.md` og arbeidsflyten før den skriver.
- Utkastet kommer seksjon for seksjon, med bekreftelse mellom hver.
- Før noe ferdigstilles, kjører **begge** reviewerne, og funnene vises til deg.
- Ingenting genereres før du sier ja.

Ser du ikke review-passet, be uttrykkelig: «Kjør review-porten fra CLAUDE.md.» Skjer det
fortsatt ikke, sjekk at `.claude`-mappen ligger i roten av den monterte mappen.

## 5. Opprett din første sak

Lag en undermappe med saksnavnet, og kopier `STATUS-mal.md` inn i den som `STATUS.md` med én
gang. Legg aldri saksinnhold rett i mappens rot. Én sak per undermappe, navngitt etter saken,
ikke etter kunden og ikke etter en dato.

`STATUS.md` er det som gjør at neste økt kan fortsette der du slapp. Uten den starter Claude
forfra hver gang.

---

## Hva du får, kort forklart

**Loopen.** Arbeidet går i små steg: utkast, vis frem, tilbakemelding, bekreft, videre. Claude
spør ikke om lov til å gå videre til neste steg, bare om bekreftelse på innholdet. Det holder
tempoet oppe og lar deg styre innholdet.

**Godkjenningsporten.** Loopen når aldri frem til et ferdig dokument på egen hånd. Rett før
ferdigstilling kjører to uavhengige reviewere:

- `customer-value-reviewer` utfordrer om leveransen faktisk skaper verdi for kunden, eller om
  den er generisk. Nøkkelspørsmålet den stiller: Kunne en konkurrent sendt akkurat denne
  teksten med sin egen logo på?
- `writing-style-reviewer` sjekker skrivereglene: tankestrek, og formuleringer som definerer
  noe ved det de ikke er.

De to overlapper ikke, og begge kjører hver gang.

**Hukommelsen.** `STATUS.md` per sak holder løpende tilstand. `memory.md` i roten holder det
som skal gjelde på tvers av saker. Begge leses før arbeidet gjenopptas.

## Hvorfor reviewerne kalles på en omvei i Cowork

Cowork kaller ikke alltid prosjekt-lokale sub-agenter på navn. Skjer det, starter Claude i
stedet en vanlig agent og limer inn reviewer-instruksen ordrett fra `.claude/agents/`. Du får
samme vurdering i samme format, fordi agenten leser sjekklisten sin selv uansett.

`CLAUDE.md` beskriver tre måter å kjøre review-passet på, og går videre til neste hvis den
forrige ikke virker. Det siste alternativet kjører vurderingen direkte i samtalen. Ser du at
review-passet kjøres «inline», er det denne mekanismen som slår inn. Oppsettet virker som det
skal.

## Endre på oppsettet

- **Egne sjekker i verdivurderingen:** legg dem til nederst i
  `.claude/customer-value/criteria.md`, i stedet for å endre de eksisterende.
- **Egne skriveregler:** legg dem i `.claude/rules/writing-style.md`.
- **Egen arbeidsflyt:** endre `.claude/skills/utkast-og-review/SKILL.md`. Selve review-porten
  bør bli stående som den er, siden `SKILL.md` peker til `CLAUDE.md` for den logikken.

Får du en oppdatert versjon av pakken senere, overskrives filene under
`.claude/customer-value/`. Endringer du har gjort der, forsvinner. Derfor hører det du selv
legger til hjemme i `.claude/rules/writing-style.md` og nederst i `criteria.md`.
