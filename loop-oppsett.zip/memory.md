# memory.md

Arbeidshukommelse for denne mappen. Her ligger det som skal overleve til en *annen* sak.
Saksspesifikk løpende status hører hjemme i sakens egen `STATUS.md`, ikke her.

Les denne filen før du skriver noe nytt. Oppdater den når en sak avsluttes, og med én gang du
lærer noe som vil gjelde neste gang også.

## Saksslogg

Én linje per sak, med peker til sakens `STATUS.md`.

| Dato | Sak | Status | Peker |
|------|-----|--------|-------|
|      |     |        |       |

## Vinnertemaer

Argumenter og vinklinger som har fungert. Et tema kan gjenbrukes, men innrammingen skal
tilpasses den nye kundens situasjon, ikke limes inn ordrett. `customer-value-reviewer` sjekker
nettopp dette.

## Korreksjoner og fakta

Produktnavn, tall, roller og andre fakta som er blitt rettet én gang og ikke skal rettes igjen.

## Prosesslærdom

Det som gikk galt eller uventet bra i arbeidsflyten, og hva som skal gjøres annerledes.

## Kundefakta

Varig kontekst om kunder som er nyttig neste gang de nevnes.
